from RFTDT_AnnotationReaderXML import *
import matplotlib.pyplot as plot
import numpy as np
import math as math
import os
import ExamplePlotter_AnnotationReader
import matplotlib.pyplot as plot
import numpy as np

file_location = raw_input("Input data path.")
os.chdir(file_location)
annotation_files = ExamplePlotter_AnnotationReader.annotation_finder(file_location)

def get_rotation_matrix(i_v, unit=None):
    # From http://www.j3d.org/matrix_faq/matrfaq_latest.html#Q38
    if unit is None:
        unit = [0.0, 1.0, 0.0]
    # Normalize vector length
    i_v = i_v/ np.linalg.norm(i_v)

    # Get axis
    uvw = np.cross(i_v, unit)

    # compute trig values - no need to go through arccos and back
    rcos = np.dot(i_v, unit)
    rsin = np.linalg.norm(uvw)

    #normalize and unpack axis
    if not np.isclose(rsin, 0):
        uvw /= rsin
    u, v, w = uvw

    # Compute rotation matrix - re-expressed to show structure
    return (
        rcos * np.eye(3) +
        rsin * np.array([
            [ 0, -w,  v],
            [ w,  0, -u],
            [-v,  u,  0]
        ]) +
        (1.0 - rcos) * uvw[:,None] * uvw[None,:]
    )

# def unit_vector(vector):
#     """ Returns the unit vector of the vector.  """
#     return vector / np.linalg.norm(vector)
#
# def polarity_index(source_target_dict, nodes, edges):


for annotation_file in annotation_files:

    trans_node_locs = []

    # Start by finding the paths and getting the coordinates for each node in the paths
    # This will allow you to plot without having lines between the last node of each tree and the first
    # node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
    # nodes, edges = annotation_parser(annotation_file)

    nodes, edges = annotation_parser(annotation_file)

    node_locations = node_location_finder(nodes, edges)

    source_target_dict = source_target(edges)

    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print len(tip_list)
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    node_location = node_location_finder(nodes, edges)
    soma_location = [item for item in node_locations if item[0] == soma_node]

    # Start by finding the lateral indicator node, the apical indicator node and the soma node
    # also get the nodes only in the tree (i.e not the apical and lateral nodes)
    # including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
    node_id_list = [node.attrib['id'] for node in nodes]
    radii_list = [node.attrib['radius'] for node in nodes]
    lateral_node = node_id_list[radii_list.index('5.5')]
    lateral_node_list = [lateral_node]
    apical_node = node_id_list[radii_list.index('5')]
    radii_list.remove('5')
    radii_list.remove('5.5')
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    radii_list.remove(max(radii_list))
    tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
    tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
    int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]

    # get branching nodes and tips
    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    branch_node_tips = branch_node_list + tip_list
    branch_node_tips.remove(lateral_node_list[0])
    int_branch_node_tips = [int(node) for node in branch_node_tips]

    # special node locations (soma, apical, lateral)
    apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
    apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
    apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
    apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
    lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
    lateral_x = np.int16([node.attrib['x'] for node in lateral_attribs])
    lateral_y = np.int16([node.attrib['y'] for node in lateral_attribs])
    lateral_z = np.int16([node.attrib['z'] for node in lateral_attribs])
    soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
    soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
    soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
    # Translate apical node the distances required for soma to be a 0,0,0
    trans_apical_x = (apical_x - soma_x)
    trans_apical_y = (apical_y - soma_y)
    trans_apical_z = (apical_z - soma_z)

    # Translate lateral indicator node the distances required for soma to be 0,0,0
    trans_lateral_x = (lateral_x - soma_x)
    trans_lateral_y = (lateral_y - soma_y)
    trans_lateral_z = (lateral_z - soma_z)

    # remove the lateral node so that it isn't counted as a tip/path/vector
    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    tip_list.remove(lateral_node_list[0])

    # define original vector as that of the sapical dendrite
    apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])

    # Compute the rotation matrix
    R = get_rotation_matrix(apicalv)

    # Apply the rotation matrix to the apical vector
    newv = np.dot(apicalv.T, R.T)

    # roate the lateral vector to be in register with rotated cell
    lateralv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
    newlatv = np.dot(lateralv.T, R.T)
    newlatv_a_l = [[coordinate for coordinate in vector] for vector in newlatv]
    newlatv_int = [int(coord) for coord in newlatv_a_l[0]]

    newlatv_coords = []
    # flip lateral vector if it is on the wrong side
    if newlatv_int[0] < 1:
        newlatv_coords.append((newlatv_int[0], newlatv_int[1], newlatv_int[2]))
    else:
        newlatv_coords.append((-newlatv_int[0], newlatv_int[1], newlatv_int[2]))
    # print newlatv_coords
    # Apply the rotation matrix to tip-soma vector for each path
    # Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
    # This is so that the rotation can be applied and simple +/- integer used to determine lateral position
    trans_tips = []

    matches = [item for item in node_location if item[0] in tip_list]
    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

    for match in int_matches:
        tipv = np.array([match[1] - soma_x, match[2] - soma_y, match[3] - soma_z])
        newtip = np.dot(tipv.T, R.T)

        trans_tips.append([match[0], newtip[0], newtip[1], newtip[2]])

    trans_tips_int = [[int(coords) for coords in tip] for tip in trans_tips]

    # Flip the cells so that the lateral side is on the left, if necessary
    flipped_tips = []
    for tip in trans_tips_int:
        if newlatv_int[0] < 1:
            flipped_tips.append((tip[0], tip[1], tip[2], tip[3]))
        else:
            flipped_tips.append((tip[0], -tip[1], tip[2], tip[3]))

    # print flipped_tips

    # find tips that are on each side of the soma
    negative_tips = [tip[0] for tip in flipped_tips if tip[1] < 0]
    positive_tips = [tip[0] for tip in flipped_tips if tip[1] > 0]
    # print negative_tips
    # print positive_tips

    # find the distance from the soma (0,0,0) and each tip (radius)
    # Because the soma is always at (0,0,0), we can omit the subtraction present in the standard distance formula

    distance = []
    for tip in flipped_tips:
        distance.append(np.sqrt(tip[1] ** 2 + tip[3] ** 2))
    # print distance

    # make unit vectors for all the vectors
    # start with apical vector
    # print newv
    apical_mag = math.sqrt(newv[0] ** 2 + newv[1] ** 2)
    # print apical_mag
    unit_apicalv = (newv[0] / apical_mag, newv[1] / apical_mag)
    # print unit_apicalv

    unit_tip_vectors = []
    for tip in flipped_tips:
        tip_mag = math.sqrt(tip[1] ** 2 + tip[3] ** 2)
        if tip_mag == 0:
            continue
        unit_tip_vectors.append((tip[0], tip[1] / tip_mag, tip[3] / tip_mag))

    # print unit_tip_vectors

    # find the angle between the apical vector and the vector that defines each path (soma to tip only)
    # return both the tip index (used later) and the angle in degrees.
    tip_angle = []
    for vector in unit_tip_vectors:
        # tip_coords = np.array(tip[1:4])
        v1_u = unit_apicalv
        v2_u = vector[1:3]
        tip_angle.append([vector[0], np.degrees(np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0)))])

    # print tip_angle

    # get just the angles of the tips for later calculations
    angles_180 = [angle[1] for angle in tip_angle]
    print max(angles_180)

    # print paths_180
    # correct the calculated angle by converting to 360 coordinates. The original calculation gives the smallest
    # angle between apical and tip (all <180), so add 180 to all "negative" tips to make 360 coordinates
    # "negative" tips were chosen as a convention. Either "negative" or "positive" could be used at users desire
    angles_360 = []
    for tip in tip_angle:
        if tip[0] in positive_tips:
            angles_360.append((360 - tip[1]))

        else:
            angles_360.append(tip[1])
            # print angles_360
            # print angles_360
            # Calculate the length of the mean vector of the tips. Based on Batchelet 1981 bood Eq. 1.3.7-1.3.9 see ex. 1.3.2
            # IMPORTANT: THIS VERSION USES LENGTH 1 FOR ALL PATHS (i.e. this is not weigthed by path length)

    # calculate X and y
    cos_angles_360 = [math.cos(math.radians(angle)) for angle in angles_360]
    # print cos_angles_360
    sum_cos = sum(cos_angles_360)
    sin_angles_360 = [math.sin(math.radians(angle)) for angle in angles_360]
    sum_sin = sum(sin_angles_360)
    x_bar = (sum_cos / len(angles_360))
    y_bar = (sum_sin / len(angles_360))

    # calucate X and Y for orientation. Use angle doubling as suggested by Batchalet et al.
    angle_doubling = [angle * 2 for angle in angles_360]

    corrected_angle_doubling = []
    for angle in angle_doubling:
        if angle >= 360:
            corrected_angle_doubling.append(angle - 360)
        else:
            corrected_angle_doubling.append(angle - 0)

    # print angle_doubling
    # print corrected_angle_doubling
    cos_angles_doub = [math.cos(math.radians(angle)) for angle in corrected_angle_doubling]
    sum_cos = sum(cos_angles_doub)
    sin_angles_doub = [math.sin(math.radians(angle)) for angle in corrected_angle_doubling]
    sum_sin = sum(sin_angles_doub)
    x_bar_2 = (sum_cos / len(corrected_angle_doubling))
    y_bar_2 = (sum_sin / len(corrected_angle_doubling))

    # calculate r, the length of the mean vector on unit circle
    r = ((x_bar ** 2) + (y_bar ** 2)) ** 0.5
    r2 = ((x_bar_2 ** 2) + (y_bar_2 ** 2)) ** 0.5

    # caluclate the angle of the mean angle. This code returns the angle someitmes in negative degrees, so a correction
    # must be applied in those cases
    xz_angle_r_raw = (str(np.degrees(np.arctan2(y_bar, x_bar))))
    xz_angle_r2_raw = (str(np.degrees(np.arctan2(y_bar_2, x_bar_2))))

    # this is the correction for negative angles.
    xz_angle_r = []
    xz_angle_r2 = []

    if float(xz_angle_r_raw) < 0:
        xz_angle_r.append(360 + float(xz_angle_r_raw))
    else:
        xz_angle_r.append(0 + float(xz_angle_r_raw))

    if float(xz_angle_r2_raw) < 0:
        xz_angle_r2.append((360 + float(xz_angle_r2_raw)) * 0.5)
    else:
        xz_angle_r2.append((0 + float(xz_angle_r2_raw)) * 0.5)


    # calculate test statistic z for Raleigh test
    n = len(angles_360)
    z = (n * (r ** 2))
    z2 = (n * (r2 ** 2))


    #####Graphing Code#####

    path_list = [ExamplePlotter_AnnotationReader.path_finder(source_target_dict, soma_node, tip) for tip in tip_list]
    node_location = ExamplePlotter_AnnotationReader.node_location_finder(nodes, edges)


    #get the locations for each node in each path
    for path in range(0, len(path_list)):
        matches = [item for item in node_location if item[0] in path_list[path]]
        matches_nodes = [match[0] for match in matches]
        matches_index = [path_list[path].index(node) for node in matches_nodes]
        sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
        int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
        x = [location[1] for location in sorted_matches]
        z = [location[3] for location in sorted_matches]
        plot.plot(x,z)

    #Identify the soma node identity and location, then plot a node of size 20 there
    #This is useful for scaling each cell reconstruction equally for figures since each differs significantly in
    #the span of the arbor (and therefore axes). Plotting a point in this way avoids excessive manual axis scaling

    #Get soma node location and plot a size 20 marker at that location
    soma_location = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [node.attrib['x'] for node in soma_location]
    soma_z = [node.attrib['z'] for node in soma_location]
    plot.plot(soma_x,soma_z,'bo',markersize=20)

    plot.show()
