import os
import sqlite3
from AnnotationReaderXML_Trees import *
from random import *
import numpy as np
import time


connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

cursor = connection.execute("select count(*) from Trees")
for row in cursor:
    print row
# cursor = connection.execute("select * from Trees")
# cursor = connection.execute("select avg(soma_radius) from Trees")
#
#
# for row in cursor:
#      print row
#      print 'animal_id', row[0]
#      print 'neuron_id =', row[1]
#      # print 'soma_size =', row[2]
#      # print 'tree_number=', row[3]
#      # print 'mean_branch_number=', row[5]
#      print 'branch_lengths',row[6]
#      print 'mean_branch_length',row[5]
#      # print 'volume', row[14]
#      # # print 'density', row[15]

# connection.execute('drop table Trees')
# connection.execute('''create table Neurons(animal_id text, neuron_id text primary key,soma_radius real,tree_number int, mean_branch_length real, branch_lengths text, branch_number int, path_lengths text, mean_path_length real,tip_number int);''')
# connection.execute('''create table Trees(animal_id text, tree_id text primary key, mean_branch_length real, branch_lengths text,
#     branch_number int, path_lengths text, mean_path_length real, tip_number int, tree_len real, tort text, mean_tortuosity real, tree_volume real, tree_density real, tree_sholl text);''')

# file_location = raw_input("Input data path.")
# os.chdir(file_location)
# annotation_files = annotation_finder(file_location)
#
#
# #
# for annotation_file in annotation_files:
#
#     nodes,edges = annotation_parser(annotation_file)
#     source_target_dict = source_target(edges)
#     id = str(annotation_filename_getter(annotation_file))
#     print id
#
#     step = step_size_corrector(id)
#     print step
#
#     animal_id = annotation_file[-29:-23]
#     print animal_id
#
#     neuron_id = annotation_file[-29:-16]
#     print neuron_id
#
#     tree_paths = find_trees(nodes, edges, source_target_dict)
#
#     for treepath in tree_paths:
#         flat_treepath = list(set([item for sublist in treepath for item in sublist]))
#         tree_nodes = [node for node in nodes if node.attrib['id'] in flat_treepath]
#         tree_edges = [edge for edge in edges if edge.attrib['source'] in flat_treepath and edge.attrib['target'] in flat_treepath]
#
#         # print 'source_target'
#         source_target_dict = source_target(tree_edges)
#
#         animal_id = annotation_file[-29:-23]
#         print animal_id
#
#         a = list(range(1,99999))
#         tree_id = annotation_file[-29:-14] + str(np.random.choice(a, replace = False))
#         print tree_id
#
#         branch_num = branch_number(tree_nodes,tree_edges)
#
#         tip_num = tip_number(tree_nodes,tree_edges)
#
#         branch_lengths, mean_branch_length = segment_length(source_target_dict, tree_nodes,tree_edges,step)
#         branch_lengths = str(branch_lengths).strip('[]')
#
#         tree_len = tree_length(source_target_dict, tree_nodes, tree_edges,step)
#
#         path_lengths, mean_path_length = path_length(source_target_dict, tree_nodes,tree_edges,step)
#         path_lengths = str(path_lengths).strip('[]')
#         mean_path_length = mean_path_length
#
#
#         tortuosity_, mean_tortuosity = tortuosity(source_target_dict, tree_nodes,tree_edges,step)
#         # print tortuosity_
#         tort = str(tortuosity_).strip('[]')
#
#
#         tree_volume = volume(tree_nodes,tree_edges,step)
#         # print tree_volume
#
#         tree_density = density(source_target_dict, tree_nodes,tree_edges,step)
#
#         tree_sholl = sholl(source_target_dict, tree_nodes,tree_edges,step)
#         tree_sholl = str(tree_sholl).strip('[]')
#
#
#     #connection.execute("insert into Trees (animal_id,neuron_id,soma_radius,tree_number,mean_branch_length,branch_lengths, branch_number, path_lengths,mean_path_length, tip_number,volume,density) values(?,?,?,?,?,?,?,?,?,?,?,?);",(animal_id,neuron_id,soma_radius, tree_num,mean_branch_length,branch_lengths, branch_num, path_lengths, mean_path_length,tip_num,volume,density))
#         connection.execute("insert into Trees (animal_id,tree_id, mean_branch_length, branch_lengths, branch_number, path_lengths, mean_path_length, tip_number, tree_len, tort, mean_tortuosity, tree_volume, tree_density, tree_sholl) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?);",(animal_id,tree_id, mean_branch_length, branch_lengths, branch_num, path_lengths, mean_path_length, tip_num, tree_len, tort, mean_tortuosity, tree_volume, tree_density, tree_sholl))
#
#

connection.commit()
connection.close()