
    # #
# # for annotation_file in annotation_files:
# #
# #     trans_node_locs = []
# #
# #     #Start by finding the paths and getting the coordinates for each node in the paths
# #     #This will allow you to plot without having lines between the last node of each tree and the first
# #     #node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
# #     # nodes, edges = annotation_parser(annotation_file)
# #     trans_node_locs = []
# #     #
# #     #     #Start by finding the paths and getting the coordinates for each node in the paths
# #     #     #This will allow you to plot without having lines between the last node of each tree and the first
# #     #     #node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
# #     #     # nodes, edges = annotation_parser(annotation_file)
# #     #
# #     nodes, edges = annotation_parser(annotation_file)
# #
# #     node_locations = node_location_finder(nodes, edges)
# #
# #     source_target_dict = source_target(edges)
# #
# #     source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
# #     target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
# #     combined_node_pairs = source_target_pairs + target_source_pairs
# #     target_nodes = [pair[0] for pair in combined_node_pairs]
# #     source_nodes = [pair[1] for pair in combined_node_pairs]
# #     combined_source_targets_flat = target_nodes + source_nodes
# #     unique_nodes_set = set(combined_source_targets_flat)
# #     unique_nodes = list(unique_nodes_set)
# #
# #     node_id_list = [node.attrib['id'] for node in nodes]
# #     tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
# #     # print len(tip_list)
# #     radii_list = [node.attrib['radius'] for node in nodes]
# #     soma_node = node_id_list[radii_list.index(max(radii_list))]
# #     node_location = node_location_finder(nodes, edges)
# #     soma_location = [item for item in node_locations if item[0] == soma_node]
# #
# #     #Start by finding the lateral indicator node, the apical indicator node and the soma node
# #     #also get the nodes only in the tree (i.e not the apical and lateral nodes)
# #     #including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
# #     node_id_list = [node.attrib['id'] for node in nodes]
# #     radii_list = [node.attrib['radius'] for node in nodes]
# #     lateral_node = node_id_list[radii_list.index('5.5')]
# #     lateral_node_list = [lateral_node]
# #     apical_node = node_id_list[radii_list.index('5')]
# #     radii_list.remove('5')
# #     radii_list.remove('5.5')
# #     soma_node = node_id_list[radii_list.index(max(radii_list))]
# #     radii_list.remove(max(radii_list))
# #     tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
# #     tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
# #     int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]
# #
# #     #get branching nodes and tips
# #     branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
# #     branch_node_tips = branch_node_list + tip_list
# #     branch_node_tips.remove(lateral_node_list[0])
# #     int_branch_node_tips = [int(node) for node in branch_node_tips]
# #
# #     #special node locations (soma, apical, lateral)
# #     apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
# #     apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
# #     apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
# #     apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
# #     lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
# #     lateral_x = [int(node.attrib['x']) for node in lateral_attribs][0]
# #     lateral_y = [int(node.attrib['y']) for node in lateral_attribs][0]
# #     lateral_z = [int(node.attrib['z']) for node in lateral_attribs][0]
# #     soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
# #     soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
# #     soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
# #     soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
# #     #Translate apical node the distances required for soma to be a 0,0,0
# #     trans_apical_x = (apical_x - soma_x)
# #     trans_apical_y = (apical_y - soma_y)
# #     trans_apical_z = (apical_z - soma_z)
# #     #Translate lateral node the distances required for soma to be 0,0,0
# #     trans_lateral_x = (lateral_x - soma_x)
# #     trans_lateral_y = (lateral_y - soma_y)
# #     trans_lateral_z = (lateral_z - soma_z)
# #
# #
# #
# #     #define original vector as that of the sapical dendrite
# #     apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])
# #
# #     # Compute the rotation matrix
# #     R = get_rotation_matrix(apicalv)
# #
# #     # Apply the rotation matrix to the apical vector
# #     newv = np.dot(apicalv.T, R.T)
# #
# #     #make and rotate the lateral node vector
# #     latv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
# #     new_latv = np.dot(latv.T,R.T)
# #     # print new_latv
# #
# #     matches = [item for item in node_location if item[0] in branch_node_tips]
# #
# #     int_matches = [[int(coordinate) for coordinate in match] for match in matches]
# #     # print int_matches
# #
# #         #Apply the rotation matrix to tip-soma vector
# #
# #     for node in int_tree_node_locations:
# #         branchv = np.array([node[1]-soma_x, node[2]-soma_y, node[3]-soma_z])
# #         # print branchv
# #
# #         new_node = np.dot(branchv.T,R.T)
# #         # print new_node
# #
# #         trans_node_locs.append([node[0], -new_node[0], (new_node[1]), new_node[2]])
# #
# #     # print trans_node_locs
# #
# #
# #     #find segments
# #     segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in
# #                     branch_node_tips]
# #     segment_list = [segment for segment in segment_list if segment is not None]
# #     segment_list = [segment for segment in segment_list if len(segment) > 1]
# #
# #
# #     superficial_branch_nodes = [node[0] for node in  trans_node_locs if node[2] > 0 and node[0] in int_branch_node_tips]
# #     deep_branch_nodes = [node[0] for node in  trans_node_locs if node[2] < 0 and node[0] in int_branch_node_tips]
# #
# #     segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in branch_node_tips]
# #     segment_list = [segment for segment in segment_list if segment is not None]
# #     segment_list = [segment for segment in segment_list if len(segment) > 1]
# #
# #     unique_segment_list1 = []
# #     for segment in segment_list:
# #         # print segment
# #         branch_node_tip_found = 0
# #         for node in branch_node_tips:
# #             if node in segment[1:-1]:
# #                 branch_node_tip_found = 1
# #         if branch_node_tip_found == 0:
# #             unique_segment_list1.append(segment)
# #
# #             #
# #             # print unique_segment_list1
# #     unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
# #     unique_segment_list = [list(item) for item in unique_segment_list]
# #     # print len(unique_segment_list)
# #
# #     real_segments = []
# #     for match in unique_segment_list:
# #         segment_found = 0
# #         for segment in unique_segment_list1:
# #             if segment_found == 0:
# #                 segment_set = set(segment)
# #                 match_set = set(match)
# #                 if segment_set == match_set:
# #                     real_segments.append(segment)
# #                     segment_found = 1
# #     unique_segment_list = real_segments
# #
# #     int_segment_list = [[int(coordinate) for coordinate in segment] for segment in unique_segment_list]
# #
# #
# #     #Reverse lines so that '1' is never the first node in order to make sorting much easier
# #     ordered_int_segments = []
# #     for segment in int_segment_list:
# #         if segment[0] == 1:
# #             ordered_int_segments.append(segment[::-1])
# #         else:
# #             ordered_int_segments.append(segment)
# #
# #     #divide up segments by whether their branch node is ont the positive or negative side.
# #     #NOTE: this code considers a branch to be in whichever side it starts in.
# #     superficial_segments = [segment for segment in ordered_int_segments if segment[0] in superficial_branch_nodes]
# #     superficial_segments_list = [[str(node) for node in segment] for segment in superficial_segments]
# #     deep_segments = [segment for segment in ordered_int_segments if segment[0] in deep_branch_nodes]
# #     deep_segments_list = [[str(node) for node in segment] for segment in deep_segments]
# #
# #     #caluclate the branch number index value
# #     # print 'Branch Number'
# #     superficial_branch_number = float(len( superficial_branch_nodes))
# #     deep_branch_number =  float(len(deep_branch_nodes))
# #     branch_number = float(superficial_branch_number + deep_branch_number)
# #     # print float(superficial_branch_number)
# #     # print float(deep_branch_number)
# #     # print float(superficial_branch_number/branch_number)
# #
# #
# #     #calculate the segment length for both positive and negative branches
# #     node_location = node_location_finder(nodes, edges)
# #     superficial_segment_lengths = []
# #     for segment in range(0, len(superficial_segments_list)):
# #         matches = [item for item in node_location if item[0] in superficial_segments_list[segment]]
# #         # print matches
# #         if matches == []:
# #             superficial_segment_lengths.append(0)
# #         else:
# #             matches_nodes = [match[0] for match in matches]
# #             matches_index = [superficial_segments_list[segment].index(node) for node in matches_nodes]
# #             sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
# #             int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
# #             # print sorted_matches
# #
# #
# #             interpoint_distance = 0
# #             for match in range(0, len(int_matches) - 1):
# #                 interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
# #                                                                                int_matches[match + 1][1:4])
# #             # print int_matches[match][1:4]
# #             superficial_segment_lengths.append(interpoint_distance)
# #
# #     superficial_segment_lengths = set(superficial_segment_lengths)
# #     supseg_total_length = sum(superficial_segment_lengths)
# #
# #     deep_segment_lengths = []
# #     for segment in range(0, len(deep_segments_list)):
# #         matches = [item for item in node_location if item[0] in deep_segments_list[segment]]
# #         # print matches
# #         if matches == []:
# #             deep_segment_lengths.append(0)
# #         else:
# #             matches_nodes = [match[0] for match in matches]
# #             matches_index = [deep_segments_list[segment].index(node) for node in matches_nodes]
# #             sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
# #             int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
# #             # print sorted_matches
# #
# #
# #             interpoint_distance = 0
# #             for match in range(0, len(int_matches) - 1):
# #                 interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
# #                                                                                int_matches[match + 1][1:4])
# #             # print int_matches[match][1:4]
# #                 deep_segment_lengths.append(interpoint_distance)
# #
# #     deep_segment_lengths = set(deep_segment_lengths)
# #     deepseg_total_length = sum(deep_segment_lengths)
# #
# #     total_seg_length = supset_total_length = deepseg_total_length
# #     # print 'Total Seg Length'
# #     # print supseg_total_length
# #     # print deepseg_total_length
# #     # print float(supseg_total_length/total_seg_length)
# #
# #
# #     #TIP BASED MEASURE
# #     #Apply the rotation matrix to tip-soma vector for each path
# #     #Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
# #     #This is so that the rotation can be applied and simple +/- integer used to determine lateral position
# #     trans_tips = []
# #
# #     matches = [item for item in node_location if item[0] in tip_list]
# #     int_matches = [[int(coordinate) for coordinate in match] for match in matches]
# #
# #     for match in int_matches:
# #         tipv = np.array([match[1]-soma_x, match[2]-soma_y, match[3]- soma_z])
# #         newtip = np.dot(tipv.T,R.T)
# #
# #         trans_tips.append(newtip[1])
# #
# #     # print newtip
# #     # find tips that are on each side of the soma
# #     superficial_tips = [tip for tip in trans_tips if tip > 0 ]
# #     deep_tips = [tip for tip in trans_tips if tip < 0 ]
# #
# #     # count number of tips on right and left of soma and count total number of tips
# #
# #     superficial_tip_num = float(len(superficial_tips))
# #     # print 'Tip Number'
# #     # print superficial_tip_num
# #     deep_tip_num =  float(len(deep_tips))
# #     # print deep_tip_num
# #     total_tip_num = float(superficial_tip_num + deep_tip_num)
# #     print float(superficial_tip_num/total_tip_num)
#
#     # print type(lat_tip_num)
#
#     # return medial_branch_number, lateral_branch_number, medseg_total_length, latseg_total_length, med_tip_num, lat_tip_num
#
# ### Begin Correlation code
# import math
# import matplotlib.pyplot as plot;plot.rcdefaults()
# import scipy
# from scipy import stats
# import numpy as np
# import matplotlib.pyplot as plot
# import statsmodels.api as sm
# from random import *
# from Database_Queries import dev_graphs
#
# from RFTdt_Database_Queries import number_dev_graphs
# from RFTdt_Database_Queries import directionality_dev_graphs
#
#
# R_WTTR_dpi03_values, R_WTTR_dpi05_values, R_WTTR_dpi07_values, R_WTTR_dpi09_values, R_WTTR_dpi12_values, R_FLXTR_dpi03_values, R_FLXTR_dpi05_values, R_FLXTR_dpi07_values, R_FLXTR_dpi09_values, R_FLXTR_dpi12_values = directionality_dev_graphs('r')
# Intersections_WTTR_dpi03_values, Intersections_WTTR_dpi05_values, Intersections_WTTR_dpi07_values, Intersections_WTTR_dpi09_values, Intersections_WTTR_dpi12_values, Intersections_FLXTR_dpi03_values, Intersections_FLXTR_dpi05_values, Intersections_FLXTR_dpi07_values, Intersections_FLXTR_dpi09_values, Intersections_FLXTR_dpi12_values = number_dev_graphs('intersections')
# SegNum_WTTR_dpi03_values, SegNum_WTTR_dpi05_values, SegNum_WTTR_dpi07_values, SegNum_WTTR_dpi09_values, SegNum_WTTR_dpi12_values, SegNum_FLXTR_dpi03_values, SegNum_FLXTR_dpi05_values, SegNum_FLXTR_dpi07_values, SegNum_FLXTR_dpi09_values, SegNum_FLXTR_dpi12_values = number_dev_graphs('branch_number')
#
#
# R_WT_values = R_WTTR_dpi03_values + R_WTTR_dpi05_values + R_WTTR_dpi07_values + R_WTTR_dpi09_values + R_WTTR_dpi12_values
# print len(R_WT_values)
# R_FLX_values = R_FLXTR_dpi03_values + R_FLXTR_dpi05_values + R_FLXTR_dpi07_values + R_FLXTR_dpi09_values + R_FLXTR_dpi12_values
#
# Intersections_WT_values = Intersections_WTTR_dpi03_values + Intersections_WTTR_dpi05_values + Intersections_WTTR_dpi07_values + Intersections_WTTR_dpi09_values + Intersections_WTTR_dpi12_values
# print len(Intersections_WT_values)
# Intersections_FLX_values = Intersections_FLXTR_dpi03_values + Intersections_FLXTR_dpi05_values + Intersections_FLXTR_dpi07_values + Intersections_FLXTR_dpi09_values + Intersections_FLXTR_dpi12_values
#
# SegNum_WT_values = SegNum_WTTR_dpi03_values + SegNum_WTTR_dpi05_values + SegNum_WTTR_dpi07_values + SegNum_WTTR_dpi09_values + SegNum_WTTR_dpi12_values
# SegNum_FLX_values = SegNum_FLXTR_dpi03_values + SegNum_FLXTR_dpi05_values + SegNum_FLXTR_dpi07_values + SegNum_FLXTR_dpi09_values + SegNum_FLXTR_dpi12_values
# print len(SegNum_WT_values)
#
# R_WT_Zscore =  stats.zscore(R_WT_values)
# R_FLX_Zscore = stats.zscore(R_FLX_values)
#
# Intersections_WT_Zscore = stats.zscore(Intersections_WT_values)
# Intersections_FLX_Zscore = stats.zscore(Intersections_FLX_values)
#
# SegNum_WT_Zscore = stats.zscore(SegNum_WT_values)
# SegNum_FLX_Zscore = stats.zscore(SegNum_FLX_values)
#
# print ' WT R X Intersections'
# r_squared = stats.pearsonr(R_WT_Zscore, Intersections_WT_Zscore)
# print r_squared
#
# print ' FLX R X Intersections'
# r_squared = stats.pearsonr(R_FLX_Zscore, Intersections_FLX_Zscore)
# print r_squared
#
# print ' WT R X SegNum'
# r_squared = stats.pearsonr(R_WT_Zscore, SegNum_WT_Zscore)
# print r_squared
#
# print ' FLX R X SegNum'
# r_squared = stats.pearsonr(R_FLX_Zscore, SegNum_FLX_Zscore)
# print r_squared
#
# print ' WT SegNum X Intersections'
# r_squared = stats.pearsonr(SegNum_WT_Zscore, Intersections_WT_Zscore)
# print r_squared
#
# print ' FLX SegNum X Intersections'
# r_squared = stats.pearsonr(SegNum_FLX_Zscore, Intersections_FLX_Zscore)
# print r_squared
# ### End correlation code ###

##### Begin lateralization calculator testing code. This measure was useful once but has more or less been replaced
#### by radial sholl which is more detailed and can also be manipulated easily to make this type of course measurement.

# from RFTDT_AnnotationReaderXML import *
# from LateralizationCalculator import *
# file_location = raw_input("Input data path.")
# os.chdir(file_location)
# annotation_files = annotation_finder(file_location)
#
# for annotation_file in annotation_files:
#
#
#     nodes, edges = annotation_parser(annotation_file)
#
#     trans_node_locs = []
#
#     #Start by finding the paths and getting the coordinates for each node in the paths
#     #This will allow you to plot without having lines between the last node of each tree and the first
#     #node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
#     # nodes, edges = annotation_parser(annotation_file)
#
#     node_locations = node_location_finder(nodes, edges)
#
#     source_target_dict = source_target(edges)
#
#     source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
#     target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
#     combined_node_pairs = source_target_pairs + target_source_pairs
#     target_nodes = [pair[0] for pair in combined_node_pairs]
#     source_nodes = [pair[1] for pair in combined_node_pairs]
#     combined_source_targets_flat = target_nodes + source_nodes
#     unique_nodes_set = set(combined_source_targets_flat)
#     unique_nodes = list(unique_nodes_set)
#
#     node_id_list = [node.attrib['id'] for node in nodes]
#     tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
#     # print len(tip_list)
#     radii_list = [node.attrib['radius'] for node in nodes]
#     soma_node = node_id_list[radii_list.index(max(radii_list))]
#     node_location = node_location_finder(nodes, edges)
#     soma_location = [item for item in node_locations if item[0] == soma_node]
#
#     #Start by finding the lateral indicator node, the apical indicator node and the soma node
#     #also get the nodes only in the tree (i.e not the apical and lateral nodes)
#     #including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
#     node_id_list = [node.attrib['id'] for node in nodes]
#     radii_list = [node.attrib['radius'] for node in nodes]
#     lateral_node = node_id_list[radii_list.index('5.5')]
#     lateral_node_list = [lateral_node]
#     apical_node = node_id_list[radii_list.index('5')]
#     radii_list.remove('5')
#     radii_list.remove('5.5')
#     soma_node = node_id_list[radii_list.index(max(radii_list))]
#     radii_list.remove(max(radii_list))
#     tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
#     tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
#     int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]
#
#     #get branching nodes and tips
#     branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
#     branch_node_tips = branch_node_list + tip_list
#     branch_node_tips.remove(lateral_node_list[0])
#     int_branch_node_tips = [int(node) for node in branch_node_tips]
#     print int_branch_node_tips
#
#     #special node locations (soma, apical, lateral)
#     apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
#     apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
#     apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
#     apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
#     lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
#     lateral_x = [int(node.attrib['x']) for node in lateral_attribs][0]
#     lateral_y = [int(node.attrib['y']) for node in lateral_attribs][0]
#     lateral_z = [int(node.attrib['z']) for node in lateral_attribs][0]
#     soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
#     soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
#     soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
#     soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
#     #Translate apical node the distances required for soma to be a 0,0,0
#     trans_apical_x = (apical_x - soma_x)
#     trans_apical_y = (apical_y - soma_y)
#     trans_apical_z = (apical_z - soma_z)
#     #Translate lateral node the distances required for soma to be 0,0,0
#     trans_lateral_x = (lateral_x - soma_x)
#     trans_lateral_y = (lateral_y - soma_y)
#     trans_lateral_z = (lateral_z - soma_z)
#
#
#
#     #define original vector as that of the sapical dendrite
#     apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])
#
#     # Compute the rotation matrix
#     R = get_rotation_matrix(apicalv)
#
#     # Apply the rotation matrix to the apical vector
#     newv = np.dot(apicalv.T, R.T)
#
#     #make and rotate the lateral node vector
#     latv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
#     new_latv = np.dot(latv.T,R.T)
#     # print new_latv
#
#     matches = [item for item in node_location if item[0] in branch_node_tips]
#
#     int_matches = [[int(coordinate) for coordinate in match] for match in matches]
#
#         #Apply the rotation matrix to tip-soma vector
#
#     for node in int_tree_node_locations:
#         branchv = np.array([node[1]-soma_x, node[2]-soma_y, node[3]-soma_z])
#         # print branchv
#
#         new_node = np.dot(branchv.T,R.T)
#
#         # adds all the translated nodes to a list
#         if new_latv[0] > 0:
#             trans_node_locs.append([node[0], new_node[0], -(new_node[1]), new_node[2]])
#         else:
#             trans_node_locs.append([node[0], new_node[0], new_node[1], new_node[2]])
#     # print trans_node_locs
#
#
#     #find segments
#     segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in
#                     branch_node_tips]
#     segment_list = [segment for segment in segment_list if segment is not None]
#     segment_list = [segment for segment in segment_list if len(segment) > 1]
#
#
#     medial_branch_nodes = [node[0] for node in  trans_node_locs if node[1] < 0 and node[0] in int_branch_node_tips]
#     lateral_branch_nodes = [node[0] for node in  trans_node_locs if node[1] > 0 and node[0] in int_branch_node_tips]
#
#     segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in branch_node_tips]
#     segment_list = [segment for segment in segment_list if segment is not None]
#     segment_list = [segment for segment in segment_list if len(segment) > 1]
#
#     unique_segment_list1 = []
#     for segment in segment_list:
#         # print segment
#         branch_node_tip_found = 0
#         for node in branch_node_tips:
#             if node in segment[1:-1]:
#                 branch_node_tip_found = 1
#         if branch_node_tip_found == 0:
#             unique_segment_list1.append(segment)
#
#             #
#             # print unique_segment_list1
#     unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
#     unique_segment_list = [list(item) for item in unique_segment_list]
#     # print len(unique_segment_list)
#
#     real_segments = []
#     for match in unique_segment_list:
#         segment_found = 0
#         for segment in unique_segment_list1:
#             if segment_found == 0:
#                 segment_set = set(segment)
#                 match_set = set(match)
#                 if segment_set == match_set:
#                     real_segments.append(segment)
#                     segment_found = 1
#     unique_segment_list = real_segments
#
#     int_segment_list = [[int(coordinate) for coordinate in segment] for segment in unique_segment_list]
#
#
#     #Reverse lines so that '1' is never the first node in order to make sorting much easier
#     ordered_int_segments = []
#     for segment in int_segment_list:
#         if segment[0] == 1:
#             ordered_int_segments.append(segment[::-1])
#         else:
#             ordered_int_segments.append(segment)
#
#     #divide up segments by whether their branch node is ont the positive or negative side.
#     #NOTE: this code considers a branch to be in whichever side it starts in.
#     medial_segments = [segment for segment in ordered_int_segments if segment[0] in medial_branch_nodes]
#     medial_segments_list = [[str(node) for node in segment] for segment in medial_segments]
#     lateral_segments = [segment for segment in ordered_int_segments if segment[0] in lateral_branch_nodes]
#     lateral_segments_list = [[str(node) for node in segment] for segment in lateral_segments]
#
#     #caluclate the branch number index value
#     medial_branch_number = len(medial_branch_nodes)
#     lateral_branch_number =  len(lateral_branch_nodes)
#     branch_number = (medial_branch_number + lateral_branch_number)
#
#
#     #calculate the segment length for both positive and negative branches
#     node_location = node_location_finder(nodes, edges)
#     medial_segment_lengths = []
#     for segment in range(0, len(medial_segments_list)):
#         matches = [item for item in node_location if item[0] in medial_segments_list[segment]]
#         # print matches
#         if matches == []:
#             medial_segment_lengths.append(0)
#         else:
#             matches_nodes = [match[0] for match in matches]
#             matches_index = [medial_segments_list[segment].index(node) for node in matches_nodes]
#             sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
#             int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
#             # print sorted_matches
#
#
#             interpoint_distance = 0
#             for match in range(0, len(int_matches) - 1):
#                 interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
#                                                                                int_matches[match + 1][1:4])
#             # print int_matches[match][1:4]
#             medial_segment_lengths.append(interpoint_distance)
#
#     medial_segment_lengths = set(medial_segment_lengths)
#     medseg_total_length = sum(medial_segment_lengths)
#     print medseg_total_length
#
#     lateral_segment_lengths = []
#     for segment in range(0, len(lateral_segments_list)):
#         matches = [item for item in node_location if item[0] in lateral_segments_list[segment]]
#         # print matches
#         if matches == []:
#             lateral_segment_lengths.append(0)
#         else:
#             matches_nodes = [match[0] for match in matches]
#             matches_index = [lateral_segments_list[segment].index(node) for node in matches_nodes]
#             sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
#             int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
#             # print sorted_matches
#
#
#             interpoint_distance = 0
#             for match in range(0, len(int_matches) - 1):
#                 interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
#                                                                                int_matches[match + 1][1:4])
#             # print int_matches[match][1:4]
#             lateral_segment_lengths.append(interpoint_distance)
#
#     lateral_segment_lengths = set(lateral_segment_lengths)
#     latseg_total_length = sum(lateral_segment_lengths)
#     print latseg_total_length
#     print type(latseg_total_length)
#
#
#
#
#     #TIP BASED MEASURE
#     #Apply the rotation matrix to tip-soma vector for each path
#     #Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
#     #This is so that the rotation can be applied and simple +/- integer used to determine lateral position
#     trans_tips = []
#
#     matches = [item for item in node_location if item[0] in tip_list]
#     int_matches = [[int(coordinate) for coordinate in match] for match in matches]
#
#     for match in int_matches:
#         tipv = np.array([match[1]-soma_x, match[2]-soma_y, match[3]- soma_z])
#         newtip = np.dot(tipv.T,R.T)
#
#         if new_latv[0] > 0:
#             trans_tips.append(-newtip[1])
#         else:
#             trans_tips.append(newtip[0])
#
#
#     # find tips that are on each side of the soma
#     medial_tips = [tip for tip in trans_tips if tip < 0 ]
#     lateral_tips = [tip for tip in trans_tips if tip > 0 ]
#
#     # count number of tips on right and left of soma and count total number of tips
#     med_tip_num = len(medial_tips)
#     print med_tip_num
#     lat_tip_num =  len(lateral_tips)
#     print lat_tip_num
#     print type(lat_tip_num)

##### End Lateralizatoin calculator. (course measure that has more or less been phased out)

# # def directionality(source_target_dict, nodes, edges):
# from RFTDT_AnnotationReaderXML import *
# from LateralizationCalculator import *
# file_location = raw_input("Input data path.")
# os.chdir(file_location)
# annotation_files = annotation_finder(file_location)
#
# for annotation_file in annotation_files:
#
#
#     nodes, edges = annotation_parser(annotation_file)
#
#     trans_node_locs = []
#
#
# # Start by finding the paths and getting the coordinates for each node in the paths
# # This will allow you to plot without having lines between the last node of each tree and the first
# # node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
# # nodes, edges = annotation_parser(annotation_file)
#
# node_locations = node_location_finder(nodes, edges)
#
# source_target_dict = source_target(edges)
#
# source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
# target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
# combined_node_pairs = source_target_pairs + target_source_pairs
# target_nodes = [pair[0] for pair in combined_node_pairs]
# source_nodes = [pair[1] for pair in combined_node_pairs]
# combined_source_targets_flat = target_nodes + source_nodes
# unique_nodes_set = set(combined_source_targets_flat)
# unique_nodes = list(unique_nodes_set)
#
# node_id_list = [node.attrib['id'] for node in nodes]
# tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
# radii_list = [node.attrib['radius'] for node in nodes]
# soma_node = node_id_list[radii_list.index(max(radii_list))]
# node_location = node_location_finder(nodes, edges)
# soma_location = [item for item in node_locations if item[0] == soma_node]
#
# # Start by finding the lateral indicator node, the apical indicator node and the soma node
# # also get the nodes only in the tree (i.e not the apical and lateral nodes)
# # including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
# node_id_list = [node.attrib['id'] for node in nodes]
# radii_list = [node.attrib['radius'] for node in nodes]
# lateral_node = node_id_list[radii_list.index('5.5')]
# lateral_node_list = [lateral_node]
# apical_node = node_id_list[radii_list.index('5')]
# radii_list.remove('5')
# radii_list.remove('5.5')
# soma_node = node_id_list[radii_list.index(max(radii_list))]
# radii_list.remove(max(radii_list))
# tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
# tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
# int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]
#
# # get branching nodes and tips
# branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
# branch_node_tips = branch_node_list + tip_list
# branch_node_tips.remove(lateral_node_list[0])
# int_branch_node_tips = [int(node) for node in branch_node_tips]
#
# # special node locations (soma, apical, lateral)
# apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
# apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
# apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
# apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
# lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
# lateral_x = np.int16([node.attrib['x'] for node in lateral_attribs])
# lateral_y = np.int16([node.attrib['y'] for node in lateral_attribs])
# lateral_z = np.int16([node.attrib['z'] for node in lateral_attribs])
# soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
# soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
# soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
# soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
# # Translate apical node the distances required for soma to be a 0,0,0
# trans_apical_x = (apical_x - soma_x)
# trans_apical_y = (apical_y - soma_y)
# trans_apical_z = (apical_z - soma_z)
#
# # Translate lateral indicator node the distances required for soma to be 0,0,0
# trans_lateral_x = (lateral_x - soma_x)
# trans_lateral_y = (lateral_y - soma_y)
# trans_lateral_z = (lateral_z - soma_z)
#
# # remove the lateral node so that it isn't counted as a tip/path/vector
# node_id_list = [node.attrib['id'] for node in nodes]
# tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
# tip_list.remove(lateral_node_list[0])
#
# # define original vector as that of the sapical dendrite
# apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])
#
# # Compute the rotation matrix
# R = get_rotation_matrix(apicalv)
#
# # Apply the rotation matrix to the apical vector
# newv = np.dot(apicalv.T, R.T)
#
# # roate the lateral vector to be in register with rotated cell
# lateralv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
# newlatv = np.dot(lateralv.T, R.T)
# newlatv_a_l = [[coordinate for coordinate in vector] for vector in newlatv]
# newlatv_int = [int(coord) for coord in newlatv_a_l[0]]
#
# newlatv_coords = []
# # flip lateral vector if it is on the wrong side
# if newlatv_int[0] < 1:
#     newlatv_coords.append((newlatv_int[0], newlatv_int[1], newlatv_int[2]))
# else:
#     newlatv_coords.append((-newlatv_int[0], newlatv_int[1], newlatv_int[2]))
#
# # Apply the rotation matrix to tip-soma vector for each path
# # Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
# # This is so that the rotation can be applied and simple +/- integer used to determine lateral position
# trans_tips = []
#
# matches = [item for item in node_location if item[0] in tip_list]
# int_matches = [[int(coordinate) for coordinate in match] for match in matches]
#
# for match in int_matches:
#     tipv = np.array([match[1] - soma_x, match[2] - soma_y, match[3] - soma_z])
#     newtip = np.dot(tipv.T, R.T)
#
#     trans_tips.append([match[0], newtip[0], newtip[1], newtip[2]])
#     # print trans_tips
#
# trans_tips_int = [[int(coords) for coords in tip] for tip in trans_tips]
# # print trans_tips_int
# # Flip the cells so that the lateral side is on the left, if necessary
# flipped_tips = []
# for tip in trans_tips_int:
#     if newlatv_int[0] < 1:
#         flipped_tips.append((tip[0], tip[1], tip[2], tip[3]))
#     else:
#         flipped_tips.append((tip[0], -tip[1], tip[2], tip[3]))
#
# # print flipped_tips
#
# # find tips that are on each side of the soma
# negative_tips = [tip[0] for tip in flipped_tips if tip[1] < 0]
# positive_tips = [tip[0] for tip in flipped_tips if tip[1] > 0]
# # print negative_tips
# # print positive_tips
#
# # find the distance from the soma (0,0,0) and each tip (radius)
# # Because the soma is always at (0,0,0), we can omit the subtraction present in the standard distance formula
#
# distance = []
# for tip in flipped_tips:
#     distance.append(np.sqrt(tip[1] ** 2 + tip[2] ** 2))
# # print distance
#
# # make unit vectors for all the vectors
# # start with apical vector
# apical_mag = math.sqrt(newv[0] ** 2 + newv[1] ** 2)
# unit_apicalv = (newv[0] / apical_mag, newv[1] / apical_mag)
#
# unit_tip_vectors = []
# for tip in flipped_tips:
#     tip_mag = math.sqrt(tip[1] ** 2 + tip[2] ** 2)
#     unit_tip_vectors.append((tip[0], tip[1] / tip_mag, tip[2] / tip_mag))
#
#
# # find the angle between the apical vector and the vector that defines each path (soma to tip only)
# # return both the tip index (used later) and the angle in degrees.
# tip_angle = []
# for vector in unit_tip_vectors:
#     # tip_coords = np.array(tip[1:4])
#     v1_u = unit_apicalv
#     v2_u = vector[1:3]
#     tip_angle.append([vector[0], np.degrees(np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0)))])
# print tip_angle
#
# # correct the calculated angle by converting to 360 coordinates. The original calculation gives the smallest
# # angle between apical and tip (all <180), so add 180 to all "negative" tips to make 360 coordinates
# # "negative" tips were chosen as a convention. Either "negative" or "positive" could be used at users desire
#
# angles_180 = [pair[1] for pair in tip_angle]
# print angles_180
#
# angles_360 = []
# for tip in tip_angle:
#     if tip[0] in positive_tips:
#         angles_360.append((360 - tip[1]))
#
#     else:
#         angles_360.append(tip[1])
#
#
#
# ## Calculate the length of the mean vector of the tips. Based on Batchelet 1981 bood Eq. 1.3.7-1.3.9 see ex. 1.3.2
# ## IMPORTANT: THIS VERSION USES LENGTH 1 FOR ALL PATHS (i.e. this is not weigthed by path lenght)
#
# # calculate X and y
# cos_angles_360 = [math.cos(math.radians(angle)) for angle in angles_360]
# # print cos_angles_360
# sum_cos = sum(cos_angles_360)
# sin_angles_360 = [math.sin(math.radians(angle)) for angle in angles_360]
# sum_sin = sum(sin_angles_360)
# x_bar = (sum_cos / len(angles_360))
# y_bar = (sum_sin / len(angles_360))
#
# # angles * 2
# cos_angles_180 = [math.cos(math.radians(angle * 2)) for angle in angles_180]
# sum_cos = sum(cos_angles_180)
# sin_angles_180 = [math.sin(math.radians(angle * 2)) for angle in angles_180]
# sum_sin = sum(sin_angles_180)
# x_bar_2 = (sum_cos / len(angles_180))
# y_bar_2 = (sum_sin / len(angles_180))
#
# # calculate r, the length of the mean vector on unit circle
# r = ((x_bar ** 2) + (y_bar ** 2)) ** 0.5
# r2 = ((x_bar_2 ** 2) + (y_bar_2 ** 2)) ** 0.5
#
# # print r
# print r2
# # print type(r)
# # calucalte the angle of the mean vector
# mean_vector_angle_r = []
# if x_bar > 0:
#     mean_vector_angle_r.append(str(np.degrees(np.arctan(y_bar / x_bar))))
# else:
#     mean_vector_angle_r.append((str(np.degrees(np.arctan(y_bar / x_bar)) + 180)))
#
# mean_vector_angle_r2 = []
# if x_bar_2 > 0:
#     mean_vector_angle_r2.append(str(np.degrees(np.arctan(y_bar_2 / x_bar_2))))
# else:
#     mean_vector_angle_r2.append((str(np.degrees(np.arctan(y_bar_2 / x_bar_2)) + 180)))
#
# mean_vector_angle_r = [float(item) for item in mean_vector_angle_r]
# mean_vector_angle_r2 = [float(item) for item in mean_vector_angle_r2]
#
# angle_r = []
# if mean_vector_angle_r[0] < 0:
#     angle_r.append([360 + mean_vector_angle_r[0]])
# else:
#     angle_r.append(mean_vector_angle_r)
#
# angle_r2 = []
# if mean_vector_angle_r2[0] < 0:
#     angle_r2.append([180 + mean_vector_angle_r2[0]])
# else:
#     angle_r2.append(mean_vector_angle_r2)
#
# angle_r_flat = [item[0] for item in angle_r]
# angle_r2_flat = [item[0] for item in angle_r2]
# angle_r = angle_r_flat[0] *1
# angle_r2 = angle_r2_flat[0] * 1
# # print angle_r
# print angle_r2
#
#
#
# # calculate test statistic
# n = len(angles_360)
# z = (n * (r ** 2))
# z2 = (n * (r2 ** 2))
# # print n
# # print z
# print z2
#
# return r, angle_r, z, r2, angle_r2, z2


import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *
import pandas as pd

# file_location = raw_input("Input data path.")
# os.chdir(file_location)
# values = pd.read_csv("TimeLineCSV2.csv")
#
# print values

values = np.array([[0.409638554,	0.469879518,	0.506024096,	0.831325301,	0.855421687,	1.204819277,	1.012048193,	1.253012048,	1.590361446,	1.638554217,	1.662650602,	1.65060241,	1.56626506,	1.578313253,	1.481927711,	1.445783133,	1.481927711,	1.084337349,	1.012048193,	1.024096386,	0.855421687,	0.602409639,	0.662650602,	0.337349398],
    [0.423913043,	0.543478261,	0.576086957,	1.097826087,	1.380434783,	1.413043478,	1.717391304,	1.467391304,	1.217391304,	1.239130435,	1.72826087,	1.239130435,	1.641304348,	1.380434783,	1.586956522,	1.717391304,	1.641304348,	1.423913043,	1.22826087,	0.804347826,	1.043478261,	0.608695652,	0.586956522,	0.456521739]])



fig, ax = plot.subplots()
im = ax.imshow(values,interpolation='none',cmap="jet")

plot.show()
