import math
import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *
from Tree_Database_Queries import dev_graphs

TreeLen_WTTR_P7_values, TreeLen_WTTR_P12_values, TreeLen_WTTR_P16_values, TreeLen_WTTR_P21_values, TreeLen_WTTR_P30_values, \
TreeLen_KOTR_P7_values, TreeLen_KOTR_P12_values, TreeLen_KOTR_P16_values, TreeLen_KOTR_P21_values, TreeLen_KOTR_P30_values = dev_graphs('tree_len')

SegLen_WTTR_P7_values, SegLen_WTTR_P12_values, SegLen_WTTR_P16_values, SegLen_WTTR_P21_values, SegLen_WTTR_P30_values, \
SegLen_KOTR_P7_values, SegLen_KOTR_P12_values, SegLen_KOTR_P16_values, SegLen_KOTR_P21_values, SegLen_KOTR_P30_values = dev_graphs('mean_branch_length')

SegNum_WTTR_P7_values, SegNum_WTTR_P12_values, SegNum_WTTR_P16_values, SegNum_WTTR_P21_values, SegNum_WTTR_P30_values, \
SegNum_KOTR_P7_values, SegNum_KOTR_P12_values, SegNum_KOTR_P16_values, SegNum_KOTR_P21_values, SegNum_KOTR_P30_values = dev_graphs('branch_number')

PathLen_WTTR_P7_values, PathLen_WTTR_P12_values, PathLen_WTTR_P16_values, PathLen_WTTR_P21_values, PathLen_WTTR_P30_values, \
PathLen_KOTR_P7_values, PathLen_KOTR_P12_values, PathLen_KOTR_P16_values, PathLen_KOTR_P21_values, PathLen_KOTR_P30_values = dev_graphs('mean_path_length')

TipNum_WTTR_P7_values, TipNum_WTTR_P12_values, TipNum_WTTR_P16_values, TipNum_WTTR_P21_values, TipNum_WTTR_P30_values, \
TipNum_KOTR_P7_values, TipNum_KOTR_P12_values, TipNum_KOTR_P16_values, TipNum_KOTR_P21_values, TipNum_KOTR_P30_values = dev_graphs('tip_number')

Tort_WTTR_P7_values, Tort_WTTR_P12_values, Tort_WTTR_P16_values, Tort_WTTR_P21_values, Tort_WTTR_P30_values, \
Tort_KOTR_P7_values, Tort_KOTR_P12_values, Tort_KOTR_P16_values, Tort_KOTR_P21_values, Tort_KOTR_P30_values = dev_graphs('mean_tortuosity')

#Make Blank Figure
fig,axs = plot.subplots(nrows=5, ncols=3, sharex=False, sharey='row')

# #Plot Tree Length by Branch Number.
# #Colorcoded by Age
# #WT
# ax=axs[0,0]
# ax.scatter(TreeLen_WTTR_P7_values,SegNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,SegNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,SegNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,SegNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,SegNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('SegNum')
#
# #KO
# ax=axs[0,2]
# ax.scatter(TreeLen_WTTR_P7_values,SegNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,SegNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,SegNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,SegNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,SegNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(TreeLen_KOTR_P7_values,SegNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,SegNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,SegNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,SegNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,SegNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('SegNum')
#
# #WT and KO
# ax=axs[0,1]
# ax.scatter(TreeLen_KOTR_P7_values,SegNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,SegNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,SegNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,SegNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,SegNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('SegNum')
#
#
#
# #Plot Tree Length by Branch_Length.
# #Colorcoded by Age
# #WT
# ax=axs[1,0]
# ax.scatter(TreeLen_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('SegLen')
#
# #KO
# ax=axs[1,1]
# ax.scatter(TreeLen_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('SegLen')
#
# #Wt and KO Data
# ax=axs[1,2]
# ax.scatter(TreeLen_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(TreeLen_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('SegLen')
#
# #Plot Tree Length by Path Length
# #Colorcoded by Age
# #WT
# ax=axs[2,0]
# ax.scatter(TreeLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('PathLen')
#
# #KO
# ax=axs[2,1]
# ax.scatter(TreeLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('PathLen')
#
# #Wt and KO Data
# ax=axs[2,2]
# ax.scatter(TreeLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(TreeLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('PathLen')
#
# #Plot Tree Length by Tip number
# #WT
# ax=axs[3,0]
# ax.scatter(TreeLen_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('TipNum')
#
# #KO
# ax=axs[3,1]
# ax.scatter(TreeLen_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('TipNum')
#
# #Wt and KO Data
# ax=axs[3,2]
# ax.scatter(TreeLen_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(TreeLen_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('TipNum')
#
# #Plot Tree Length by Tortuosity
# #WT
# ax=axs[4,0]
# ax.scatter(TreeLen_WTTR_P7_values,Tort_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,Tort_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,Tort_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,Tort_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,Tort_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('Tort')
#
# #KO
# ax=axs[4,1]
# ax.scatter(TreeLen_KOTR_P7_values,Tort_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,Tort_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,Tort_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,Tort_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,Tort_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('Tort')
#
# #Wt and KO Data
# ax=axs[4,2]
# ax.scatter(TreeLen_WTTR_P7_values,Tort_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P12_values,Tort_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P16_values,Tort_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P21_values,Tort_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_WTTR_P30_values,Tort_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(TreeLen_KOTR_P7_values,Tort_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P12_values,Tort_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P16_values,Tort_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P21_values,Tort_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TreeLen_KOTR_P30_values,Tort_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TreeLen')
# ax.set_ylabel('Tort')

#Plot Branch Number by Tip Number
#WT
ax=axs[0,0]
ax.scatter(SegNum_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('SegNum')
ax.set_ylabel('TipNum')

# #KO
ax=axs[0,1]
ax.scatter(SegNum_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('TipNum')

#Wt and KO Data
ax=axs[0,2]
ax.scatter(SegNum_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(SegNum_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('TipNum')

#Plot Branch Number by Branch Length
#WT
ax=axs[1,0]
ax.scatter(SegNum_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('SegNum')
ax.set_ylabel('SegLen')

#KO
ax=axs[1,1]
ax.scatter(SegNum_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('SegLen')

#Wt and KO Data
ax=axs[1,2]
ax.scatter(SegNum_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(SegNum_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('SegLen')

#Plot Tip Number by Path Length
#WT
ax=axs[2,0]
ax.scatter(TipNum_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('TipNum')
ax.set_ylabel('PathLen')

#KO
ax=axs[2,1]
ax.scatter(TipNum_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('TipNum')
ax.set_ylabel('PathLen')

#Wt and KO Data
ax=axs[2,2]
ax.scatter(TipNum_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(TipNum_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(TipNum_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('TipNum')
ax.set_ylabel('PathLen')

#Plot Path Length by Tortuosity
#WT
ax=axs[3,0]
ax.scatter(Tort_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('Tort')
ax.set_ylabel('PathLen')

#KO
ax=axs[3,1]
ax.scatter(Tort_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('Tort')
ax.set_ylabel('PathLen')

#Wt and KO Data
ax=axs[3,2]
ax.scatter(Tort_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(Tort_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('Tort')
ax.set_ylabel('PathLen')

#Plot Path Length by Segment Length
#WT
ax=axs[4,0]
ax.scatter(SegLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('SegLen')
ax.set_ylabel('PathLen')

#KO
ax=axs[4,1]
ax.scatter(SegLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegLen')
ax.set_ylabel('PathLen')

#Wt and KO Data
ax=axs[4,2]
ax.scatter(SegLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(SegLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegLen')
ax.set_ylabel('PathLen')





plot.show()