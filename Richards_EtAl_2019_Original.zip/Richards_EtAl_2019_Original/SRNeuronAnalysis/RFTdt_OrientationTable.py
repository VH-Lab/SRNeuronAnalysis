import os
import sqlite3
import RFTDT_AnnotationReaderXML
import LateralizationCalculator

connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
# cursor = connection.execute("select * from RFTdt_OriNeurons")
# # for row in cursor:
# #     print row
# # # # # cursor = connection.execute("select * from Neurons")
# # # # cursor = connection.execute("select avg(soma_radius) from Neurons")
# # # #
# # # #
# for row in cursor:
# #      # print row
# #      print 'animal_id', row[0]
#      print 'neuron_id =', row[23]
# #      print 'branch_number_index = ', row[2]
# #      print 'branch_length_index = ', row[3]
# #      print 'tip_number_index = ', row[4]
# # #      print 'arbor_length', row[10]


connection.execute('drop table RFTdt_OriNeurons')
# # #connection.execute('''create table Neurons(animal_id text, neuron_id text primary key,soma_radius real,tree_number int, mean_branch_length real, branch_lengths text, branch_number int, path_lengths text, mean_path_length real,tip_number int);''')
connection.execute('''create table RFTdt_OriNeurons(animal_id text, neuron_id text primary key, branch_number_index real,
branch_length_index real, tip_number_index real, medial_branch_number real, lateral_branch_number real, medseg_total_length real,
latseg_total_length real, med_tip_num real, lat_tip_num real, r real, angle_r real, z real, r2 real, angle_r2 real, z2 real,
xz_r real, xz_angle_r real, xz_z real,xz_r2 real, xz_angle_r2 real, xz_z2 real, num_angles_0_15 real,num_angles_15_30 real,num_angles_30_45 real,
num_angles_45_60 real,num_angles_60_75 real,num_angles_75_90 real,num_angles_90_105 real,num_angles_105_120 real, num_angles_120_135 real,
num_angles_135_150 real,num_angles_150_165 real, num_angles_165_180 real,num_angles_180_195 real,num_angles_195_210 real,num_angles_210_225 real,
num_angles_225_240 real,num_angles_240_255 real,num_angles_255_270 real,num_angles_270_285 real,num_angles_285_300 real,num_angles_300_315 real,
num_angles_315_330 real,num_angles_330_345 real,num_angles_345_360 real,fraction_angles_0_15 real, fraction_angles_15_30 real,fraction_angles_30_45 real,
fraction_angles_45_60 real,fraction_angles_60_75 real,fraction_angles_75_90 real,fraction_angles_90_105 real, fraction_angles_105_120 real, 
fraction_angles_120_135 real,fraction_angles_135_150 real,fraction_angles_150_165 real, fraction_angles_165_180 real,fraction_angles_180_195 real,
fraction_angles_195_210 real,fraction_angles_210_225 real,fraction_angles_225_240 real,fraction_angles_240_255 real,fraction_angles_255_270 real,
fraction_angles_270_285 real, fraction_angles_285_300 real,fraction_angles_300_315 real,fraction_angles_315_330 real,fraction_angles_330_345 real,fraction_angles_345_360 real);''')
#
file_location = raw_input("Input data path.")
os.chdir(file_location)
annotation_files = RFTDT_AnnotationReaderXML.annotation_finder(file_location)


for annotation_file in annotation_files:

    nodes,edges = RFTDT_AnnotationReaderXML.annotation_parser(annotation_file)
    node_locations = RFTDT_AnnotationReaderXML.node_location_finder(nodes, edges)
    source_target_dict = RFTDT_AnnotationReaderXML.source_target(edges)

    animal_id = annotation_file[-29:-21]
    print animal_id

    neuron_id = annotation_file[-29:-14]
    print neuron_id
    branch_number_index, branch_length_index, tip_number_index = LateralizationCalculator.polarity_index(source_target_dict, nodes, edges)

    medial_branch_number, lateral_branch_number, medseg_total_length, latseg_total_length, med_tip_num, lat_tip_num = LateralizationCalculator.polarity_absolute(source_target_dict, nodes, edges)

    r, angle_r, z, r2, angle_r2, z2 = LateralizationCalculator.directionality(source_target_dict, nodes, edges)

    xz_r, xz_angle_r, xz_z, xz_r2, xz_angle_r2, xz_z2 = LateralizationCalculator.xz_directionality(source_target_dict, nodes, edges)

    num_angles_0_15, num_angles_15_30, num_angles_30_45, num_angles_45_60, num_angles_60_75, num_angles_75_90, num_angles_90_105, \
    num_angles_105_120, num_angles_120_135, num_angles_135_150, num_angles_150_165, num_angles_165_180, num_angles_180_195, \
    num_angles_195_210, num_angles_210_225, num_angles_225_240, num_angles_240_255, num_angles_255_270, num_angles_270_285, \
    num_angles_285_300, num_angles_300_315, num_angles_315_330, num_angles_330_345, num_angles_345_360, fraction_angles_0_15, \
    fraction_angles_15_30, fraction_angles_30_45, fraction_angles_45_60, fraction_angles_60_75, fraction_angles_75_90, fraction_angles_90_105, \
    fraction_angles_105_120, fraction_angles_120_135, fraction_angles_135_150, fraction_angles_150_165, fraction_angles_165_180, fraction_angles_180_195, \
    fraction_angles_195_210, fraction_angles_210_225, fraction_angles_225_240, fraction_angles_240_255, fraction_angles_255_270, fraction_angles_270_285, \
    fraction_angles_285_300, fraction_angles_300_315, fraction_angles_315_330, fraction_angles_330_345, fraction_angles_345_360 = LateralizationCalculator.radial_sholl(source_target_dict, nodes, edges)

    # branch_number_index = LateralizationCalculator.branch_polarity_index
    # branch_length_index = seglen_polarity_index
    # tip_number_index = tip_polarity_index

    #connection.execute("insert into Neurons (animal_id,neuron_id,soma_radius,tree_number,mean_branch_length,branch_lengths, branch_number, path_lengths,mean_path_length, tip_number) values(?,?,?,?,?,?,?,?,?,?);",(animal_id,neuron_id,soma_radius, tree_num,mean_branch_length,branch_lengths, branch_num, path_lengths, mean_path_length,tip_num))
    connection.execute("insert into RFTdt_OriNeurons (animal_id,neuron_id,branch_number_index, branch_length_index, "
                       "tip_number_index, medial_branch_number, lateral_branch_number, medseg_total_length, latseg_total_length, "
                       "med_tip_num, lat_tip_num, r, angle_r, z, r2, angle_r2, z2, xz_r, xz_angle_r, xz_z,xz_r2, xz_angle_r2, "
                       "xz_z2, num_angles_0_15,num_angles_15_30,num_angles_30_45,num_angles_45_60,num_angles_60_75,num_angles_75_90,num_angles_90_105,"
                       "num_angles_105_120, num_angles_120_135,num_angles_135_150,num_angles_150_165, num_angles_165_180,num_angles_180_195,"
                       "num_angles_195_210,num_angles_210_225,num_angles_225_240,num_angles_240_255,num_angles_255_270,num_angles_270_285,"
                       "num_angles_285_300,num_angles_300_315,num_angles_315_330,num_angles_330_345,num_angles_345_360,fraction_angles_0_15,"
                       "fraction_angles_15_30,fraction_angles_30_45,fraction_angles_45_60,fraction_angles_60_75,fraction_angles_75_90,fraction_angles_90_105,"
                       "fraction_angles_105_120, fraction_angles_120_135,fraction_angles_135_150,fraction_angles_150_165, fraction_angles_165_180,fraction_angles_180_195,"
                       "fraction_angles_195_210,fraction_angles_210_225,fraction_angles_225_240,fraction_angles_240_255,fraction_angles_255_270,fraction_angles_270_285,"
                       "fraction_angles_285_300,fraction_angles_300_315,fraction_angles_315_330,fraction_angles_330_345,fraction_angles_345_360   ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);",(animal_id,neuron_id,branch_number_index, branch_length_index, tip_number_index, medial_branch_number, lateral_branch_number, medseg_total_length, latseg_total_length, med_tip_num, lat_tip_num, r, angle_r, z, r2, angle_r2, z2, xz_r, xz_angle_r, xz_z,xz_r2, xz_angle_r2, xz_z2, num_angles_0_15,num_angles_15_30,num_angles_30_45,num_angles_45_60,num_angles_60_75,num_angles_75_90,num_angles_90_105,num_angles_105_120, num_angles_120_135,num_angles_135_150,num_angles_150_165, num_angles_165_180,num_angles_180_195,num_angles_195_210,num_angles_210_225,num_angles_225_240,num_angles_240_255,num_angles_255_270,num_angles_270_285,num_angles_285_300,num_angles_300_315,num_angles_315_330,num_angles_330_345,num_angles_345_360,fraction_angles_0_15,fraction_angles_15_30,fraction_angles_30_45,fraction_angles_45_60,fraction_angles_60_75,fraction_angles_75_90,fraction_angles_90_105,fraction_angles_105_120, fraction_angles_120_135,fraction_angles_135_150,fraction_angles_150_165, fraction_angles_165_180,fraction_angles_180_195,fraction_angles_195_210,fraction_angles_210_225,fraction_angles_225_240,fraction_angles_240_255,fraction_angles_255_270,fraction_angles_270_285,fraction_angles_285_300,fraction_angles_300_315,fraction_angles_315_330,fraction_angles_330_345,fraction_angles_345_360))

connection.commit()