import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
# import matplotlib.pyplot as plot
import math
from Database_Queries import recover_graphs
WTTR_values,WTDD_values,WTDL_values,KOTR_values,KODD_values, KODL_values,WTTRM_values,WTTRF_values,WTDDM_values,WTDDF_values,WTDLM_values, WTDLF_values,KOTRM_values,KOTRF_values,KODDM_values,KODDF_values, KODLM_values, KODLF_values = recover_graphs('tip_number')


