import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
from scipy import stats
import math
import sqlite3
import RFTdt_Database_Queries

connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

# #Get info from the database
# WTTR = connection.execute("select branch_lengths fromRFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'")
# WTTR_values = [list(row) for row in WTTR]
# 
# #Get the actual Segments from the database data
# segment_list = []
# for cell in WTTR_values:
#     cell_string = [str(item) for item in cell]
#     cell_split = cell_string[0].split(",")
#     cell_float = [float(item) for item in cell_split]
#     segment_list.append(cell_float)
# 
# 
# #Get the histogram info
# bins = np.linspace(0, 500,500)
# normalized_seg_list = []
# for segment in segment_list:
#     segment_hist = plot.hist(segment, bins, normed=False)
#     bin_values = [item for item in segment_hist[0]]
#     normalized_seg_list.append(bin_values)
# 
# #make it an array
# seg_array = np.array(normalized_seg_list)
# 
# fig,axs = plot.subplots(nrows=3, ncols=3, sharex=True, sharey=True)
# 
# 
# #plot data as is
# # ax =axs[0]
# # ax.imshow(seg_array, cmap='inferno', interpolation='None')
# #
# # #normalize it
# # ax=axs[1]
# # norm_data = (seg_array - np.min(seg_array, axis=1)[:, np.newaxis]) / np.ptp(seg_array, axis=1)[:, np.newaxis]
# # ax.imshow(norm_data, interpolation='none', cmap='inferno')
#
## some other graphs
# 
# ArborLen_WT_12dpi, ArborLen_FLX_12dpi = RFTdt_Database_Queries.length_summary_graphs('12dpi','arbor_length')
# 
# 
# SegLen_WT_12dpi, SegLen_FLX_12dpi = RFTdt_Database_Queries.length_summary_graphs('12dpi', 'mean_branch_length')
# 
# 
# SegNum_WT_12dpi, SegNum_FLX_12dpi = RFTdt_Database_Queries.number_summary_graphs('12dpi','branch_number')
# 
# Direction_WT_12dpi, Direction_FLX_12dpi = RFTdt_Database_Queries.polarity_summary_graphs('12dpi','r')
# 
# 
# # SegNum_WT_12dpi = SegNum_WT_12dpi[0:20]
# 
# # ax =axs[0,0]
# # ax.scatter(stats.zscore(ArborLen_WT_12dpi),stats.zscore(SegLen_WT_12dpi), color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax =axs[0,1]
# # ax.scatter(stats.zscore(ArborLen_WT_12dpi),stats.zscore(SegNum_WT_12dpi), color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax =axs[0,2]
# # ax.scatter(stats.zscore(SegLen_WT_12dpi),stats.zscore(SegNum_WT_12dpi), color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# #
# # ax =axs[1,0]
# # ax.scatter(stats.zscore(ArborLen_FLX_12dpi),stats.zscore(SegLen_FLX_12dpi), color = '#df3325',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax =axs[1,1]
# # ax.scatter(stats.zscore(ArborLen_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi), color = '#df3325',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax =axs[1,2]
# # ax.scatter(stats.zscore(SegLen_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi), color = '#df3325',zorder='2',alpha='0.8',edgecolors='none', s=30)
# #
# # ax =axs[2,0]
# # ax.scatter(stats.zscore(ArborLen_WT_12dpi),stats.zscore(SegLen_WT_12dpi), color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax.scatter(stats.zscore(ArborLen_FLX_12dpi),stats.zscore(SegLen_FLX_12dpi), color = '#df3325',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax =axs[2,1]
# # ax.scatter(stats.zscore(ArborLen_WT_12dpi),stats.zscore(SegNum_WT_12dpi), color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax.scatter(stats.zscore(ArborLen_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi), color = '#df3325',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax =axs[2,0]
# # ax.scatter(stats.zscore(SegLen_WT_12dpi),stats.zscore(SegNum_WT_12dpi), color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# # ax.scatter(stats.zscore(SegLen_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi), color = '#df3325',zorder='2',alpha='0.8',edgecolors='none', s=30)
# 
# ax.scatter(stats.zscore(Direction_WT_12dpi),stats.zscore(SegNum_WT_12dpi), color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# 
# ax =axs[2,1]
# ax.scatter(stats.zscore(Direction_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi), color = '#df3325',zorder='2',alpha='0.8',edgecolors='none', s=30)
# 
# 
# # print 'WT Arbor X SegLen'
# # print stats.pearsonr(stats.zscore(ArborLen_WT_12dpi),stats.zscore(SegLen_WT_12dpi))
# # print 'WT Arbor X SegNum'
# # print stats.pearsonr(stats.zscore(ArborLen_WT_12dpi),stats.zscore(SegNum_WT_12dpi))
# # print 'WT SegLen X SegNum'
# # print stats.pearsonr(stats.zscore(SegLen_WT_12dpi),stats.zscore(SegNum_WT_12dpi))
# print 'WT Direction X SegNum'
# print stats.pearsonr(stats.zscore(Direction_WT_12dpi),stats.zscore(SegNum_WT_12dpi))
# Direction_WT_12dpi = Direction_WT_12dpi[0:20]
# print 'WT Direction X Arbor'
# print stats.pearsonr(stats.zscore(Direction_WT_12dpi),stats.zscore(ArborLen_WT_12dpi))
# print 'WT Direction X SegLen'
# print stats.pearsonr(stats.zscore(Direction_WT_12dpi),stats.zscore(SegLen_WT_12dpi))
# 
# 
# # print 'FLX Arbor X SegLen'
# # print stats.pearsonr(stats.zscore(ArborLen_FLX_12dpi),stats.zscore(SegLen_FLX_12dpi))
# # print 'FLX Arbor X SegNum'
# # print stats.pearsonr(stats.zscore(ArborLen_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi))
# # print 'FLX SegLen X SegNum'
# # print stats.pearsonr(stats.zscore(SegLen_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi))
# print 'FLX Direction X SegNum'
# print stats.pearsonr(stats.zscore(Direction_FLX_12dpi),stats.zscore(SegNum_FLX_12dpi))
# print 'FLX Direction X Arbor'
# print stats.pearsonr(stats.zscore(Direction_FLX_12dpi),stats.zscore(ArborLen_FLX_12dpi))
# print 'FLX Direction X SegLen'
# print stats.pearsonr(stats.zscore(Direction_FLX_12dpi),stats.zscore(SegLen_FLX_12dpi))



### DO NOT ERASE ###
# #This is the percent of ttal trees in each genotype that are in each respective cluster
# ax =axs[0]
# WTTreeClusters= [10.87481875,	17.88303528,	16.81971967,	21.16964717,	19.52634123,0.386660222,	9.521507975,
#                  0.338327695,	1.884968584,	0.241662639,	0.773320445,	0.338327695,	0.241662639]
#
# KOTreeClusters= [10.2464332,	36.61910938,	21.31431042,	17.85559879,	11.2408128,	0.216169477,	0.907911803,
#                 0.172935581,	0.259403372,	0.389105058,	0.216169477,	0.302637268,	0.259403372]
#
# WT_X_values = np.arange(len(WTTreeClusters))
#
# ax.bar(WT_X_values, WTTreeClusters, align='center', alpha=1,color=('#0d0d0d'),linewidth=0)
#
# KO_X_values =  [value + 14 for value in WT_X_values]
# ax.bar(KO_X_values, KOTreeClusters, align='center', alpha=1,color=('#008287'),linewidth=0)
#
# # plot.set_title('WT and KO Density Cluster Results')
# ax.set_ylabel('Percent of total Trees')
#
#
# #Stacked bar plots for WT Data
# ax =axs[1]
# N = 13
# P7 = np.array([9.142857143,	19.42857143,	21.14285714,	20,	21.71428571,	0,	7.428571429, 0, 1.142857143,
#                0,	0,	0,	0])
#
# P12 = np.array([8.374384236,	15.7635468,	18.22660099,	24.63054187,	26.60098522,	0,
#                 5.418719212,	0,	0.492610837,	0,	0.492610837,	0,	0])
#
# P16 = np.array([8.056042032,	16.81260946,	18.21366025,	20.84063047,	21.36602452,	0.700525394,
#                 9.281961471,	0,	1.926444834,	0.525394046,	0.700525394,	1.22591944,	0.350262697])
#
# P21 = np.array([15.78947368,	20.33492823,	14.35406699,	18.66028708,	15.55023923,	0.23923445,	11.24401914,
#                 0.23923445,	2.153110048,	0,	1.435406699,	0,	0])
#
# P30 = ([11.3960114,	17.52136752,	15.66951567,	22.22222222,	17.80626781,	0.427350427,	10.3988604,
#        0.854700855,	2.279202279,	0.284900285,	0.712250712,	0,	0.427350427])
#
# ind = np.arange(N)    # the x locations for the groups
# width = 0.35       # the width of the bars: can also be len(x) sequence
#
# ax.bar(ind, P7, width, color='#B4B4B4')
# ax.bar(ind, P12, width,bottom=P7, color='#838383')
# ax.bar(ind, P16, width,bottom=P7+P12, color = '#5B5B5B')
# ax.bar(ind, P21, width,bottom=P7+P12+P16, color = '#343434')
# ax.bar(ind, P30, width,bottom=P7+P12+P16+P21, color = '#0D0D0D')
#
#
# #Stacked bar plots for KO Data
# ax =axs[2]
# N = 13
# P7 = np.array([4.827586207,	37.93103448,	28.27586207,	17.93103448,	7.586206897,	0.689655172,	1.379310345,
#                0,	0.689655172,	0.689655172,	0,	0,	0])
#
# P12 = np.array([5.245901639,	42.29508197,	24.26229508,	17.70491803,	8.524590164,	0.655737705,
#                 0.655737705,	0,	0,	0.655737705,	0,	0,	0])
#
# P16 = np.array([9.530201342,	36.37583893,	21.74496644,	19.19463087,	10.87248322,	0.268456376,
#                 0.536912752,	0.134228188,	0.134228188,	0.268456376,	0.67114094,	0.268456376,	0])
#
# P21 = np.array([12.9707113,	36.82008368,	14.43514644,	17.15481172,	13.59832636,	0,	2.092050209,
#                 0.418410042,	0.627615063,	0.836820084,	0,	0.418410042,	0.627615063])
#
# P30 = ([12.65625,	33.75,	22.96875,	16.875,	12.03125,	0,	0.46875,	0.15625,	0.15625,	0,	0,	0.4687,
#        0.46875])
#
# ind = np.arange(N)    # the x locations for the groups
# width = 0.35       # the width of the bars: can also be len(x) sequence
#
# ax.bar(ind, P7, width, color='#C2DCDE')
# ax.bar(ind, P12, width,bottom=P7, color='#6DB7BA')
# ax.bar(ind, P16, width,bottom=P7+P12, color = '#289498')
# ax.bar(ind, P21, width,bottom=P7+P12+P16, color = '#008287')
# ax.bar(ind, P30, width,bottom=P7+P12+P16+P21, color = '#025F64')

# #test out cone/polarity graphs
#
# Libraries
# import matplotlib.pyplot as plt
# import pandas as pd
# from math import pi
#
# # Set data
# df = pd.DataFrame({
#     'group': ['cell1','cell2','cell3','cell4','cell5' 'cell6','cell7','cell8','cell9','cell10','cell11','cell12','cell13','cell14','cell15','cell16','cell17','cell18','cell19','cell20','cell21','cell22','cell23','cell24','cell25','cell26','cell27','cell28','cell29','cell30','cell31','cell32','cell33','cell34','cell35','cell36','cell37','cell38','cell39','cell40','cell41','cell42','cell43','cell44','cell45','cell46','cell47','cell48','cell49','cell50','cell51','cell52','cell53','cell54','cell55','cell56','cell57','cell58','cell59','cell60','cell61','cell62','cell63','cell64','cell65','cell66','cell67','cell68','cell69','cell70','cell71','cell72','cell73','cell74','cell75','cell76'],
#     '0': [1,	0,	0,	0,	1,	0,	0,	0,	0,	0,	0,	0,	1,	1,	0,	0,	0,	0,	1,	0,	1,	1,	0,	1,	0,	1,	0,	0,	0,	0,	0,	1,	1,	0,	1,	1,	0,	0,	0,	1,	1,	1,	0,	0,	0,	1,	1,	0,	0,	0,	0,	0,	0,	1,	1,	0,	1,	1,	0,	2,	0,	1,	2,	2,	0,	0,	2,	0,	0,	1,	0,	0,	0,	1,	0],
#     '15': [0,	1,	0,	0,	0,	2,	0,	0,	0,	0,	0,	1,	0,	0,	0,	0,	0,	0,	0,	0,	1,	1,	0,	0,	0,	1,	0,	0,	0,	0,	1,	0,	0,	1,	2,	1,	0,	0,	0,	2,	2,	0,	3,	1,	3,	0,	0,	0,	0,	0,	2,	1,	0,	0,	0,	0,	0,	0,	1,	1,	0,	0,	0,	0,	1,	0,	2,	1,	1,	0,	1,	0,	1,	1,	0],
#     '30': [1,	0,	0,	0,	1,	0,	0,	0,	1,	0,	0,	1,	3,	2,	1,	0,	0,	0,	2,	0,	0,	0,	0,	1,	0,	1,	0,	0,	1,	0,	0,	0,	2,	0,	0,	0,	0,	3,	1,	0,	0,	0,	0,	0,	1,	0,	1,	1,	1,	1,	0,	1,	0,	0,	0,	1,	0,	1,	0,	0,	0,	2,	0,	0,	0,	0,	2,	1,	0,	0,	1,	0,	1,	0,	1],
#     '45': [1,	0,	0,	1,	1,	0,	2,	0,	3,	0,	0,	1,	2,	0,	2,	3,	1,	0,	2,	0,	2,	1,	1,	2,	1,	1,	0,	1,	1,	0,	2,	0,	0,	0,	0,	1,	0,	0,	1,	2,	0,	0,	1,	0,	2,	2,	0,	1,	0,	1,	2,	0,	0,	0,	1,	0,	3,	2,	0,	1,	1,	1,	0,	0,	0,	2,	1,	4,	0,	1,	1,	1,	1,	2,	0],
#     '60': [3,	0,	0,	1,	0,	0,	2,	1,	0,	4,	2,	0,	2,	2,	0,	2,	0,	0,	1,	1,	0,	1,	1,	0,	0,	1,	0,	0,	0,	1,	2,	0,	1,	2,	0,	1,	0,	1,	0,	3,	0,	1,	1,	1,	0,	1,	0,	1,	2,	0,	0,	0,	1,	0,	0,	0,	2,	1,	1,	1,	1,	2,	3,	3,	1,	2,	2,	1,	0,	1,	0,	0,	0,	0,	0],
#     '75': [0,	1,	1,	1,	0,	1,	2,	0,	2,	2,	0,	1,	2,	0,	0,	1,	1,	2,	2,	0,	1,	1,	2,	1,	1,	2,	2,	1,	1,	0,	1,	1,	1,	1,	1,	1,	1,	0,	0,	1,	0,	1,	2,	1,	1,	2,	0,	0,	2,	2,	3,	1,	0,	0,	2,	1,	1,	1,	0,	2,	2,	1,	1,	3,	1,	3,	2,	2,	2,	3,	3,	1,	1,	2,	1],
#     '90': [2,	1,	0,	2,	1,	0,	1,	1,	1,	1,	0,	0,	0,	0,	2,	2,	3,	2,	1,	1,	1,	1,	0,	2,	0,	1,	0,	1,	0,	0,	3,	0,	0,	0,	0,	1,	1,	2,	1,	1,	2,	1,	2,	0,	1,	0,	0,	0,	1,	1,	1,	4,	1,	2,	0,	1,	1,	3,	1,	0,	0,	0,	2,	1,	0,	2,	2,	1,	1,	1,	2,	0,	1,	2,	1],
#     '105': [0,	2,	0,	0,	0,	0,	1,	0,	2,	3,	1,	2,	2,	2,	1,	1,	2,	1,	0,	1,	1,	2,	2,	3,	2,	4,	2,	0,	0,	2,	2,	2,	0,	1,	1,	1,	1,	3,	1,	1,	1,	1,	1,	3,	1,	2,	0,	0,	2,	1,	2,	1,	1,	1,	1,	1,	0,	2,	0,	0,	2,	1,	2,	0,	2,	0,	3,	4,	1,	0,	0,	0,	1,	2,	0],
#     '120': [1,	0,	3,	1,	4,	1,	1,	1,	2,	1,	1,	0,	1,	0,	1,	3,	3,	0,	1,	3,	1,	4,	0,	4,	4,	1,	3,	2,	1,	1,	1,	1,	1,	2,	1,	2,	2,	3,	3,	1,	4,	1,	1,	2,	0,	0,	0,	1,	2,	1,	3,	3,	1,	2,	1,	1,	1,	0,	0,	1,	0,	3,	1,	0,	0,	1,	2,	4,	2,	3,	1,	2,	1,	0,	1],
#     '135': [0, 1,	2,	0,	2,	1,	1,	2,	3,	0,	3,	3,	3,	0,	0,	3,	1,	1,	1,	1,	3,	2,	2,	3,	2,	2,	1,	3,	2,	2,	0,	0,	1,	0,	3,	1,	0,	1,	0,	4,	5,	3,	4,	2,	1,	0,	0,	1,	2,	3,	0,	0,	1,	3,	1,	3,	0,	1,	6,	3,	0,	3,	4,	3,	3,	2,	2,	6,	1,	1,	2,	1,	2,	0,	0],
#     '150': [1, 5,	2,	2,	3,	2,	2,	3,	2,	1,	4,	4,	0,	0,	1,	1,	2,	1,	1,	3,	3,	3,	1,	1,	1,	1,	2,	1,	1,	0,	4,	3,	3,	3,	0,	2,	1,	2,	2,	0,	1,	5,	0,	1,	0,	4,	1,	1,	4,	0,	3,	1,	2,	1,	0,	1,	1,	1,	3,	0,	1,	0,	3,	2,	4,	2,	1,	3,	1,	3,	1,	0,	1,	3,	1],
#     '165': [5, 2,	1,	1,	2,	4,	2,	1,	2,	1,	0,	3,	2,	2,	5,	0,	3,	0,	1,	3,	1,	0,	2,	0,	5,	0,	1,	1,	1,	0,	2,	2,	4,	2,	2,	2,	0,	3,	0,	1,	5,	1,	2,	2,	0,	2,	0,	2,	3,	0,	1,	0,	3,	0,	1,	1,	2,	4,	4,	3,	1,	4,	2,	2,	2,	1,	1,	2,	1,	3,	1,	0,	0,	0,	1],
#     '180': [2, 1,	1,	1,	0,	2,	1,	2,	1,	1,	0,	4,	3,	3,	6,	1,	1,	1,	3,	2,	3,	1,	1,	3,	2,	0,	2,	1,	1,	2,	1,	1,	4,	2,	1,	1,	0,	3,	0,	1,	3,	1,	1,	1,	0,	0,	0,	2,	1,	5,	0,	4,	1,	3,	0,	1,	3,	1,	1,	1,	2,	0,	0,	3,	1,	1,	1,	5,	3,	2,	2,	0,	1,	2,	1],
#     '195': [2, 2,	2,	4,	1,	0,	1,	3,	2,	2,	1,	0,	2,	1,	2,	2,	4,	1,	0,	4,	3,	1,	4,	0,	2,	4,	1,	2,	2,	3,	3,	1,	0,	1,	4,	3,	1,	3,	0,	2,	0,	0,	1,	1,	0,	0,	0,	3,	2,	1,	0,	1,	1,	1,	3,	2,	1,	3,	7,	0,	4,	3,	1,	0,	0,	1,	0,	2,	1,	2,	1,	1,	0,	2,	1],
#     '210': [2, 0,	3,	3,	1,	4,	1,	0,	2,	2,	0,	2,	1,	3,	2,	2,	0,	2,	1,	2,	2,	3,	1,	2,	1,	1,	1,	1,	1,	0,	3,	3,	2,	0,	2,	1,	1,	1,	0,	2,	1,	1,	2,	1,	2,	0,	0,	2,	0,	4,	0,	0,	1,	1,	0,	0,	2,	4,	6,	2,	1,	2,	0,	0,	3,	1,	1,	1,	3,	2,	1,	2,	2,	2,	0],
#     '225': [0, 1,	0,	3,	0,	1,	1,	1,	1,	1,	3,	3,	0,	1,	2,	2,	2,	3,	2,	1,	2,	4,	2,	0,	1,	1,	0,	4,	3,	2,	2,	1,	1,	1,	2,	1,	1,	2,	1,	1,	0,	3,	1,	3,	4,	0,	0,	1,	0,	0,	2,	2,	1,	1,	1,	1,	3,	3,	0,	2,	0,	4,	2,	0,	2,	1,	1,	0,	0,	6,	1,	2,	0,	1,	1],
#     '240': [1, 1,	1,	1,	1,	1,	0,	2,	1,	3,	1,	1,	0,	0,	1,	2,	0,	1,	0,	0,	1,	2,	3,	0,	2,	3,	2,	1,	2,	2,	0,	4,	0,	2,	1,	2,	2,	2,	1,	2,	0,	2,	1,	4,	1,	0,	0,	0,	0,	4,	2,	3,	4,	1,	2,	3,	2,	0,	1,	1,	2,	0,	3,	1,	1,	3,	1,	2,	3,	4,	3,	1,	2,	0,	2],
#     '255': [1, 3,	2,	2,	1,	0,	1,	1,	1,	0,	1,	0,	0,	2,	1,	1,	0,	1,	0,	0,	2,	3,	4,	1,	0,	1,	0,	2,	0,	0,	2,	1,	2,	1,	3,	3,	0,	2,	2,	0,	0,	2,	0,	2,	1,	0,	0,	0,	2,	1,	0,	2,	1,	3,	0,	1,	3,	1,	5,	0,	0,	2,	1,	0,	2,	4,	0,	0,	0,	1,	1,	1,	1,	1,	0],
#     '270': [1, 0,	0,	0,	2,	1,	3,	3,	1,	0,	0,	0,	1,	1,	0,	0,	1,	2,	1,	0,	1,	0,	0,	0,	1,	0,	2,	1,	1,	1,	1,	0,	1,	2,	2,	1,	1,	0,	1,	2,	1,	2,	1,	1,	3,	0,	1,	0,	0,	1,	0,	0,	2,	2,	1,	1,	1,	1,	2,	1,	0,	4,	2,	2,	1,	1,	0,	4,	1,	0,	1,	0,	0,	2,	2],
#     '285': [1, 1,	2,	1,	0,	0,	0,	0,	1,	4,	2,	0,	1,	1,	1,	2,	0,	0,	0,	2,	1,	1,	1,	3,	1,	5,	0,	1,	0,	0,	0,	0,	0,	1,	1,	1,	2,	1,	0,	2,	0,	3,	1,	1,	0,	0,	5,	1,	2,	0,	0,	0,	1,	2,	0,	1,	1,	0,	0,	0,	2,	1,	1,	0,	1,	1,	0,	5,	0,	2,	3,	2,	0,	0,	2],
#     '300': [1, 1,	1,	0,	1,	2,	2,	0,	0,	1,	0,	0,	1,	1,	1,	0,	0,	1,	1,	1,	2,	2,	0,	0,	0,	1,	0,	3,	1,	1,	1,	2,	0,	0,	2,	1,	0,	0,	0,	0,	1,	1,	1,	0,	1,	0,	4,	1,	0,	0,	0,	3,	0,	1,	3,	1,	0,	0,	1,	2,	1,	0,	0,	1,	0,	1,	1,	0,	0,	1,	1,	0,	1,	0,	2],
#     '315': [1, 1,	0,	0,	2,	0,	0,	0,	1,	1,	1,	0,	1,	1,	0,	3,	1,	0,	0,	0,	2,	2,	0,	1,	0,	0,	0,	0,	0,	1,	1,	0,	1,	0,	1,	0,	0,	1,	1,	1,	0,	1,	0,	0,	1,	2,	1,	3,	1,	1,	1,	1,	1,	1,	1,	1,	1,	0,	0,	0,	0,	1,	1,	1,	0,	0,	1,	0,	0,	0,	0,	0,	1,	0,	0],
#     '330': [0, 0,	0,	0,	0,	0,	0,	0,	0,	3,	0,	2,	1,	0,	1,	0,	0,	2,	0,	1,	0,	0,	1,	0,	0,	1,	1,	1,	1,	0,	1,	0,	0,	1,	4,	1,	0,	0,	0,	0,	1,	2,	2,	0,	1,	0,	7,	0,	0,	0,	2,	0,	0,	0,	0,	1,	1,	1,	0,	1,	0,	2,	1,	0,	0,	2,	1,	0,	1,	0,	1,	0,	0,	1,	0],
#     '345': [0, 0,	1,	0,	0,	0,	0,	0,	1,	0,	1,	0,	0,	0,	0,	0,	0,	1,	0,	0,	0,	1,	0,	0,	0,	2,	0,	0,	0,	0,	1,	0,	0,	0,	1,	0,	3,	0,	0,	0,	0,	2,	0,	0,	0,	1,	8,	0,	1,	0,	0,	0,	1,	0,	0,	0,	1,	1,	0,	0,	1,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0]
# })
#
# # Set data
# mean = pd.DataFrame({
#     'group': ['mean'],
#     'var1': [0.44],
#     'var2': [0.48],
#     'var3': [0.4933],
#     'var4': [0.88],
#     'var5': [0.85333],
#     'var6': [1.18666],
#     'var7': [0.98666],
#     'var8': [1.21333],
#     'var9': [1.49333],
#     'var10': [1.72],
#     'var11': [1.7333],
#     'var12': [1.68],
#     'var13': [1.58666],
#     'var14': [1.62666],
#     'var15': [1.48],
#     'var16': [1.45333],
#     'var17': [1.48],
#     'var18': [1.1333],
#     'var19': [1.01333],
#     'var20': [1.04],
#     'var21': [0.8],
#     'var22': [0.62666],
#     'var23': [0.66666],
#     'var24': [0.37333]
# })
#
#
#
# # ------- PART 1: Create background
#
# # number of variable
# categories = list(df)[1:]
# N = len(categories)
#
# # What will be the angle of each axis in the plot? (we divide the plot / number of variable)
# angles = [n / float(N) * 2 * pi for n in range(N)]
# angles += angles[:1]
# # angles = [0,15,30,45,60,75,90,105,120,135,150,165,180,195,210,225,240,255,270,285,300,315,330,345]
#
# # Initialise the spider plot
# ax = plt.subplot(111, polar=True)
#
# # If you want the first axis to be on top:
# ax.set_theta_offset(pi / 2)
# ax.set_theta_direction(-1)
#
# # Draw one axe per variable + add labels labels yet
# # plt.xticks(angles[:-1], categories)
#
# # Draw ylabels
# # ax.set_rlabel_position(0)
# plt.yticks([2, 4, 6,8], ["2", "4", "6",'8'], color="grey", size=7)
# plt.ylim(0, 8)
#
# # ------- PART 2: Add plots
#
# # Plot each individual = each line of the data
# # I don't do a loop, because plotting more than 3 groups makes the chart unreadable
#
# # Ind1
# for cell in range(0,len(df)):
#     values = df.loc[cell].drop('group').values.flatten().tolist()
#     values += values[:1]
#     ax.plot(angles, values, linewidth=1, linestyle='solid', label="group A")
# # ax.fill(angles, values, 'b', alpha=0.1)
#
# # # Ind1
# # values = df.loc[0].drop('group').values.flatten().tolist()
# # values += values[:1]
# # ax.plot(angles, values, linewidth=1, linestyle='solid', label="group A")
# # # ax.fill(angles, values, 'b', alpha=0.1)
# #
# # Ind2
# values = mean.loc[0].drop('group').values.flatten().tolist()
# values += values[:1]
# ax.plot(angles, values, linewidth=3, linestyle='solid', label="group B", color = 'k')
# ax.fill(angles, values, 'k', alpha=0.9)
#
# # Add legend
# plt.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))
#
# plt.show()
#
# ##### This is code to plot WT only graphs for directionality things #######
import math
import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *
from RFTdt_Database_Queries import number_dev_graphs
from RFTdt_Database_Queries import length_dev_graphs
from RFTdt_Database_Queries import polarity_dev_graphs
from RFTdt_Database_Queries import directionality_dev_graphs
WTTR_dpi03_values, WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values, FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values = directionality_dev_graphs('r')

WTTR_values = WTTR_dpi03_values+WTTR_dpi05_values+WTTR_dpi07_values+WTTR_dpi09_values+WTTR_dpi12_values
print WTTR_values
WTTR_Mean = (np.mean(WTTR_dpi03_values+WTTR_dpi05_values+WTTR_dpi07_values+WTTR_dpi09_values+WTTR_dpi12_values))

WTTR_SEM  = np.std(WTTR_dpi03_values+WTTR_dpi05_values+WTTR_dpi07_values+WTTR_dpi09_values+WTTR_dpi12_values,ddof=1) / math.sqrt(len(WTTR_dpi03_values+WTTR_dpi05_values+WTTR_dpi07_values+WTTR_dpi09_values+WTTR_dpi12_values))

#Make Blank Figure
fig,axs = plot.subplots(nrows=1, ncols=3, sharex=False, sharey=False)

#Plot WT Dev Graph
ax=axs[0]

ax.set_xlim(0,2)
ax.set_ylim(0,1)
# ax.set_ylim(0,360)

WT_xcoords = []
WT_xcoords = [uniform(0.95,1.05) for value in WTTR_values]
# print WT_xcoords

ax.scatter(1,WTTR_Mean, color = '#233E90',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WT_xcoords,WTTR_values, color = '#0d0d0d',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.errorbar(1,WTTR_Mean,WTTR_SEM,fmt='none',ecolor= '#233E90',elinewidth='2',capsize=10,capthick='2')


#Plot an ECDF of all WT values
ax =axs[1]

ecdf1 = sm.distributions.ECDF(WTTR_values)
values = np.linspace(min(WTTR_values), max(WTTR_values))
values_ecdf = ecdf1(values)


ax.step(values,values_ecdf, color= '#0d0d0d', linewidth=2.0)

#Plot WT histogram
ax =axs[2]

bins = np.linspace(0, 1, 20)

ax.hist(WTTR_values, bins, normed=1, alpha=0.5, label='WT TR',color='#0d0d0d')
ax.legend(loc='upper right')
# ax.plot([WTTR_Median,WTTR_Median],[0,0.001], color = '#f26b47', linewidth='2')
# ax.plot([WTTR_Mean,WTTR_Mean],[0,0.001], color = '#f26b47', linewidth='2', linestyle="--")


plot.show()

# ###End Directionality Plotting Code #####

# ####Makes a simple heatmap with two identical rows (minimum for making image)
# import numpy as np
# import matplotlib
# import matplotlib.pyplot as plt
# # sphinx_gallery_thumbnail_number = 2
#
# #create 2 rows so that it can plot an image
# rows = ["1", "2"]
# #the angle intervals
# angles = ['0-15','15-30','30-45','45-60','60-75','75-90','9-105','105-120','120-135','135-150','150-165','165-180','180-195','195-210','210-225','225-240','240-255','255-270','270-285','285-300','300-315','315-330','330-345','345-360']
#
# paths = np.array([[23,	21,	22,	41,	47,	54,	50,	50,	58,	66,	61,	51,	49,	58,	57,	63,	59,	49,	51,	39,	41,	31,	34,	15],
#                  [11,	18,	20,	28,	24,	46,	34,	54,	74,	70,	77,	86,	81,	73,	66,	57,	64,	41,	33,	46,	30,	19,	21,	13]])
#
# # paths = np.array([[23,	21,	22,	41,	47,	54,	50,	50,	58,	66,	61,	51,	49,	58,	57,	63,	59,	49,	51,	39,	41,	31,	34,	15],
# #                   [23, 21, 22, 41, 47, 54, 50, 50, 58, 66, 61, 51, 49, 58, 57, 63, 59, 49, 51, 39, 41, 31, 34, 15]])
#
# # paths = np.array([[11,	18,	20,	28,	24,	46,	34,	54,	74,	70,	77,	86,	81,	73,	66,	57,	64,	41,	33,	46,	30,	19,	21,	13],
# #                  [11,	18,	20,	28,	24,	46,	34,	54,	74,	70,	77,	86,	81,	73,	66,	57,	64,	41,	33,	46,	30,	19,	21,	13]])
#
# fig, ax = plt.subplots()
# im = ax.imshow(paths,cmap="plasma",interpolation = "none")
#
# # We want to show all ticks...
# ax.set_xticks(np.arange(len(angles)))
# ax.set_yticks(np.arange(len(rows)))
# # ... and label them with the respective list entries
# ax.set_xticklabels(angles)
# ax.set_yticklabels(rows)
#
# # Rotate the tick labels and set their alignment.
# plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
#          rotation_mode="anchor")
#
# # # Loop over data dimensions and create text annotations.
# # for i in range(len(vegetables)):
# #     for j in range(len(farmers)):
# #         text = ax.text(j, i, harvest[i, j],
# #                        ha="center", va="center", color="w")
#
# ax.set_title("Heatmap of dendrite density)")
# plt.show()

####End simple heatmap