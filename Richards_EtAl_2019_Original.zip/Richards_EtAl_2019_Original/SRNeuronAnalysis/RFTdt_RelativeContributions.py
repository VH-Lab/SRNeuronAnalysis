### Test code to calculate the fraction development stats for Steve ###
import numpy as np
import math
import matplotlib.pyplot as plot;

plot.rcdefaults()
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *

from RFTdt_Database_Queries import geno_growth_components

dpi03_WT_arbor, dpi03_WT_seglen, dpi03_WT_segnum,dpi05_WT_arbor,dpi05_WT_seglen, dpi05_WT_segnum,dpi07_WT_arbor, dpi07_WT_seglen, \
dpi07_WT_segnum,dpi09_WT_arbor, dpi09_WT_seglen, dpi09_WT_segnum,dpi12_WT_arbor, dpi12_WT_seglen, dpi12_WT_segnum,dpi03_FLX_arbor, \
dpi03_FLX_seglen, dpi03_FLX_segnum,dpi05_FLX_arbor, dpi05_FLX_seglen, dpi05_FLX_segnum,dpi07_FLX_arbor, dpi07_FLX_seglen, \
dpi07_FLX_segnum,dpi09_FLX_arbor, dpi09_FLX_seglen, dpi09_FLX_segnum,dpi12_FLX_arbor, dpi12_FLX_seglen, dpi12_FLX_segnum = geno_growth_components()


dpi03_WT_values = zip(dpi03_WT_arbor, dpi03_WT_seglen, dpi03_WT_segnum)
dpi05_WT_values = zip(dpi05_WT_arbor, dpi05_WT_seglen, dpi05_WT_segnum)
dpi07_WT_values = zip(dpi07_WT_arbor, dpi07_WT_seglen, dpi07_WT_segnum)
dpi09_WT_values = zip(dpi09_WT_arbor, dpi09_WT_seglen, dpi09_WT_segnum)
dpi12_WT_values = zip(dpi12_WT_arbor, dpi12_WT_seglen, dpi12_WT_segnum)

dpi03_FLX_values = zip(dpi03_FLX_arbor, dpi03_FLX_seglen, dpi03_FLX_segnum)
dpi05_FLX_values = zip(dpi05_FLX_arbor, dpi05_FLX_seglen, dpi05_FLX_segnum)
dpi07_FLX_values = zip(dpi07_FLX_arbor, dpi07_FLX_seglen, dpi07_FLX_segnum)
dpi09_FLX_values = zip(dpi09_FLX_arbor, dpi09_FLX_seglen, dpi09_FLX_segnum)
dpi12_FLX_values = zip(dpi12_FLX_arbor, dpi12_FLX_seglen, dpi12_FLX_segnum)

dpi03_deltaArbor = []
dpi03_deltaSegNum = []
dpi03_deltaSegLen = []
dpi03_Len_value = []
dpi03_Num_value = []
dpi03_LenNum_value = []

for value in dpi03_WT_values:
    delta_A = [arbor - value[0] for arbor in dpi03_FLX_arbor]
    delta_L = [seglen - value[1] for seglen in dpi03_FLX_seglen]
    delta_N = [segnum - value[2] for segnum in dpi03_FLX_segnum]
    dpi03_deltaArbor.append(delta_A)
    dpi03_deltaSegNum.append(delta_N)
    dpi03_deltaSegLen.append(delta_L)
    len_v = [(seglen - value[1]) * value[2] for seglen in dpi03_FLX_seglen]
    dpi03_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in dpi03_FLX_segnum]
    dpi03_Num_value.append(num_v)

    len_num_zip = zip(delta_L, delta_N)
    len_num_v = [item[0] * item[1] for item in len_num_zip]
    dpi03_LenNum_value.append(len_num_v)

dpi05_deltaArbor = []
dpi05_deltaSegNum = []
dpi05_deltaSegLen = []
dpi05_Len_value = []
dpi05_Num_value = []
dpi05_LenNum_value = []

for value in dpi05_WT_values:
    delta_A = [arbor - value[0] for arbor in dpi05_FLX_arbor]
    delta_L = [seglen - value[1] for seglen in dpi05_FLX_seglen]
    delta_N = [segnum - value[2] for segnum in dpi05_FLX_segnum]
    dpi05_deltaArbor.append(delta_A)
    dpi05_deltaSegNum.append(delta_N)
    dpi05_deltaSegLen.append(delta_L)
    len_v = [(seglen - value[1]) * value[2] for seglen in dpi05_FLX_seglen]
    dpi05_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in dpi05_FLX_segnum]
    dpi05_Num_value.append(num_v)

    len_num_zip = zip(delta_L, delta_N)
    len_num_v = [item[0] * item[1] for item in len_num_zip]
    dpi05_LenNum_value.append(len_num_v)

dpi07_deltaArbor = []
dpi07_deltaSegNum = []
dpi07_deltaSegLen = []
dpi07_Len_value = []
dpi07_Num_value = []
dpi07_LenNum_value = []

for value in dpi07_WT_values:
    delta_A = [arbor - value[0] for arbor in dpi07_FLX_arbor]
    delta_L = [seglen - value[1] for seglen in dpi07_FLX_seglen]
    delta_N = [segnum - value[2] for segnum in dpi07_FLX_segnum]
    dpi07_deltaArbor.append(delta_A)
    dpi07_deltaSegNum.append(delta_N)
    dpi07_deltaSegLen.append(delta_L)
    len_v = [(seglen - value[1]) * value[2] for seglen in dpi07_FLX_seglen]
    dpi07_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in dpi07_FLX_segnum]
    dpi07_Num_value.append(num_v)

    len_num_zip = zip(delta_L, delta_N)
    len_num_v = [item[0] * item[1] for item in len_num_zip]
    dpi07_LenNum_value.append(len_num_v)

dpi09_deltaArbor = []
dpi09_deltaSegNum = []
dpi09_deltaSegLen = []
dpi09_Len_value = []
dpi09_Num_value = []
dpi09_LenNum_value = []

for value in dpi09_WT_values:
    delta_A = [arbor - value[0] for arbor in dpi09_FLX_arbor]
    delta_L = [seglen - value[1] for seglen in dpi09_FLX_seglen]
    delta_N = [segnum - value[2] for segnum in dpi09_FLX_segnum]
    dpi09_deltaArbor.append(delta_A)
    dpi09_deltaSegNum.append(delta_N)
    dpi09_deltaSegLen.append(delta_L)
    len_v = [(seglen - value[1]) * value[2] for seglen in dpi09_FLX_seglen]
    dpi09_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in dpi09_FLX_segnum]
    dpi09_Num_value.append(num_v)

    len_num_zip = zip(delta_L, delta_N)
    len_num_v = [item[0] * item[1] for item in len_num_zip]
    dpi09_LenNum_value.append(len_num_v)

dpi12_deltaArbor = []
dpi12_deltaSegNum = []
dpi12_deltaSegLen = []
dpi12_Len_value = []
dpi12_Num_value = []
dpi12_LenNum_value = []

for value in dpi12_WT_values:
    delta_A = [arbor - value[0] for arbor in dpi12_FLX_arbor]
    delta_L = [seglen - value[1] for seglen in dpi12_FLX_seglen]
    delta_N = [segnum - value[2] for segnum in dpi12_FLX_segnum]
    dpi12_deltaArbor.append(delta_A)
    dpi12_deltaSegNum.append(delta_N)
    dpi12_deltaSegLen.append(delta_L)
    len_v = [(seglen - value[1]) * value[2] for seglen in dpi12_FLX_seglen]
    dpi12_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in dpi12_FLX_segnum]
    dpi12_Num_value.append(num_v)

    len_num_zip = zip(delta_L, delta_N)
    len_num_v = [item[0] * item[1] for item in len_num_zip]
    dpi12_LenNum_value.append(len_num_v)

dpi03_flat_deltaArbor = [value for cell in dpi03_deltaArbor for value in cell]
dpi03_flat_Num_value = [value for cell in dpi03_Num_value for value in cell]
dpi03_flat_Len_value = [value for cell in dpi03_Len_value for value in cell]
dpi03_flat_LenNum_value = [value for cell in dpi03_LenNum_value for value in cell]

dpi05_flat_deltaArbor = [value for cell in dpi05_deltaArbor for value in cell]
dpi05_flat_Num_value = [value for cell in dpi05_Num_value for value in cell]
dpi05_flat_Len_value = [value for cell in dpi05_Len_value for value in cell]
dpi05_flat_LenNum_value = [value for cell in dpi05_LenNum_value for value in cell]

dpi07_flat_deltaArbor = [value for cell in dpi07_deltaArbor for value in cell]
dpi07_flat_Num_value = [value for cell in dpi07_Num_value for value in cell]
dpi07_flat_Len_value = [value for cell in dpi07_Len_value for value in cell]
dpi07_flat_LenNum_value = [value for cell in dpi07_LenNum_value for value in cell]
print dpi07_flat_deltaArbor
# print dpi07_flat_Num_value
# print dpi07_flat_Len_value
# print dpi07_flat_LenNum_value

dpi09_flat_deltaArbor = [value for cell in dpi09_deltaArbor for value in cell]
dpi09_flat_Num_value = [value for cell in dpi09_Num_value for value in cell]
dpi09_flat_Len_value = [value for cell in dpi09_Len_value for value in cell]
dpi09_flat_LenNum_value = [value for cell in dpi09_LenNum_value for value in cell]

dpi12_flat_deltaArbor = [value for cell in dpi12_deltaArbor for value in cell]
dpi12_flat_Num_value = [value for cell in dpi12_Num_value for value in cell]
dpi12_flat_Len_value = [value for cell in dpi12_Len_value for value in cell]
dpi12_flat_LenNum_value = [value for cell in dpi12_LenNum_value for value in cell]

# Calculate Means
dpi03_deltaArbor_mean = np.mean(dpi03_flat_deltaArbor)
dpi03_Num_value_mean = np.mean(dpi03_flat_Num_value)
dpi03_Len_value_mean = np.mean(dpi03_flat_Len_value)
dpi03_LenNum_value_mean = np.mean(dpi03_flat_LenNum_value)
# print dpi03_Num_value_mean
# print dpi03_Len_value_mean
# print dpi03_LenNum_value_mean

dpi05_deltaArbor_mean = np.mean(dpi05_flat_deltaArbor)
dpi05_Num_value_mean = np.mean(dpi05_flat_Num_value)
dpi05_Len_value_mean = np.mean(dpi05_flat_Len_value)
dpi05_LenNum_value_mean = np.mean(dpi05_flat_LenNum_value)
# print dpi05_Num_value_mean
# print dpi05_Len_value_mean
# print dpi05_LenNum_value_mean

dpi07_deltaArbor_mean = np.mean(dpi07_flat_deltaArbor)
dpi07_Num_value_mean = np.mean(dpi07_flat_Num_value)
dpi07_Len_value_mean = np.mean(dpi07_flat_Len_value)
dpi07_LenNum_value_mean = np.mean(dpi07_flat_LenNum_value)
# print dpi07_Num_value_mean
# print dpi07_Len_value_mean
# print dpi07_LenNum_value_mean

dpi09_deltaArbor_mean = np.mean(dpi09_flat_deltaArbor)
dpi09_Num_value_mean = np.mean(dpi09_flat_Num_value)
dpi09_Len_value_mean = np.mean(dpi09_flat_Len_value)
dpi09_LenNum_value_mean = np.mean(dpi09_flat_LenNum_value)
# print dpi09_Num_value_mean
# print dpi09_Len_value_mean
# print dpi09_LenNum_value_mean

dpi12_deltaArbor_mean = np.mean(dpi12_flat_deltaArbor)
dpi12_Num_value_mean = np.mean(dpi12_flat_Num_value)
dpi12_Len_value_mean = np.mean(dpi12_flat_Len_value)
dpi12_LenNum_value_mean = np.mean(dpi12_flat_LenNum_value)
# print dpi12_Num_value_mean
# print dpi12_Len_value_mean
# print dpi12_LenNum_value_mean

# Calculate SEM
# deltaArbor_SEM  = np.std(flat_deltaArbor,ddof=1) / math.sqrt(len(flat_deltaArbor))
# Num_value_SEM = np.std(flat_Num_value,ddof=1) / math.sqrt(len(flat_Num_value))
# Len_value_SEM = np.std(flat_Len_value,ddof=1) / math.sqrt(len(flat_Len_value))
# LenNum_value_SEM = np.std(flat_LenNum_value,ddof=1) / math.sqrt(len(flat_LenNum_value))

# Caluculate Standard Error
dpi03_deltaArbor_STD = np.std(dpi03_flat_deltaArbor, ddof=1)
dpi03_Num_value_STD = np.std(dpi03_flat_Num_value, ddof=1)
dpi03_Len_value_STD = np.std(dpi03_flat_Len_value, ddof=1)
dpi03_LenNum_value_STD = np.std(dpi03_flat_LenNum_value, ddof=1)

dpi05_deltaArbor_STD = np.std(dpi05_flat_deltaArbor, ddof=1)
dpi05_Num_value_STD = np.std(dpi05_flat_Num_value, ddof=1)
dpi05_Len_value_STD = np.std(dpi05_flat_Len_value, ddof=1)
dpi05_LenNum_value_STD = np.std(dpi05_flat_LenNum_value, ddof=1)

dpi07_deltaArbor_STD = np.std(dpi07_flat_deltaArbor, ddof=1)
dpi07_Num_value_STD = np.std(dpi07_flat_Num_value, ddof=1)
dpi07_Len_value_STD = np.std(dpi07_flat_Len_value, ddof=1)
dpi07_LenNum_value_STD = np.std(dpi07_flat_LenNum_value, ddof=1)

dpi09_deltaArbor_STD = np.std(dpi09_flat_deltaArbor, ddof=1)
dpi09_Num_value_STD = np.std(dpi09_flat_Num_value, ddof=1)
dpi09_Len_value_STD = np.std(dpi09_flat_Len_value, ddof=1)
dpi09_LenNum_value_STD = np.std(dpi09_flat_LenNum_value, ddof=1)

dpi12_deltaArbor_STD = np.std(dpi12_flat_deltaArbor, ddof=1)
dpi12_Num_value_STD = np.std(dpi12_flat_Num_value, ddof=1)
dpi12_Len_value_STD = np.std(dpi12_flat_Len_value, ddof=1)
dpi12_LenNum_value_STD = np.std(dpi12_flat_LenNum_value, ddof=1)

# Make Blank Figure
fig, axs = plot.subplots(nrows=2, ncols=1, sharex=False, sharey='row')
# Plot growth graph
ax = axs[0]

ax.set_xlim(0, 15)
xvalue = [1, 1.5, 2, 4, 4.5, 5, 7, 7.5, 8, 10, 10.5, 11, 13, 13.5, 14]
yvalue = [dpi03_Num_value_mean, dpi03_Len_value_mean, dpi03_LenNum_value_mean, dpi05_Num_value_mean, dpi05_Len_value_mean,
          dpi05_LenNum_value_mean, dpi07_Num_value_mean, dpi07_Len_value_mean,
          dpi07_LenNum_value_mean, dpi09_Num_value_mean, dpi09_Len_value_mean, dpi09_LenNum_value_mean, dpi12_Num_value_mean,
          dpi12_Len_value_mean, dpi12_LenNum_value_mean]

yerr = [dpi03_Num_value_STD, dpi03_Len_value_STD, dpi03_LenNum_value_STD, dpi05_Num_value_STD, dpi05_Len_value_STD,
        dpi05_LenNum_value_STD, dpi07_Num_value_STD, dpi07_Len_value_STD,
        dpi07_LenNum_value_STD, dpi09_Num_value_STD, dpi09_Len_value_STD, dpi09_LenNum_value_STD, dpi12_Num_value_STD,
        dpi12_Len_value_STD, dpi12_LenNum_value_STD]

# ax.violinplot(dpi05_flat_deltaArbor,[0])
ax.violinplot(dpi03_flat_Num_value, [1])
ax.violinplot(dpi03_flat_Len_value, [1.5])
ax.violinplot(dpi03_flat_LenNum_value, [2])

ax.violinplot(dpi05_flat_Num_value, [4])
ax.violinplot(dpi05_flat_Len_value, [4.5])
ax.violinplot(dpi05_flat_LenNum_value, [25])

ax.violinplot(dpi07_flat_Num_value, [7])
ax.violinplot(dpi07_flat_Len_value, [7.5])
ax.violinplot(dpi07_flat_LenNum_value, [8])

ax.violinplot(dpi09_flat_Num_value, [10])
ax.violinplot(dpi09_flat_Len_value, [10.5])
ax.violinplot(dpi09_flat_LenNum_value, [11])

ax.violinplot(dpi12_flat_Num_value, [13])
ax.violinplot(dpi12_flat_Len_value, [13.5])
ax.violinplot(dpi12_flat_LenNum_value, [14])

# ax.scatter(0,dpi05_deltaArbor_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(1, dpi03_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(1.5, dpi03_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(2, dpi03_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(4, dpi05_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(4.5, dpi05_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(5, dpi05_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(7, dpi07_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(7.5, dpi07_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(8, dpi07_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(10, dpi09_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(10.5, dpi09_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(11, dpi09_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(13, dpi12_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(13.5, dpi12_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(14, dpi12_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.errorbar(xvalue, yvalue, yerr, fmt='none', ecolor='#F26B47', elinewidth='2', capsize=10, capthick='2')
ax.plot((0, 15), (0, 15), '--', linewidth=2)

# Plot FLX DPI boxplots
ax = axs[1]

data = (dpi03_flat_Num_value, dpi03_flat_Len_value, dpi03_flat_LenNum_value, dpi05_flat_Num_value, dpi05_flat_Len_value,
        dpi05_flat_LenNum_value, dpi07_flat_Num_value, dpi07_flat_Len_value,
        dpi07_flat_LenNum_value,
        dpi09_flat_Num_value, dpi09_flat_Len_value, dpi09_flat_LenNum_value, dpi12_flat_Num_value, dpi12_flat_Len_value,
        dpi12_flat_LenNum_value)

position = [1, 1.5, 2, 4, 4.5, 5, 7, 7.5, 8, 10, 10.5, 11, 13, 13.5, 14]

boxprops = dict(linestyle='-', linewidth=0, color='none', facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0AF25', markersize=4, markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops = dict(linestyle='-', color='#666666', linewidth=2)
capprops = dict(linewidth=2, color='#666666')

box = ax.boxplot(data, positions=position, patch_artist=True, sym='o', boxprops=boxprops, flierprops=flierprops,
                 medianprops=medianprops, whiskerprops=whiskerprops, capprops=capprops, widths=0.4)
colors = ['#fcd9cd','#fcd9cd','#fcd9cd','#f8a793','#f8a793','#f8a793','#f26b47','#f26b47','#f26b47','#df3325','#df3325','#df3325','#A42521','#A42521','#A42521']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

# ax.scatter(0,dpi05_deltaArbor_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(1, dpi03_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(1.5, dpi03_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(2, dpi03_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(4, dpi05_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(4.5, dpi05_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(5, dpi05_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(7, dpi07_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(7.5, dpi07_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(8, dpi07_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(10, dpi09_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(10.5, dpi09_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(11, dpi09_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.scatter(13, dpi12_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(13.5, dpi12_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
ax.scatter(14, dpi12_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)

ax.errorbar(xvalue, yvalue, yerr, fmt='none', ecolor='#F26B47', elinewidth='2', capsize=10, capthick='2')
ax.plot((0, 15), (0, 15), '--', linewidth=2)

plot.show()
