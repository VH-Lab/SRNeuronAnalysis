def number_summary_graphs(dpi, metric):

    import sqlite3
    connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    # cursor = connection.execute("select * from RFTDT_Trees")
    # for row in cursor:
    #     print row

    #By Genotype and Condition
    WTTR = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR'")
    WTTR_values = [row[0] for row in WTTR]
    # print WTTR_values
#
#     WTDD = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD'")
#     WTDD_values = [row[0] for row in WTDD]
#     # print WTDD_values
#
    FLXTR = connection.execute("select "+metric+ " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='FLX' and condition='TR'")
    FLXTR_values = [row[0] for row in FLXTR]
    # print FLXTR_values
#
#     FLXDD = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD'")
#     FLXDD_values = [row[0] for row in FLXDD]
#     # print FLXDD_values
#
#
#     #By Genotype, Condition, and Sex
#     WTTRM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR' and sex='M'")
#     WTTRM_values = [row[0] for row in WTTRM]
#     # print WTTRM_values
#     WTTRF= connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR' and sex='F'")
#     WTTRF_values = [row[0] for row in WTTRF]
#     # print WTTRF_values
#
#
#     WTDDM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD' and sex='M'")
#     WTDDM_values = [row[0] for row in WTDDM]
#     # print WTDDM_values
#     WTDDF = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD' and sex='F'")
#     WTDDF_values = [row[0] for row in WTDDF]
#     # print WTDDF_values
#
#
#     FLXTRM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and sex='M'")
#     FLXTRM_values = [row[0] for row in FLXTRM]
#     # print FLXTRM_values
#     FLXTRF = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and sex='F'")
#     FLXTRF_values = [row[0] for row in FLXTRF]
#     # print FLXTRF_values
#
#
#     FLXDDM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD' and sex='M'")
#     FLXDDM_values = [row[0] for row in FLXDDM]
#     # print FLXDDM_values
#     FLXDDF = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD' and sex='F'")
#     FLXDDF_values = [row[0] for row in FLXDDF]
#     # print FLXDDF_values
#
    return WTTR_values,FLXTR_values
#
# # WTTR_values,WTDD_values,FLXTR_values,FLXDD_values,WTTRM_values,WTTRF_values,WTDDM_values,WTDDF_values,FLXTRM_values,FLXTRF_values,FLXDDM_values,FLXDDF_values = summary_graphs('09dpi','soma_size')

def length_summary_graphs(dpi, metric):

    import sqlite3
    connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    # cursor = connection.execute("select * from RFTDT_Trees")
    # for row in cursor:
    #     print row

    #By Genotype and Condition
    WTTR_124 = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR' and pix_to_um ='1.24'")
    WTTR_values_124 = [row[0] for row in WTTR_124]
    WTTR_scaled_values_124 = [value*1.24 for value in WTTR_values_124]
    WTTR_042 = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR' and pix_to_um ='0.42'")
    WTTR_values_042 = [row[0] for row in WTTR_042]
    WTTR_scaled_values_042 = [value * 0.42 for value in WTTR_values_042]

    WTTR_values = WTTR_scaled_values_124 + WTTR_scaled_values_042

    # print WTTR_values
#
#     WTDD = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD'")
#     WTDD_values = [row[0] for row in WTDD]
#     # print WTDD_values
#
    FLXTR_124 = connection.execute(
        "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and pix_to_um ='1.24'")
    FLXTR_values_124 = [row[0] for row in FLXTR_124]
    FLXTR_scaled_values_124 = [value * 1.24 for value in FLXTR_values_124]
    FLXTR_042 = connection.execute(
        "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and pix_to_um ='0.42'")
    FLXTR_values_042 = [row[0] for row in FLXTR_042]
    FLXTR_scaled_values_042 = [value * 0.42 for value in FLXTR_values_042]

    FLXTR_values = FLXTR_scaled_values_124 + FLXTR_scaled_values_042

    # print FLXTR_values
#
#     FLXDD = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD'")
#     FLXDD_values = [row[0] for row in FLXDD]
#     # print FLXDD_values
#
#
#     #By Genotype, Condition, and Sex
#     WTTRM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR' and sex='M'")
#     WTTRM_values = [row[0] for row in WTTRM]
#     # print WTTRM_values
#     WTTRF= connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR' and sex='F'")
#     WTTRF_values = [row[0] for row in WTTRF]
#     # print WTTRF_values
#
#
#     WTDDM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD' and sex='M'")
#     WTDDM_values = [row[0] for row in WTDDM]
#     # print WTDDM_values
#     WTDDF = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD' and sex='F'")
#     WTDDF_values = [row[0] for row in WTDDF]
#     # print WTDDF_values
#
#
#     FLXTRM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and sex='M'")
#     FLXTRM_values = [row[0] for row in FLXTRM]
#     # print FLXTRM_values
#     FLXTRF = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and sex='F'")
#     FLXTRF_values = [row[0] for row in FLXTRF]
#     # print FLXTRF_values
#
#
#     FLXDDM = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD' and sex='M'")
#     FLXDDM_values = [row[0] for row in FLXDDM]
#     # print FLXDDM_values
#     FLXDDF = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD' and sex='F'")
#     FLXDDF_values = [row[0] for row in FLXDDF]
#     # print FLXDDF_values
#
    return WTTR_values,FLXTR_values
#
# # WTTR_values,WTDD_values,FLXTR_values,FLXDD_values,WTTRM_values,WTTRF_values,WTDDM_values,WTDDF_values,FLXTRM_values,FLXTRF_values,FLXDDM_values,FLXDDF_values = summary_graphs('09dpi','soma_size')

#
def number_dev_graphs(metric):
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    cursor = connection.execute("select * from RFTDT_Trees")
    # for row in cursor:
    #     print row

    WT_03dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_values = [row[0] for row in  WT_03dpi]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute("select "+ metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_values = [row[0] for row in  WT_05dpi]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_values = [row[0] for row in  WT_07dpi]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_values = [row[0] for row in  WT_09dpi]
    # print WTTR_09dpi_values

    WT_12dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi12_values = [row[0] for row in  WT_12dpi]
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute( "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_values = [row[0] for row in  FLX_03dpi]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_values = [row[0] for row in FLX_05dpi]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute( "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_values = [row[0] for row in FLX_07dpi]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute( "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_values = [row[0] for row in FLX_09dpi]
    # print  FLXTR_09dpi_values

    FLX_12dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi12_values = [row[0] for row in  FLX_12dpi]
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values,WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values,FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def length_dev_graphs(metric):
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    cursor = connection.execute("select * from RFTDT_Trees")
    # for row in cursor:
    #     print row

    WT_03dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_raw_values = [row[0] for row in  WT_03dpi]
    WTTR_dpi03_values = [value*0.42 for value in WTTR_dpi03_raw_values]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute("select "+ metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_raw_values = [row[0] for row in  WT_05dpi]
    WTTR_dpi05_values = [value * 0.42 for value in WTTR_dpi05_raw_values]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_raw_values = [row[0] for row in  WT_07dpi]
    WTTR_dpi07_values = [value * 0.42 for value in WTTR_dpi07_raw_values]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_raw_values = [row[0] for row in  WT_09dpi]
    WTTR_dpi09_values = [value * 0.42 for value in WTTR_dpi09_raw_values]
    # print WTTR_09dpi_values

    WT_12dpi_124_raw = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR' and pix_to_um='1.24'")
    WT_12dpi_124 = [row[0] for row in WT_12dpi_124_raw]
    WT_12dpi_042_raw = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'and pix_to_um='0.42'")
    WT_12dpi_042 = [row[0] for row in WT_12dpi_042_raw]
    WT_12dpi_124_scaled = [value*1.24 for value in WT_12dpi_124]
    WT_12dpi_042_scaled = [value*0.42 for value in WT_12dpi_042]
    WTTR_dpi12_values = WT_12dpi_124_scaled + WT_12dpi_042_scaled
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute( "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_raw_values = [row[0] for row in  FLX_03dpi]
    FLXTR_dpi03_values = [value * 0.42 for value in FLXTR_dpi03_raw_values]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_raw_values = [row[0] for row in FLX_05dpi]
    FLXTR_dpi05_values = [value * 0.42 for value in FLXTR_dpi05_raw_values]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute( "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_raw_values = [row[0] for row in FLX_07dpi]
    FLXTR_dpi07_values = [value * 0.42 for value in FLXTR_dpi07_raw_values]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute( "select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_raw_values = [row[0] for row in FLX_09dpi]
    FLXTR_dpi09_values = [value * 0.42 for value in FLXTR_dpi09_raw_values]
    # print  FLXTR_09dpi_values

    FLX_12dpi_124_raw = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR' and pix_to_um='1.24'")
    FLX_12dpi_124 = [row[0] for row in FLX_12dpi_124_raw]
    FLX_12dpi_042_raw = connection.execute("select " + metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'and pix_to_um='0.42'")
    FLX_12dpi_042 = [row[0] for row in FLX_12dpi_042_raw]
    FLX_12dpi_124_scaled = [value * 1.24 for value in FLX_12dpi_124]
    FLX_12dpi_042_scaled = [value * 0.42 for value in FLX_12dpi_042]
    FLXTR_dpi12_values = FLX_12dpi_124_scaled + FLX_12dpi_042_scaled
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values,WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values,FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def sholl_values(dpi, metric):

    import sqlite3
    connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\RFTdt_Dendrite_Analysis.db')
    # cursor = connection.execute("select genotype from RFTDT_Trees")
    # for row in cursor:
    #     print row

    #By Genotype and Condition
    WTTR = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR'")
    WTTR_values = [row[0] for row in WTTR]
    # print WTTR_values
    WTTR_values = [strings.split(',') for strings in WTTR_values]
    # print WTTR_values
    WTTR_values = [[int(sholl_intersections) for sholl_intersections in values] for values in WTTR_values]
    # print WTTR_values

    # WTDD = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD'")
    # WTDD_values = [row[0] for row in WTDD]
    # # print WTDD_values
    # WTDD_values = [strings.split(',') for strings in WTDD_values]
    # # print WTDD_values
    # WTDD_values = [[int(sholl_intersections) for sholl_intersections in values] for values in WTDD_values]
    # # print WTDD_values

    FLXTR = connection.execute("select "+metric+ " from RFTDT_Trees left join RFTdt_Animals on rftdt_trees.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='FLX' and condition='TR'")
    FLXTR_values = [row[0] for row in FLXTR]
    FLXTR_values = [strings.split(',') for strings in FLXTR_values]
    FLXTR_values = [[int(sholl_intersections) for sholl_intersections in values] for values in FLXTR_values]
    # print FLXTR_values

    # FLXDD = connection.execute("select "+metric + " from RFTDT_Trees left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD'")
    # FLXDD_values = [row[0] for row in FLXDD]
    # FLXDD_values = [strings.split(',') for strings in FLXDD_values]
    # FLXDD_values = [[int(sholl_intersections) for sholl_intersections in values] for values in FLXDD_values]
    # # print FLXDD_values

    return WTTR_values, FLXTR_values


