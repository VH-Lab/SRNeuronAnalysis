import math
import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *

from RFTdt_Database_Queries import radial_sholl

##This gives the value or r and the radial sholl value for each cell in each wedge (as listed). This allows one to divide
## the population of neurons into polar and non-polar cells at each age for graphing ease.
WT_0_15_values, WT_15_30_values,WT_30_45_values,WT_45_60_values,WT_60_75_values,WT_75_90_values,WT_90_105_values,\
           WT_105_120_values,WT_120_135_values, WT_135_150_values,WT_150_165_values,WT_165_180_values,WT_180_195_values,WT_195_210_values,WT_210_225_values,\
           WT_225_240_values,WT_240_255_values, WT_255_270_values,WT_270_285_values,WT_285_300_values,WT_300_315_values,WT_315_330_values,WT_330_345_values,\
           WT_345_360_values, FLX_0_15_values, FLX_15_30_values,FLX_30_45_values,FLX_45_60_values,FLX_60_75_values,FLX_75_90_values,FLX_90_105_values,\
           FLX_105_120_values,FLX_120_135_values, FLX_135_150_values,FLX_150_165_values,FLX_165_180_values,FLX_180_195_values,FLX_195_210_values,FLX_210_225_values,\
           FLX_225_240_values,FLX_240_255_values, FLX_255_270_values,FLX_270_285_values,FLX_285_300_values,FLX_300_315_values,FLX_315_330_values,FLX_330_345_values,\
           FLX_345_360_values= radial_sholl('num')



##Value of "num" gives number of paths in each span. Value of "fraction' gives the percentage of total paths in each span

# print WT_0_15_values
# print WT_15_30_values
# print WT_30_45_values
# print WT_45_60_values
# print WT_60_75_values
# print WT_75_90_values
# print WT_90_105_values
# print WT_105_120_values
# 
# print WT_120_135_values
# print WT_135_150_values
# print WT_150_165_values
# print WT_165_180_values
# print WT_180_195_values
# print WT_195_210_values
# print WT_210_225_values
# print WT_225_240_values
# 
# print WT_240_255_values
# print WT_255_270_values
# print WT_270_285_values
# print WT_285_300_values
# print WT_300_315_values
# print WT_315_330_values
# print WT_330_345_values
# print WT_345_360_values

## This gives you all of the values for radial sholl regardless of polarity status
##WT and FLX values
WT_0_15_all = [item[0] for item in WT_0_15_values]
WT_15_30_all = [item[0] for item in WT_15_30_values]
WT_30_45_all = [item[0] for item in WT_30_45_values]
WT_45_60_all = [item[0] for item in WT_45_60_values]
WT_60_75_all = [item[0] for item in WT_60_75_values]
WT_75_90_all = [item[0] for item in WT_75_90_values]
WT_90_105_all = [item[0] for item in WT_90_105_values]
WT_105_120_all = [item[0] for item in WT_105_120_values]

WT_120_135_all = [item[0] for item in WT_120_135_values]
WT_135_150_all = [item[0] for item in WT_135_150_values]
WT_150_165_all = [item[0] for item in WT_150_165_values]
WT_165_180_all = [item[0] for item in WT_165_180_values]
WT_180_195_all = [item[0] for item in WT_180_195_values]
WT_195_210_all = [item[0] for item in WT_195_210_values]
WT_210_225_all = [item[0] for item in WT_210_225_values]
WT_225_240_all = [item[0] for item in WT_225_240_values]

WT_240_255_all = [item[0] for item in WT_240_255_values]
WT_255_270_all = [item[0] for item in WT_255_270_values]
WT_270_285_all = [item[0] for item in WT_270_285_values]
WT_285_300_all = [item[0] for item in WT_285_300_values]
WT_300_315_all = [item[0] for item in WT_300_315_values]
WT_315_330_all = [item[0] for item in WT_315_330_values]
WT_330_345_all = [item[0] for item in WT_330_345_values]
WT_345_360_all = [item[0] for item in WT_345_360_values]

# print WT_0_15_all
# print WT_15_30_all
# print WT_30_45_all
# print WT_45_60_all
# print WT_60_75_all
# print WT_75_90_all
# print WT_90_105_all
# print WT_105_120_all
# 
# print WT_120_135_all
# print WT_135_150_all
# print WT_150_165_all
# print WT_165_180_all
# print WT_180_195_all
# print WT_195_210_all
# print WT_210_225_all
# print WT_225_240_all
# 
# print WT_240_255_all
# print WT_255_270_all
# print WT_270_285_all
# print WT_285_300_all
# print WT_300_315_all
# print WT_315_330_all
# print WT_330_345_all
# print WT_345_360_all


FLX_0_15_all = [item[0] for item in FLX_0_15_values]
FLX_15_30_all = [item[0] for item in FLX_15_30_values]
FLX_30_45_all = [item[0] for item in FLX_30_45_values]
FLX_45_60_all = [item[0] for item in FLX_45_60_values]
FLX_60_75_all = [item[0] for item in FLX_60_75_values]
FLX_75_90_all = [item[0] for item in FLX_75_90_values]
FLX_90_105_all = [item[0] for item in FLX_90_105_values]
FLX_105_120_all = [item[0] for item in FLX_105_120_values]

FLX_120_135_all = [item[0] for item in FLX_120_135_values]
FLX_135_150_all = [item[0] for item in FLX_135_150_values]
FLX_150_165_all = [item[0] for item in FLX_150_165_values]
FLX_165_180_all = [item[0] for item in FLX_165_180_values]
FLX_180_195_all = [item[0] for item in FLX_180_195_values]
FLX_195_210_all = [item[0] for item in FLX_195_210_values]
FLX_210_225_all = [item[0] for item in FLX_210_225_values]
FLX_225_240_all = [item[0] for item in FLX_225_240_values]

FLX_240_255_all = [item[0] for item in FLX_240_255_values]
FLX_255_270_all = [item[0] for item in FLX_255_270_values]
FLX_270_285_all = [item[0] for item in FLX_270_285_values]
FLX_285_300_all = [item[0] for item in FLX_285_300_values]
FLX_300_315_all = [item[0] for item in FLX_300_315_values]
FLX_315_330_all = [item[0] for item in FLX_315_330_values]
FLX_330_345_all = [item[0] for item in FLX_330_345_values]
FLX_345_360_all = [item[0] for item in FLX_345_360_values]


print FLX_0_15_all
print FLX_15_30_all
print FLX_30_45_all
print FLX_45_60_all
print FLX_60_75_all
print FLX_75_90_all
print FLX_90_105_all
print FLX_105_120_all

print FLX_120_135_all
print FLX_135_150_all
print FLX_150_165_all
print FLX_165_180_all
print FLX_180_195_all
print FLX_195_210_all
print FLX_210_225_all
print FLX_225_240_all

print FLX_240_255_all
print FLX_255_270_all
print FLX_270_285_all
print FLX_285_300_all
print FLX_300_315_all
print FLX_315_330_all
print FLX_330_345_all
print FLX_345_360_all


## This gives you radial sholl values for only non-polar cells
##WT and FLX values
WT_0_15_nonpolar = [item[0] for item in WT_0_15_values if item[1] < 0.315]
WT_15_30_nonpolar = [item[0] for item in WT_15_30_values if item[1] < 0.315]
WT_30_45_nonpolar = [item[0] for item in WT_30_45_values if item[1] < 0.315]
WT_45_60_nonpolar = [item[0] for item in WT_45_60_values if item[1] < 0.315]
WT_60_75_nonpolar = [item[0] for item in WT_60_75_values if item[1] < 0.315]
WT_75_90_nonpolar = [item[0] for item in WT_75_90_values if item[1] < 0.315]
WT_90_105_nonpolar = [item[0] for item in WT_90_105_values if item[1] < 0.315]
WT_105_120_nonpolar = [item[0] for item in WT_105_120_values if item[1] < 0.315]

WT_120_135_nonpolar = [item[0] for item in WT_120_135_values if item[1] < 0.315]
WT_135_150_nonpolar = [item[0] for item in WT_135_150_values if item[1] < 0.315]
WT_150_165_nonpolar = [item[0] for item in WT_150_165_values if item[1] < 0.315]
WT_165_180_nonpolar = [item[0] for item in WT_165_180_values if item[1] < 0.315]
WT_180_195_nonpolar = [item[0] for item in WT_180_195_values if item[1] < 0.315]
WT_195_210_nonpolar = [item[0] for item in WT_195_210_values if item[1] < 0.315]
WT_210_225_nonpolar = [item[0] for item in WT_210_225_values if item[1] < 0.315]
WT_225_240_nonpolar = [item[0] for item in WT_225_240_values if item[1] < 0.315]

WT_240_255_nonpolar = [item[0] for item in WT_240_255_values if item[1] < 0.315]
WT_255_270_nonpolar = [item[0] for item in WT_255_270_values if item[1] < 0.315]
WT_270_285_nonpolar = [item[0] for item in WT_270_285_values if item[1] < 0.315]
WT_285_300_nonpolar = [item[0] for item in WT_285_300_values if item[1] < 0.315]
WT_300_315_nonpolar = [item[0] for item in WT_300_315_values if item[1] < 0.315]
WT_315_330_nonpolar = [item[0] for item in WT_315_330_values if item[1] < 0.315]
WT_330_345_nonpolar = [item[0] for item in WT_330_345_values if item[1] < 0.315]
WT_345_360_nonpolar = [item[0] for item in WT_345_360_values if item[1] < 0.315]

FLX_0_15_nonpolar = [item[0] for item in FLX_0_15_values if item[1] < 0.315]
FLX_15_30_nonpolar = [item[0] for item in FLX_15_30_values if item[1] < 0.315]
FLX_30_45_nonpolar = [item[0] for item in FLX_30_45_values if item[1] < 0.315]
FLX_45_60_nonpolar = [item[0] for item in FLX_45_60_values if item[1] < 0.315]
FLX_60_75_nonpolar = [item[0] for item in FLX_60_75_values if item[1] < 0.315]
FLX_75_90_nonpolar = [item[0] for item in FLX_75_90_values if item[1] < 0.315]
FLX_90_105_nonpolar = [item[0] for item in FLX_90_105_values if item[1] < 0.315]
FLX_105_120_nonpolar = [item[0] for item in FLX_105_120_values if item[1] < 0.315]

FLX_120_135_nonpolar = [item[0] for item in FLX_120_135_values if item[1] < 0.315]
FLX_135_150_nonpolar = [item[0] for item in FLX_135_150_values if item[1] < 0.315]
FLX_150_165_nonpolar = [item[0] for item in FLX_150_165_values if item[1] < 0.315]
FLX_165_180_nonpolar = [item[0] for item in FLX_165_180_values if item[1] < 0.315]
FLX_180_195_nonpolar = [item[0] for item in FLX_180_195_values if item[1] < 0.315]
FLX_195_210_nonpolar = [item[0] for item in FLX_195_210_values if item[1] < 0.315]
FLX_210_225_nonpolar = [item[0] for item in FLX_210_225_values if item[1] < 0.315]
FLX_225_240_nonpolar = [item[0] for item in FLX_225_240_values if item[1] < 0.315]

FLX_240_255_nonpolar = [item[0] for item in FLX_240_255_values if item[1] < 0.315]
FLX_255_270_nonpolar = [item[0] for item in FLX_255_270_values if item[1] < 0.315]
FLX_270_285_nonpolar = [item[0] for item in FLX_270_285_values if item[1] < 0.315]
FLX_285_300_nonpolar = [item[0] for item in FLX_285_300_values if item[1] < 0.315]
FLX_300_315_nonpolar = [item[0] for item in FLX_300_315_values if item[1] < 0.315]
FLX_315_330_nonpolar = [item[0] for item in FLX_315_330_values if item[1] < 0.315]
FLX_330_345_nonpolar = [item[0] for item in FLX_330_345_values if item[1] < 0.315]
FLX_345_360_nonpolar = [item[0] for item in FLX_345_360_values if item[1] < 0.315]


## This gives you radial sholl values for only polar cells
##WT and FLX values
WT_0_15_polar = [item[0] for item in WT_0_15_values if item[1] > 0.315]
WT_15_30_polar = [item[0] for item in WT_15_30_values if item[1] > 0.315]
WT_30_45_polar = [item[0] for item in WT_30_45_values if item[1] > 0.315]
WT_45_60_polar = [item[0] for item in WT_45_60_values if item[1] > 0.315]
WT_60_75_polar = [item[0] for item in WT_60_75_values if item[1] > 0.315]
WT_75_90_polar = [item[0] for item in WT_75_90_values if item[1] > 0.315]
WT_90_105_polar = [item[0] for item in WT_90_105_values if item[1] > 0.315]
WT_105_120_polar = [item[0] for item in WT_105_120_values if item[1] > 0.315]

WT_120_135_polar = [item[0] for item in WT_120_135_values if item[1] > 0.315]
WT_135_150_polar = [item[0] for item in WT_135_150_values if item[1] > 0.315]
WT_150_165_polar = [item[0] for item in WT_150_165_values if item[1] > 0.315]
WT_165_180_polar = [item[0] for item in WT_165_180_values if item[1] > 0.315]
WT_180_195_polar = [item[0] for item in WT_180_195_values if item[1] > 0.315]
WT_195_210_polar = [item[0] for item in WT_195_210_values if item[1] > 0.315]
WT_210_225_polar = [item[0] for item in WT_210_225_values if item[1] > 0.315]
WT_225_240_polar = [item[0] for item in WT_225_240_values if item[1] > 0.315]

WT_240_255_polar = [item[0] for item in WT_240_255_values if item[1] > 0.315]
WT_255_270_polar = [item[0] for item in WT_255_270_values if item[1] > 0.315]
WT_270_285_polar = [item[0] for item in WT_270_285_values if item[1] > 0.315]
WT_285_300_polar = [item[0] for item in WT_285_300_values if item[1] > 0.315]
WT_300_315_polar = [item[0] for item in WT_300_315_values if item[1] > 0.315]
WT_315_330_polar = [item[0] for item in WT_315_330_values if item[1] > 0.315]
WT_330_345_polar = [item[0] for item in WT_330_345_values if item[1] > 0.315]
WT_345_360_polar = [item[0] for item in WT_345_360_values if item[1] > 0.315]

FLX_0_15_polar = [item[0] for item in FLX_0_15_values if item[1] > 0.315]
FLX_15_30_polar = [item[0] for item in FLX_15_30_values if item[1] > 0.315]
FLX_30_45_polar = [item[0] for item in FLX_30_45_values if item[1] > 0.315]
FLX_45_60_polar = [item[0] for item in FLX_45_60_values if item[1] > 0.315]
FLX_60_75_polar = [item[0] for item in FLX_60_75_values if item[1] > 0.315]
FLX_75_90_polar = [item[0] for item in FLX_75_90_values if item[1] > 0.315]
FLX_90_105_polar = [item[0] for item in FLX_90_105_values if item[1] > 0.315]
FLX_105_120_polar = [item[0] for item in FLX_105_120_values if item[1] > 0.315]

FLX_120_135_polar = [item[0] for item in FLX_120_135_values if item[1] > 0.315]
FLX_135_150_polar = [item[0] for item in FLX_135_150_values if item[1] > 0.315]
FLX_150_165_polar = [item[0] for item in FLX_150_165_values if item[1] > 0.315]
FLX_165_180_polar = [item[0] for item in FLX_165_180_values if item[1] > 0.315]
FLX_180_195_polar = [item[0] for item in FLX_180_195_values if item[1] > 0.315]
FLX_195_210_polar = [item[0] for item in FLX_195_210_values if item[1] > 0.315]
FLX_210_225_polar = [item[0] for item in FLX_210_225_values if item[1] > 0.315]
FLX_225_240_polar = [item[0] for item in FLX_225_240_values if item[1] > 0.315]

FLX_240_255_polar = [item[0] for item in FLX_240_255_values if item[1] > 0.315]
FLX_255_270_polar = [item[0] for item in FLX_255_270_values if item[1] > 0.315]
FLX_270_285_polar = [item[0] for item in FLX_270_285_values if item[1] > 0.315]
FLX_285_300_polar = [item[0] for item in FLX_285_300_values if item[1] > 0.315]
FLX_300_315_polar = [item[0] for item in FLX_300_315_values if item[1] > 0.315]
FLX_315_330_polar = [item[0] for item in FLX_315_330_values if item[1] > 0.315]
FLX_330_345_polar = [item[0] for item in FLX_330_345_values if item[1] > 0.315]
FLX_345_360_polar = [item[0] for item in FLX_345_360_values if item[1] > 0.315]


# print WT_0_15_polar
# print WT_15_30_polar
# print WT_30_45_polar
# print WT_45_60_polar
# print WT_60_75_polar
# print WT_75_90_polar
# print WT_90_105_polar
# print WT_105_120_polar
#
# print WT_120_135_polar
# print WT_135_150_polar
# print WT_150_165_polar
# print WT_165_180_polar
# print WT_180_195_polar
# print WT_195_210_polar
# print WT_210_225_polar
# print WT_225_240_polar
#
# print WT_240_255_polar
# print WT_255_270_polar
# print WT_270_285_polar
# print WT_285_300_polar
# print WT_300_315_polar
# print WT_315_330_polar
# print WT_330_345_polar
# print WT_345_360_polar


WT_nonpolar_sum = zip(WT_0_15_nonpolar,WT_15_30_nonpolar,WT_30_45_nonpolar,WT_45_60_nonpolar,WT_60_75_nonpolar,WT_75_90_nonpolar,WT_90_105_nonpolar,
                      WT_105_120_nonpolar,WT_120_135_nonpolar,WT_135_150_nonpolar,WT_150_165_nonpolar,WT_165_180_nonpolar,WT_180_195_nonpolar,WT_195_210_nonpolar,
                      WT_210_225_nonpolar,WT_225_240_nonpolar,WT_240_255_nonpolar,WT_255_270_nonpolar,WT_270_285_nonpolar,WT_285_300_nonpolar,WT_300_315_nonpolar,
                      WT_315_330_nonpolar,WT_330_345_nonpolar,WT_345_360_nonpolar)
WT_polar_sum =  zip(WT_0_15_polar,WT_15_30_polar,WT_30_45_polar,WT_45_60_polar,WT_60_75_polar,WT_75_90_polar,WT_90_105_polar,
                      WT_105_120_polar,WT_120_135_polar,WT_135_150_polar,WT_150_165_polar,WT_165_180_polar,WT_180_195_polar,WT_195_210_polar,
                      WT_210_225_polar,WT_225_240_polar,WT_240_255_polar,WT_255_270_polar,WT_270_285_polar,WT_285_300_polar,WT_300_315_polar,
                      WT_315_330_polar,WT_330_345_polar,WT_345_360_polar)
# print WT_nonpolar_sum
# print WT_polar_sum


###Calculate Means

#For all WT and FLX cells 
WT_0_15_Mean_all = (np.mean(WT_0_15_all))
WT_15_30_Mean_all = (np.mean(WT_15_30_all))
WT_30_45_Mean_all = (np.mean(WT_30_45_all))
WT_45_60_Mean_all = (np.mean(WT_45_60_all))
WT_60_75_Mean_all = (np.mean(WT_60_75_all))
WT_75_90_Mean_all = (np.mean(WT_75_90_all))
WT_90_105_Mean_all = (np.mean(WT_90_105_all))
WT_105_120_Mean_all = (np.mean(WT_105_120_all))

WT_120_135_Mean_all = (np.mean(WT_120_135_all))
WT_135_150_Mean_all = (np.mean(WT_135_150_all))
WT_150_165_Mean_all = (np.mean(WT_150_165_all))
WT_165_180_Mean_all = (np.mean(WT_165_180_all))
WT_180_195_Mean_all = (np.mean(WT_180_195_all))
WT_195_210_Mean_all = (np.mean(WT_195_210_all))
WT_210_225_Mean_all = (np.mean(WT_210_225_all))
WT_225_240_Mean_all = (np.mean(WT_225_240_all))

WT_240_255_Mean_all = (np.mean(WT_240_255_all))
WT_255_270_Mean_all = (np.mean(WT_255_270_all))
WT_270_285_Mean_all = (np.mean(WT_270_285_all))
WT_285_300_Mean_all = (np.mean(WT_285_300_all))
WT_300_315_Mean_all = (np.mean(WT_300_315_all))
WT_315_330_Mean_all = (np.mean(WT_315_330_all))
WT_330_345_Mean_all = (np.mean(WT_330_345_all))
WT_345_360_Mean_all = (np.mean(WT_345_360_all))

FLX_0_15_Mean_all = (np.mean(FLX_0_15_all))
FLX_15_30_Mean_all = (np.mean(FLX_15_30_all))
FLX_30_45_Mean_all = (np.mean(FLX_30_45_all))
FLX_45_60_Mean_all = (np.mean(FLX_45_60_all))
FLX_60_75_Mean_all = (np.mean(FLX_60_75_all))
FLX_75_90_Mean_all = (np.mean(FLX_75_90_all))
FLX_90_105_Mean_all = (np.mean(FLX_90_105_all))
FLX_105_120_Mean_all = (np.mean(FLX_105_120_all))

FLX_120_135_Mean_all = (np.mean(FLX_120_135_all))
FLX_135_150_Mean_all = (np.mean(FLX_135_150_all))
FLX_150_165_Mean_all = (np.mean(FLX_150_165_all))
FLX_165_180_Mean_all = (np.mean(FLX_165_180_all))
FLX_180_195_Mean_all = (np.mean(FLX_180_195_all))
FLX_195_210_Mean_all = (np.mean(FLX_195_210_all))
FLX_210_225_Mean_all = (np.mean(FLX_210_225_all))
FLX_225_240_Mean_all = (np.mean(FLX_225_240_all))

FLX_240_255_Mean_all = (np.mean(FLX_240_255_all))
FLX_255_270_Mean_all = (np.mean(FLX_255_270_all))
FLX_270_285_Mean_all = (np.mean(FLX_270_285_all))
FLX_285_300_Mean_all = (np.mean(FLX_285_300_all))
FLX_300_315_Mean_all = (np.mean(FLX_300_315_all))
FLX_315_330_Mean_all = (np.mean(FLX_315_330_all))
FLX_330_345_Mean_all = (np.mean(FLX_330_345_all))
FLX_345_360_Mean_all = (np.mean(FLX_345_360_all))



#For all nonpolar WT and FLX cells 
WT_0_15_Mean_nonpolar = (np.mean(WT_0_15_nonpolar))
WT_15_30_Mean_nonpolar = (np.mean(WT_15_30_nonpolar))
WT_30_45_Mean_nonpolar = (np.mean(WT_30_45_nonpolar))
WT_45_60_Mean_nonpolar = (np.mean(WT_45_60_nonpolar))
WT_60_75_Mean_nonpolar = (np.mean(WT_60_75_nonpolar))
WT_75_90_Mean_nonpolar = (np.mean(WT_75_90_nonpolar))
WT_90_105_Mean_nonpolar = (np.mean(WT_90_105_nonpolar))
WT_105_120_Mean_nonpolar = (np.mean(WT_105_120_nonpolar))

WT_120_135_Mean_nonpolar = (np.mean(WT_120_135_nonpolar))
WT_135_150_Mean_nonpolar = (np.mean(WT_135_150_nonpolar))
WT_150_165_Mean_nonpolar = (np.mean(WT_150_165_nonpolar))
WT_165_180_Mean_nonpolar = (np.mean(WT_165_180_nonpolar))
WT_180_195_Mean_nonpolar = (np.mean(WT_180_195_nonpolar))
WT_195_210_Mean_nonpolar = (np.mean(WT_195_210_nonpolar))
WT_210_225_Mean_nonpolar = (np.mean(WT_210_225_nonpolar))
WT_225_240_Mean_nonpolar = (np.mean(WT_225_240_nonpolar))

WT_240_255_Mean_nonpolar = (np.mean(WT_240_255_nonpolar))
WT_255_270_Mean_nonpolar = (np.mean(WT_255_270_nonpolar))
WT_270_285_Mean_nonpolar = (np.mean(WT_270_285_nonpolar))
WT_285_300_Mean_nonpolar = (np.mean(WT_285_300_nonpolar))
WT_300_315_Mean_nonpolar = (np.mean(WT_300_315_nonpolar))
WT_315_330_Mean_nonpolar = (np.mean(WT_315_330_nonpolar))
WT_330_345_Mean_nonpolar = (np.mean(WT_330_345_nonpolar))
WT_345_360_Mean_nonpolar = (np.mean(WT_345_360_nonpolar))

FLX_0_15_Mean_nonpolar = (np.mean(FLX_0_15_nonpolar))
FLX_15_30_Mean_nonpolar = (np.mean(FLX_15_30_nonpolar))
FLX_30_45_Mean_nonpolar = (np.mean(FLX_30_45_nonpolar))
FLX_45_60_Mean_nonpolar = (np.mean(FLX_45_60_nonpolar))
FLX_60_75_Mean_nonpolar = (np.mean(FLX_60_75_nonpolar))
FLX_75_90_Mean_nonpolar = (np.mean(FLX_75_90_nonpolar))
FLX_90_105_Mean_nonpolar = (np.mean(FLX_90_105_nonpolar))
FLX_105_120_Mean_nonpolar = (np.mean(FLX_105_120_nonpolar))

FLX_120_135_Mean_nonpolar = (np.mean(FLX_120_135_nonpolar))
FLX_135_150_Mean_nonpolar = (np.mean(FLX_135_150_nonpolar))
FLX_150_165_Mean_nonpolar = (np.mean(FLX_150_165_nonpolar))
FLX_165_180_Mean_nonpolar = (np.mean(FLX_165_180_nonpolar))
FLX_180_195_Mean_nonpolar = (np.mean(FLX_180_195_nonpolar))
FLX_195_210_Mean_nonpolar = (np.mean(FLX_195_210_nonpolar))
FLX_210_225_Mean_nonpolar = (np.mean(FLX_210_225_nonpolar))
FLX_225_240_Mean_nonpolar = (np.mean(FLX_225_240_nonpolar))

FLX_240_255_Mean_nonpolar = (np.mean(FLX_240_255_nonpolar))
FLX_255_270_Mean_nonpolar = (np.mean(FLX_255_270_nonpolar))
FLX_270_285_Mean_nonpolar = (np.mean(FLX_270_285_nonpolar))
FLX_285_300_Mean_nonpolar = (np.mean(FLX_285_300_nonpolar))
FLX_300_315_Mean_nonpolar = (np.mean(FLX_300_315_nonpolar))
FLX_315_330_Mean_nonpolar = (np.mean(FLX_315_330_nonpolar))
FLX_330_345_Mean_nonpolar = (np.mean(FLX_330_345_nonpolar))
FLX_345_360_Mean_nonpolar = (np.mean(FLX_345_360_nonpolar))



#For all polar WT and FLX cells 
WT_0_15_Mean_polar = (np.mean(WT_0_15_polar))
WT_15_30_Mean_polar = (np.mean(WT_15_30_polar))
WT_30_45_Mean_polar = (np.mean(WT_30_45_polar))
WT_45_60_Mean_polar = (np.mean(WT_45_60_polar))
WT_60_75_Mean_polar = (np.mean(WT_60_75_polar))
WT_75_90_Mean_polar = (np.mean(WT_75_90_polar))
WT_90_105_Mean_polar = (np.mean(WT_90_105_polar))
WT_105_120_Mean_polar = (np.mean(WT_105_120_polar))

WT_120_135_Mean_polar = (np.mean(WT_120_135_polar))
WT_135_150_Mean_polar = (np.mean(WT_135_150_polar))
WT_150_165_Mean_polar = (np.mean(WT_150_165_polar))
WT_165_180_Mean_polar = (np.mean(WT_165_180_polar))
WT_180_195_Mean_polar = (np.mean(WT_180_195_polar))
WT_195_210_Mean_polar = (np.mean(WT_195_210_polar))
WT_210_225_Mean_polar = (np.mean(WT_210_225_polar))
WT_225_240_Mean_polar = (np.mean(WT_225_240_polar))

WT_240_255_Mean_polar = (np.mean(WT_240_255_polar))
WT_255_270_Mean_polar = (np.mean(WT_255_270_polar))
WT_270_285_Mean_polar = (np.mean(WT_270_285_polar))
WT_285_300_Mean_polar = (np.mean(WT_285_300_polar))
WT_300_315_Mean_polar = (np.mean(WT_300_315_polar))
WT_315_330_Mean_polar = (np.mean(WT_315_330_polar))
WT_330_345_Mean_polar = (np.mean(WT_330_345_polar))
WT_345_360_Mean_polar = (np.mean(WT_345_360_polar))

FLX_0_15_Mean_polar = (np.mean(FLX_0_15_polar))
FLX_15_30_Mean_polar = (np.mean(FLX_15_30_polar))
FLX_30_45_Mean_polar = (np.mean(FLX_30_45_polar))
FLX_45_60_Mean_polar = (np.mean(FLX_45_60_polar))
FLX_60_75_Mean_polar = (np.mean(FLX_60_75_polar))
FLX_75_90_Mean_polar = (np.mean(FLX_75_90_polar))
FLX_90_105_Mean_polar = (np.mean(FLX_90_105_polar))
FLX_105_120_Mean_polar = (np.mean(FLX_105_120_polar))

FLX_120_135_Mean_polar = (np.mean(FLX_120_135_polar))
FLX_135_150_Mean_polar = (np.mean(FLX_135_150_polar))
FLX_150_165_Mean_polar = (np.mean(FLX_150_165_polar))
FLX_165_180_Mean_polar = (np.mean(FLX_165_180_polar))
FLX_180_195_Mean_polar = (np.mean(FLX_180_195_polar))
FLX_195_210_Mean_polar = (np.mean(FLX_195_210_polar))
FLX_210_225_Mean_polar = (np.mean(FLX_210_225_polar))
FLX_225_240_Mean_polar = (np.mean(FLX_225_240_polar))

FLX_240_255_Mean_polar = (np.mean(FLX_240_255_polar))
FLX_255_270_Mean_polar = (np.mean(FLX_255_270_polar))
FLX_270_285_Mean_polar = (np.mean(FLX_270_285_polar))
FLX_285_300_Mean_polar = (np.mean(FLX_285_300_polar))
FLX_300_315_Mean_polar = (np.mean(FLX_300_315_polar))
FLX_315_330_Mean_polar = (np.mean(FLX_315_330_polar))
FLX_330_345_Mean_polar = (np.mean(FLX_330_345_polar))
FLX_345_360_Mean_polar = (np.mean(FLX_345_360_polar))

###Calculate SEM

#For all cells
WT_0_15_SEM_all  = np.std(WT_0_15_all,ddof=1) / math.sqrt(len(WT_0_15_all))
WT_15_30_SEM_all = (np.std(WT_15_30_all,ddof=1) / math.sqrt(len(WT_15_30_all)))
WT_30_45_SEM_all = (np.std(WT_30_45_all,ddof=1) / math.sqrt(len(WT_30_45_all)))
WT_45_60_SEM_all = (np.std(WT_45_60_all,ddof=1) / math.sqrt(len(WT_45_60_all)))
WT_60_75_SEM_all = np.std(WT_60_75_all,ddof=1) / math.sqrt(len(WT_60_75_all))
WT_75_90_SEM_all = np.std(WT_75_90_all,ddof=1) / math.sqrt(len(WT_75_90_all))
WT_90_105_SEM_all = np.std(WT_90_105_all,ddof=1) / math.sqrt(len(WT_90_105_all))
WT_105_120_SEM_all = np.std(WT_105_120_all,ddof=1) / math.sqrt(len(WT_105_120_all))

WT_120_135_SEM_all  = np.std(WT_120_135_all,ddof=1) / math.sqrt(len(WT_120_135_all))
WT_135_150_SEM_all = (np.std(WT_135_150_all,ddof=1) / math.sqrt(len(WT_135_150_all)))
WT_150_165_SEM_all = (np.std(WT_150_165_all,ddof=1) / math.sqrt(len(WT_150_165_all)))
WT_165_180_SEM_all = np.std(WT_165_180_all,ddof=1) / math.sqrt(len(WT_165_180_all))
WT_180_195_SEM_all = np.std(WT_180_195_all,ddof=1) / math.sqrt(len(WT_180_195_all))
WT_195_210_SEM_all = np.std(WT_195_210_all,ddof=1) / math.sqrt(len(WT_195_210_all))
WT_210_225_SEM_all = np.std(WT_210_225_all,ddof=1) / math.sqrt(len(WT_210_225_all))
WT_225_240_SEM_all  = np.std(WT_225_240_all,ddof=1) / math.sqrt(len(WT_225_240_all))

WT_240_255_SEM_all = (np.std(WT_240_255_all,ddof=1) / math.sqrt(len(WT_240_255_all)))
WT_255_270_SEM_all = (np.std(WT_255_270_all,ddof=1) / math.sqrt(len(WT_255_270_all)))
WT_270_285_SEM_all = (np.std(WT_270_285_all,ddof=1) / math.sqrt(len(WT_270_285_all)))
WT_285_300_SEM_all = np.std(WT_285_300_all,ddof=1) / math.sqrt(len(WT_285_300_all))
WT_300_315_SEM_all = np.std(WT_300_315_all,ddof=1) / math.sqrt(len(WT_300_315_all))
WT_315_330_SEM_all = np.std(WT_315_330_all,ddof=1) / math.sqrt(len(WT_315_330_all))
WT_330_345_SEM_all = np.std(WT_330_345_all,ddof=1) / math.sqrt(len(WT_330_345_all))
WT_345_360_SEM_all = np.std(WT_345_360_all,ddof=1) / math.sqrt(len(WT_345_360_all))


FLX_0_15_SEM_all  = np.std(FLX_0_15_all,ddof=1) / math.sqrt(len(FLX_0_15_all))
FLX_15_30_SEM_all = (np.std(FLX_15_30_all,ddof=1) / math.sqrt(len(FLX_15_30_all)))
FLX_30_45_SEM_all = (np.std(FLX_30_45_all,ddof=1) / math.sqrt(len(FLX_30_45_all)))
FLX_45_60_SEM_all = (np.std(FLX_45_60_all,ddof=1) / math.sqrt(len(FLX_45_60_all)))
FLX_60_75_SEM_all = np.std(FLX_60_75_all,ddof=1) / math.sqrt(len(FLX_60_75_all))
FLX_75_90_SEM_all = np.std(FLX_75_90_all,ddof=1) / math.sqrt(len(FLX_75_90_all))
FLX_90_105_SEM_all = np.std(FLX_90_105_all,ddof=1) / math.sqrt(len(FLX_90_105_all))
FLX_105_120_SEM_all = np.std(FLX_105_120_all,ddof=1) / math.sqrt(len(FLX_105_120_all))

FLX_120_135_SEM_all  = np.std(FLX_120_135_all,ddof=1) / math.sqrt(len(FLX_120_135_all))
FLX_135_150_SEM_all = (np.std(FLX_135_150_all,ddof=1) / math.sqrt(len(FLX_135_150_all)))
FLX_150_165_SEM_all = (np.std(FLX_150_165_all,ddof=1) / math.sqrt(len(FLX_150_165_all)))
FLX_165_180_SEM_all = np.std(FLX_165_180_all,ddof=1) / math.sqrt(len(FLX_165_180_all))
FLX_180_195_SEM_all = np.std(FLX_180_195_all,ddof=1) / math.sqrt(len(FLX_180_195_all))
FLX_195_210_SEM_all = np.std(FLX_195_210_all,ddof=1) / math.sqrt(len(FLX_195_210_all))
FLX_210_225_SEM_all = np.std(FLX_210_225_all,ddof=1) / math.sqrt(len(FLX_210_225_all))
FLX_225_240_SEM_all  = np.std(FLX_225_240_all,ddof=1) / math.sqrt(len(FLX_225_240_all))

FLX_240_255_SEM_all = (np.std(FLX_240_255_all,ddof=1) / math.sqrt(len(FLX_240_255_all)))
FLX_255_270_SEM_all = (np.std(FLX_255_270_all,ddof=1) / math.sqrt(len(FLX_255_270_all)))
FLX_270_285_SEM_all = (np.std(FLX_270_285_all,ddof=1) / math.sqrt(len(FLX_270_285_all)))
FLX_285_300_SEM_all = np.std(FLX_285_300_all,ddof=1) / math.sqrt(len(FLX_285_300_all))
FLX_300_315_SEM_all = np.std(FLX_300_315_all,ddof=1) / math.sqrt(len(FLX_300_315_all))
FLX_315_330_SEM_all = np.std(FLX_315_330_all,ddof=1) / math.sqrt(len(FLX_315_330_all))
FLX_330_345_SEM_all = np.std(FLX_330_345_all,ddof=1) / math.sqrt(len(FLX_330_345_all))
FLX_345_360_SEM_all = np.std(FLX_345_360_all,ddof=1) / math.sqrt(len(FLX_345_360_all))




#For nonpolar cells
WT_0_15_SEM_nonpolar  = np.std(WT_0_15_nonpolar,ddof=1) / math.sqrt(len(WT_0_15_nonpolar))
WT_15_30_SEM_nonpolar = (np.std(WT_15_30_nonpolar,ddof=1) / math.sqrt(len(WT_15_30_nonpolar)))
WT_30_45_SEM_nonpolar = (np.std(WT_30_45_nonpolar,ddof=1) / math.sqrt(len(WT_30_45_nonpolar)))
WT_45_60_SEM_nonpolar = (np.std(WT_45_60_nonpolar,ddof=1) / math.sqrt(len(WT_45_60_nonpolar)))
WT_60_75_SEM_nonpolar = np.std(WT_60_75_nonpolar,ddof=1) / math.sqrt(len(WT_60_75_nonpolar))
WT_75_90_SEM_nonpolar = np.std(WT_75_90_nonpolar,ddof=1) / math.sqrt(len(WT_75_90_nonpolar))
WT_90_105_SEM_nonpolar = np.std(WT_90_105_nonpolar,ddof=1) / math.sqrt(len(WT_90_105_nonpolar))
WT_105_120_SEM_nonpolar = np.std(WT_105_120_nonpolar,ddof=1) / math.sqrt(len(WT_105_120_nonpolar))

WT_120_135_SEM_nonpolar  = np.std(WT_120_135_nonpolar,ddof=1) / math.sqrt(len(WT_120_135_nonpolar))
WT_135_150_SEM_nonpolar = (np.std(WT_135_150_nonpolar,ddof=1) / math.sqrt(len(WT_135_150_nonpolar)))
WT_150_165_SEM_nonpolar = (np.std(WT_150_165_nonpolar,ddof=1) / math.sqrt(len(WT_150_165_nonpolar)))
WT_165_180_SEM_nonpolar = np.std(WT_165_180_nonpolar,ddof=1) / math.sqrt(len(WT_165_180_nonpolar))
WT_180_195_SEM_nonpolar = np.std(WT_180_195_nonpolar,ddof=1) / math.sqrt(len(WT_180_195_nonpolar))
WT_195_210_SEM_nonpolar = np.std(WT_195_210_nonpolar,ddof=1) / math.sqrt(len(WT_195_210_nonpolar))
WT_210_225_SEM_nonpolar = np.std(WT_210_225_nonpolar,ddof=1) / math.sqrt(len(WT_210_225_nonpolar))
WT_225_240_SEM_nonpolar  = np.std(WT_225_240_nonpolar,ddof=1) / math.sqrt(len(WT_225_240_nonpolar))

WT_240_255_SEM_nonpolar = (np.std(WT_240_255_nonpolar,ddof=1) / math.sqrt(len(WT_240_255_nonpolar)))
WT_255_270_SEM_nonpolar = (np.std(WT_255_270_nonpolar,ddof=1) / math.sqrt(len(WT_255_270_nonpolar)))
WT_270_285_SEM_nonpolar = (np.std(WT_270_285_nonpolar,ddof=1) / math.sqrt(len(WT_270_285_nonpolar)))
WT_285_300_SEM_nonpolar = np.std(WT_285_300_nonpolar,ddof=1) / math.sqrt(len(WT_285_300_nonpolar))
WT_300_315_SEM_nonpolar = np.std(WT_300_315_nonpolar,ddof=1) / math.sqrt(len(WT_300_315_nonpolar))
WT_315_330_SEM_nonpolar = np.std(WT_315_330_nonpolar,ddof=1) / math.sqrt(len(WT_315_330_nonpolar))
WT_330_345_SEM_nonpolar = np.std(WT_330_345_nonpolar,ddof=1) / math.sqrt(len(WT_330_345_nonpolar))
WT_345_360_SEM_nonpolar = np.std(WT_345_360_nonpolar,ddof=1) / math.sqrt(len(WT_345_360_nonpolar))


FLX_0_15_SEM_nonpolar  = np.std(FLX_0_15_nonpolar,ddof=1) / math.sqrt(len(FLX_0_15_nonpolar))
FLX_15_30_SEM_nonpolar = (np.std(FLX_15_30_nonpolar,ddof=1) / math.sqrt(len(FLX_15_30_nonpolar)))
FLX_30_45_SEM_nonpolar = (np.std(FLX_30_45_nonpolar,ddof=1) / math.sqrt(len(FLX_30_45_nonpolar)))
FLX_45_60_SEM_nonpolar = (np.std(FLX_45_60_nonpolar,ddof=1) / math.sqrt(len(FLX_45_60_nonpolar)))
FLX_60_75_SEM_nonpolar = np.std(FLX_60_75_nonpolar,ddof=1) / math.sqrt(len(FLX_60_75_nonpolar))
FLX_75_90_SEM_nonpolar = np.std(FLX_75_90_nonpolar,ddof=1) / math.sqrt(len(FLX_75_90_nonpolar))
FLX_90_105_SEM_nonpolar = np.std(FLX_90_105_nonpolar,ddof=1) / math.sqrt(len(FLX_90_105_nonpolar))
FLX_105_120_SEM_nonpolar = np.std(FLX_105_120_nonpolar,ddof=1) / math.sqrt(len(FLX_105_120_nonpolar))

FLX_120_135_SEM_nonpolar  = np.std(FLX_120_135_nonpolar,ddof=1) / math.sqrt(len(FLX_120_135_nonpolar))
FLX_135_150_SEM_nonpolar = (np.std(FLX_135_150_nonpolar,ddof=1) / math.sqrt(len(FLX_135_150_nonpolar)))
FLX_150_165_SEM_nonpolar = (np.std(FLX_150_165_nonpolar,ddof=1) / math.sqrt(len(FLX_150_165_nonpolar)))
FLX_165_180_SEM_nonpolar = np.std(FLX_165_180_nonpolar,ddof=1) / math.sqrt(len(FLX_165_180_nonpolar))
FLX_180_195_SEM_nonpolar = np.std(FLX_180_195_nonpolar,ddof=1) / math.sqrt(len(FLX_180_195_nonpolar))
FLX_195_210_SEM_nonpolar = np.std(FLX_195_210_nonpolar,ddof=1) / math.sqrt(len(FLX_195_210_nonpolar))
FLX_210_225_SEM_nonpolar = np.std(FLX_210_225_nonpolar,ddof=1) / math.sqrt(len(FLX_210_225_nonpolar))
FLX_225_240_SEM_nonpolar  = np.std(FLX_225_240_nonpolar,ddof=1) / math.sqrt(len(FLX_225_240_nonpolar))

FLX_240_255_SEM_nonpolar = (np.std(FLX_240_255_nonpolar,ddof=1) / math.sqrt(len(FLX_240_255_nonpolar)))
FLX_255_270_SEM_nonpolar = (np.std(FLX_255_270_nonpolar,ddof=1) / math.sqrt(len(FLX_255_270_nonpolar)))
FLX_270_285_SEM_nonpolar = (np.std(FLX_270_285_nonpolar,ddof=1) / math.sqrt(len(FLX_270_285_nonpolar)))
FLX_285_300_SEM_nonpolar = np.std(FLX_285_300_nonpolar,ddof=1) / math.sqrt(len(FLX_285_300_nonpolar))
FLX_300_315_SEM_nonpolar = np.std(FLX_300_315_nonpolar,ddof=1) / math.sqrt(len(FLX_300_315_nonpolar))
FLX_315_330_SEM_nonpolar = np.std(FLX_315_330_nonpolar,ddof=1) / math.sqrt(len(FLX_315_330_nonpolar))
FLX_330_345_SEM_nonpolar = np.std(FLX_330_345_nonpolar,ddof=1) / math.sqrt(len(FLX_330_345_nonpolar))
FLX_345_360_SEM_nonpolar = np.std(FLX_345_360_nonpolar,ddof=1) / math.sqrt(len(FLX_345_360_nonpolar))




#For polar cells
WT_0_15_SEM_polar  = np.std(WT_0_15_polar,ddof=1) / math.sqrt(len(WT_0_15_polar))
WT_15_30_SEM_polar = (np.std(WT_15_30_polar,ddof=1) / math.sqrt(len(WT_15_30_polar)))
WT_30_45_SEM_polar = (np.std(WT_30_45_polar,ddof=1) / math.sqrt(len(WT_30_45_polar)))
WT_45_60_SEM_polar = (np.std(WT_45_60_polar,ddof=1) / math.sqrt(len(WT_45_60_polar)))
WT_60_75_SEM_polar = np.std(WT_60_75_polar,ddof=1) / math.sqrt(len(WT_60_75_polar))
WT_75_90_SEM_polar = np.std(WT_75_90_polar,ddof=1) / math.sqrt(len(WT_75_90_polar))
WT_90_105_SEM_polar = np.std(WT_90_105_polar,ddof=1) / math.sqrt(len(WT_90_105_polar))
WT_105_120_SEM_polar = np.std(WT_105_120_polar,ddof=1) / math.sqrt(len(WT_105_120_polar))

WT_120_135_SEM_polar  = np.std(WT_120_135_polar,ddof=1) / math.sqrt(len(WT_120_135_polar))
WT_135_150_SEM_polar = (np.std(WT_135_150_polar,ddof=1) / math.sqrt(len(WT_135_150_polar)))
WT_150_165_SEM_polar = (np.std(WT_150_165_polar,ddof=1) / math.sqrt(len(WT_150_165_polar)))
WT_165_180_SEM_polar = np.std(WT_165_180_polar,ddof=1) / math.sqrt(len(WT_165_180_polar))
WT_180_195_SEM_polar = np.std(WT_180_195_polar,ddof=1) / math.sqrt(len(WT_180_195_polar))
WT_195_210_SEM_polar = np.std(WT_195_210_polar,ddof=1) / math.sqrt(len(WT_195_210_polar))
WT_210_225_SEM_polar = np.std(WT_210_225_polar,ddof=1) / math.sqrt(len(WT_210_225_polar))
WT_225_240_SEM_polar  = np.std(WT_225_240_polar,ddof=1) / math.sqrt(len(WT_225_240_polar))

WT_240_255_SEM_polar = (np.std(WT_240_255_polar,ddof=1) / math.sqrt(len(WT_240_255_polar)))
WT_255_270_SEM_polar = (np.std(WT_255_270_polar,ddof=1) / math.sqrt(len(WT_255_270_polar)))
WT_270_285_SEM_polar = (np.std(WT_270_285_polar,ddof=1) / math.sqrt(len(WT_270_285_polar)))
WT_285_300_SEM_polar = np.std(WT_285_300_polar,ddof=1) / math.sqrt(len(WT_285_300_polar))
WT_300_315_SEM_polar = np.std(WT_300_315_polar,ddof=1) / math.sqrt(len(WT_300_315_polar))
WT_315_330_SEM_polar = np.std(WT_315_330_polar,ddof=1) / math.sqrt(len(WT_315_330_polar))
WT_330_345_SEM_polar = np.std(WT_330_345_polar,ddof=1) / math.sqrt(len(WT_330_345_polar))
WT_345_360_SEM_polar = np.std(WT_345_360_polar,ddof=1) / math.sqrt(len(WT_345_360_polar))


FLX_0_15_SEM_polar  = np.std(FLX_0_15_polar,ddof=1) / math.sqrt(len(FLX_0_15_polar))
FLX_15_30_SEM_polar = (np.std(FLX_15_30_polar,ddof=1) / math.sqrt(len(FLX_15_30_polar)))
FLX_30_45_SEM_polar = (np.std(FLX_30_45_polar,ddof=1) / math.sqrt(len(FLX_30_45_polar)))
FLX_45_60_SEM_polar = (np.std(FLX_45_60_polar,ddof=1) / math.sqrt(len(FLX_45_60_polar)))
FLX_60_75_SEM_polar = np.std(FLX_60_75_polar,ddof=1) / math.sqrt(len(FLX_60_75_polar))
FLX_75_90_SEM_polar = np.std(FLX_75_90_polar,ddof=1) / math.sqrt(len(FLX_75_90_polar))
FLX_90_105_SEM_polar = np.std(FLX_90_105_polar,ddof=1) / math.sqrt(len(FLX_90_105_polar))
FLX_105_120_SEM_polar = np.std(FLX_105_120_polar,ddof=1) / math.sqrt(len(FLX_105_120_polar))

FLX_120_135_SEM_polar  = np.std(FLX_120_135_polar,ddof=1) / math.sqrt(len(FLX_120_135_polar))
FLX_135_150_SEM_polar = (np.std(FLX_135_150_polar,ddof=1) / math.sqrt(len(FLX_135_150_polar)))
FLX_150_165_SEM_polar = (np.std(FLX_150_165_polar,ddof=1) / math.sqrt(len(FLX_150_165_polar)))
FLX_165_180_SEM_polar = np.std(FLX_165_180_polar,ddof=1) / math.sqrt(len(FLX_165_180_polar))
FLX_180_195_SEM_polar = np.std(FLX_180_195_polar,ddof=1) / math.sqrt(len(FLX_180_195_polar))
FLX_195_210_SEM_polar = np.std(FLX_195_210_polar,ddof=1) / math.sqrt(len(FLX_195_210_polar))
FLX_210_225_SEM_polar = np.std(FLX_210_225_polar,ddof=1) / math.sqrt(len(FLX_210_225_polar))
FLX_225_240_SEM_polar  = np.std(FLX_225_240_polar,ddof=1) / math.sqrt(len(FLX_225_240_polar))

FLX_240_255_SEM_polar = (np.std(FLX_240_255_polar,ddof=1) / math.sqrt(len(FLX_240_255_polar)))
FLX_255_270_SEM_polar = (np.std(FLX_255_270_polar,ddof=1) / math.sqrt(len(FLX_255_270_polar)))
FLX_270_285_SEM_polar = (np.std(FLX_270_285_polar,ddof=1) / math.sqrt(len(FLX_270_285_polar)))
FLX_285_300_SEM_polar = np.std(FLX_285_300_polar,ddof=1) / math.sqrt(len(FLX_285_300_polar))
FLX_300_315_SEM_polar = np.std(FLX_300_315_polar,ddof=1) / math.sqrt(len(FLX_300_315_polar))
FLX_315_330_SEM_polar = np.std(FLX_315_330_polar,ddof=1) / math.sqrt(len(FLX_315_330_polar))
FLX_330_345_SEM_polar = np.std(FLX_330_345_polar,ddof=1) / math.sqrt(len(FLX_330_345_polar))
FLX_345_360_SEM_polar = np.std(FLX_345_360_polar,ddof=1) / math.sqrt(len(FLX_345_360_polar))

### Setup some values for graphing 
wt_yvalue_all = [WT_0_15_Mean_all, WT_15_30_Mean_all,WT_30_45_Mean_all,WT_45_60_Mean_all,WT_60_75_Mean_all,WT_75_90_Mean_all,WT_90_105_Mean_all,WT_105_120_Mean_all, 
             WT_120_135_Mean_all, WT_135_150_Mean_all,WT_150_165_Mean_all,WT_165_180_Mean_all,WT_180_195_Mean_all,WT_195_210_Mean_all,WT_210_225_Mean_all,WT_225_240_Mean_all,
             WT_240_255_Mean_all, WT_255_270_Mean_all,WT_270_285_Mean_all,WT_285_300_Mean_all,WT_300_315_Mean_all,WT_315_330_Mean_all,WT_330_345_Mean_all,WT_345_360_Mean_all]
FLX_yvalue_all = [FLX_0_15_Mean_all, FLX_15_30_Mean_all,FLX_30_45_Mean_all,FLX_45_60_Mean_all,FLX_60_75_Mean_all,FLX_75_90_Mean_all,FLX_90_105_Mean_all,FLX_105_120_Mean_all, 
             FLX_120_135_Mean_all, FLX_135_150_Mean_all,FLX_150_165_Mean_all,FLX_165_180_Mean_all,FLX_180_195_Mean_all,FLX_195_210_Mean_all,FLX_210_225_Mean_all,FLX_225_240_Mean_all,
             FLX_240_255_Mean_all, FLX_255_270_Mean_all,FLX_270_285_Mean_all,FLX_285_300_Mean_all,FLX_300_315_Mean_all,FLX_315_330_Mean_all,FLX_330_345_Mean_all,FLX_345_360_Mean_all]
wt_yerr_all =  [WT_0_15_SEM_all, WT_15_30_SEM_all,WT_30_45_SEM_all,WT_45_60_SEM_all,WT_60_75_SEM_all,WT_75_90_SEM_all,WT_90_105_SEM_all,WT_105_120_SEM_all, 
             WT_120_135_SEM_all, WT_135_150_SEM_all,WT_150_165_SEM_all,WT_165_180_SEM_all,WT_180_195_SEM_all,WT_195_210_SEM_all,WT_210_225_SEM_all,WT_225_240_SEM_all,
             WT_240_255_SEM_all, WT_255_270_SEM_all,WT_270_285_SEM_all,WT_285_300_SEM_all,WT_300_315_SEM_all,WT_315_330_SEM_all,WT_330_345_SEM_all,WT_345_360_SEM_all]
FLX_yerr_all = [FLX_0_15_SEM_all, FLX_15_30_SEM_all,FLX_30_45_SEM_all,FLX_45_60_SEM_all,FLX_60_75_SEM_all,FLX_75_90_SEM_all,FLX_90_105_SEM_all,FLX_105_120_SEM_all, 
             FLX_120_135_SEM_all, FLX_135_150_SEM_all,FLX_150_165_SEM_all,FLX_165_180_SEM_all,FLX_180_195_SEM_all,FLX_195_210_SEM_all,FLX_210_225_SEM_all,FLX_225_240_SEM_all,
             FLX_240_255_SEM_all, FLX_255_270_SEM_all,FLX_270_285_SEM_all,FLX_285_300_SEM_all,FLX_300_315_SEM_all,FLX_315_330_SEM_all,FLX_330_345_SEM_all,FLX_345_360_SEM_all]


wt_yvalue_nonpolar = [WT_0_15_Mean_nonpolar, WT_15_30_Mean_nonpolar,WT_30_45_Mean_nonpolar,WT_45_60_Mean_nonpolar,WT_60_75_Mean_nonpolar,WT_75_90_Mean_nonpolar,WT_90_105_Mean_nonpolar,WT_105_120_Mean_nonpolar, 
             WT_120_135_Mean_nonpolar, WT_135_150_Mean_nonpolar,WT_150_165_Mean_nonpolar,WT_165_180_Mean_nonpolar,WT_180_195_Mean_nonpolar,WT_195_210_Mean_nonpolar,WT_210_225_Mean_nonpolar,WT_225_240_Mean_nonpolar,
             WT_240_255_Mean_nonpolar, WT_255_270_Mean_nonpolar,WT_270_285_Mean_nonpolar,WT_285_300_Mean_nonpolar,WT_300_315_Mean_nonpolar,WT_315_330_Mean_nonpolar,WT_330_345_Mean_nonpolar,WT_345_360_Mean_nonpolar]
FLX_yvalue_nonpolar = [FLX_0_15_Mean_nonpolar, FLX_15_30_Mean_nonpolar,FLX_30_45_Mean_nonpolar,FLX_45_60_Mean_nonpolar,FLX_60_75_Mean_nonpolar,FLX_75_90_Mean_nonpolar,FLX_90_105_Mean_nonpolar,FLX_105_120_Mean_nonpolar, 
             FLX_120_135_Mean_nonpolar, FLX_135_150_Mean_nonpolar,FLX_150_165_Mean_nonpolar,FLX_165_180_Mean_nonpolar,FLX_180_195_Mean_nonpolar,FLX_195_210_Mean_nonpolar,FLX_210_225_Mean_nonpolar,FLX_225_240_Mean_nonpolar,
             FLX_240_255_Mean_nonpolar, FLX_255_270_Mean_nonpolar,FLX_270_285_Mean_nonpolar,FLX_285_300_Mean_nonpolar,FLX_300_315_Mean_nonpolar,FLX_315_330_Mean_nonpolar,FLX_330_345_Mean_nonpolar,FLX_345_360_Mean_nonpolar]
wt_yerr_nonpolar =  [WT_0_15_SEM_nonpolar, WT_15_30_SEM_nonpolar,WT_30_45_SEM_nonpolar,WT_45_60_SEM_nonpolar,WT_60_75_SEM_nonpolar,WT_75_90_SEM_nonpolar,WT_90_105_SEM_nonpolar,WT_105_120_SEM_nonpolar, 
             WT_120_135_SEM_nonpolar, WT_135_150_SEM_nonpolar,WT_150_165_SEM_nonpolar,WT_165_180_SEM_nonpolar,WT_180_195_SEM_nonpolar,WT_195_210_SEM_nonpolar,WT_210_225_SEM_nonpolar,WT_225_240_SEM_nonpolar,
             WT_240_255_SEM_nonpolar, WT_255_270_SEM_nonpolar,WT_270_285_SEM_nonpolar,WT_285_300_SEM_nonpolar,WT_300_315_SEM_nonpolar,WT_315_330_SEM_nonpolar,WT_330_345_SEM_nonpolar,WT_345_360_SEM_nonpolar]
FLX_yerr_nonpolar = [FLX_0_15_SEM_nonpolar, FLX_15_30_SEM_nonpolar,FLX_30_45_SEM_nonpolar,FLX_45_60_SEM_nonpolar,FLX_60_75_SEM_nonpolar,FLX_75_90_SEM_nonpolar,FLX_90_105_SEM_nonpolar,FLX_105_120_SEM_nonpolar, 
             FLX_120_135_SEM_nonpolar, FLX_135_150_SEM_nonpolar,FLX_150_165_SEM_nonpolar,FLX_165_180_SEM_nonpolar,FLX_180_195_SEM_nonpolar,FLX_195_210_SEM_nonpolar,FLX_210_225_SEM_nonpolar,FLX_225_240_SEM_nonpolar,
             FLX_240_255_SEM_nonpolar, FLX_255_270_SEM_nonpolar,FLX_270_285_SEM_nonpolar,FLX_285_300_SEM_nonpolar,FLX_300_315_SEM_nonpolar,FLX_315_330_SEM_nonpolar,FLX_330_345_SEM_nonpolar,FLX_345_360_SEM_nonpolar]


wt_yvalue_polar = [WT_0_15_Mean_polar, WT_15_30_Mean_polar,WT_30_45_Mean_polar,WT_45_60_Mean_polar,WT_60_75_Mean_polar,WT_75_90_Mean_polar,WT_90_105_Mean_polar,WT_105_120_Mean_polar, 
             WT_120_135_Mean_polar, WT_135_150_Mean_polar,WT_150_165_Mean_polar,WT_165_180_Mean_polar,WT_180_195_Mean_polar,WT_195_210_Mean_polar,WT_210_225_Mean_polar,WT_225_240_Mean_polar,
             WT_240_255_Mean_polar, WT_255_270_Mean_polar,WT_270_285_Mean_polar,WT_285_300_Mean_polar,WT_300_315_Mean_polar,WT_315_330_Mean_polar,WT_330_345_Mean_polar,WT_345_360_Mean_polar]
FLX_yvalue_polar = [FLX_0_15_Mean_polar, FLX_15_30_Mean_polar,FLX_30_45_Mean_polar,FLX_45_60_Mean_polar,FLX_60_75_Mean_polar,FLX_75_90_Mean_polar,FLX_90_105_Mean_polar,FLX_105_120_Mean_polar, 
             FLX_120_135_Mean_polar, FLX_135_150_Mean_polar,FLX_150_165_Mean_polar,FLX_165_180_Mean_polar,FLX_180_195_Mean_polar,FLX_195_210_Mean_polar,FLX_210_225_Mean_polar,FLX_225_240_Mean_polar,
             FLX_240_255_Mean_polar, FLX_255_270_Mean_polar,FLX_270_285_Mean_polar,FLX_285_300_Mean_polar,FLX_300_315_Mean_polar,FLX_315_330_Mean_polar,FLX_330_345_Mean_polar,FLX_345_360_Mean_polar]
wt_yerr_polar =  [WT_0_15_SEM_polar, WT_15_30_SEM_polar,WT_30_45_SEM_polar,WT_45_60_SEM_polar,WT_60_75_SEM_polar,WT_75_90_SEM_polar,WT_90_105_SEM_polar,WT_105_120_SEM_polar, 
             WT_120_135_SEM_polar, WT_135_150_SEM_polar,WT_150_165_SEM_polar,WT_165_180_SEM_polar,WT_180_195_SEM_polar,WT_195_210_SEM_polar,WT_210_225_SEM_polar,WT_225_240_SEM_polar,
             WT_240_255_SEM_polar, WT_255_270_SEM_polar,WT_270_285_SEM_polar,WT_285_300_SEM_polar,WT_300_315_SEM_polar,WT_315_330_SEM_polar,WT_330_345_SEM_polar,WT_345_360_SEM_polar]
FLX_yerr_polar = [FLX_0_15_SEM_polar, FLX_15_30_SEM_polar,FLX_30_45_SEM_polar,FLX_45_60_SEM_polar,FLX_60_75_SEM_polar,FLX_75_90_SEM_polar,FLX_90_105_SEM_polar,FLX_105_120_SEM_polar, 
             FLX_120_135_SEM_polar, FLX_135_150_SEM_polar,FLX_150_165_SEM_polar,FLX_165_180_SEM_polar,FLX_180_195_SEM_polar,FLX_195_210_SEM_polar,FLX_210_225_SEM_polar,FLX_225_240_SEM_polar,
             FLX_240_255_SEM_polar, FLX_255_270_SEM_polar,FLX_270_285_SEM_polar,FLX_285_300_SEM_polar,FLX_300_315_SEM_polar,FLX_315_330_SEM_polar,FLX_330_345_SEM_polar,FLX_345_360_SEM_polar]


#Make Blank Figure
fig,axs = plot.subplots(nrows=2, ncols=2, sharex=False, sharey=False)

###Plot WT vs FLX all cells included, regardless of polarity status
ax=axs[0,0]
# ax.set_ylim(0,1)
# ax.set_ylim(0,0.0006)
#Plot WT + KO Dev Graph
group_n = 24
ax.set_title('All WT vs All FLX Radial Sholl')
xvalue = np.arange(group_n)

### This bit makes scattered x-values if you're using individual cell datapoints with jitter. Not recommended for these
### plots. It looks very messy and crowded.
# WT0_15_xcoords = []
# WT0_15_xcoords = [uniform(-0.05,0.05) for value in WT_0_15_all]
# # print WT_xcoords
# 
# WT15_30_xcoords = []
# WT15_30_xcoords = [uniform(0.95,1.05) for value in WT_15_30_all]
# # print WT_xcoords
# 
# WT30_45_xcoords = []
# WT30_45_xcoords = [uniform(1.95,2.05) for value in WT_30_45_all]
# # print WT_xcoords
# 
# WT45_60_xcoords = []
# WT45_60_xcoords = [uniform(2.95,3.05) for value in WT_45_60_all]
# 
# WT60_75_xcoords = []
# WT60_75_xcoords = [uniform(3.95,4.05) for value in WT_60_75_all]
# # print WT_xcoords
# 
# WT75_90_xcoords = []
# WT75_90_xcoords = [uniform(4.95,5.05) for value in WT_75_90_all]
# # print WT_xcoords
# 
# WT90_105_xcoords = []
# WT90_105_xcoords = [uniform(5.95,6.05) for value in WT_90_105_all]
# # print WT_xcoords
# 
# WT105_120_xcoords = []
# WT105_120_xcoords = [uniform(6.95,7.05) for value in WT_105_120_all]
# # print WT_xcoords
# 
# 
# WT120_135_xcoords = []
# WT120_135_xcoords = [uniform(7.955,8.05) for value in WT_120_135_all]
# # print WT_xcoords
# 
# WT135_150_xcoords = []
# WT135_150_xcoords = [uniform(8.95,9.05) for value in WT_135_150_all]
# # print WT_xcoords
# 
# WT150_165_xcoords = []
# WT150_165_xcoords = [uniform(9.95,10.05) for value in WT_150_165_all]
# # print WT_xcoords
# 
# WT165_180_xcoords = []
# WT165_180_xcoords = [uniform(10.95,11.05) for value in WT_165_180_all]
# 
# WT180_195_xcoords = []
# WT180_195_xcoords = [uniform(11.95,12.05) for value in WT_180_195_all]
# # print WT_xcoords
# 
# WT195_210_xcoords = []
# WT195_210_xcoords = [uniform(12.95,13.05) for value in WT_195_210_all]
# # print WT_xcoords
# 
# WT210_225_xcoords = []
# WT210_225_xcoords = [uniform(13.95,14.05) for value in WT_210_225_all]
# # print WT_xcoords
# 
# WT225_240_xcoords = []
# WT225_240_xcoords = [uniform(14.95,15.05) for value in WT_225_240_all]
# # print WT_xcoords
# 
# 
# WT240_255_xcoords = []
# WT240_255_xcoords = [uniform(15.95,16.05) for value in WT_240_255_all]
# # print WT_xcoords
# 
# WT255_270_xcoords = []
# WT255_270_xcoords = [uniform(16.95,17.05) for value in WT_255_270_all]
# # print WT_xcoords
# 
# WT270_285_xcoords = []
# WT270_285_xcoords = [uniform(17.95,18.05) for value in WT_270_285_all]
# # print WT_xcoords
# 
# WT285_300_xcoords = []
# WT285_300_xcoords = [uniform(18.95,19.05) for value in WT_285_300_all]
# 
# WT300_315_xcoords = []
# WT300_315_xcoords = [uniform(19.95,20.05) for value in WT_300_315_all]
# # print WT_xcoords
# 
# WT315_330_xcoords = []
# WT315_330_xcoords = [uniform(20.95,21.05) for value in WT_315_330_all]
# # print WT_xcoords
# 
# WT330_345_xcoords = []
# WT330_345_xcoords = [uniform(21.95,22.05) for value in WT_330_345_all]
# # print WT_xcoords
# 
# WT345_360_xcoords = []
# WT345_360_xcoords = [uniform(22.95,23.05) for value in WT_345_360_all]
# # print WT_xcoords
# 
# 
# 
# 
# 
# FLX0_15_xcoords = []
# FLX0_15_xcoords = [uniform(0.35,0.45) for value in FLX_0_15_all]
# # print FLX_xcoords
# 
# FLX15_30_xcoords = []
# FLX15_30_xcoords = [uniform(1.35,1.45) for value in FLX_15_30_all]
# # print FLX_xcoords
# 
# FLX30_45_xcoords = []
# FLX30_45_xcoords = [uniform(2.35,2.45) for value in FLX_30_45_all]
# # print FLX_xcoords
# 
# FLX45_60_xcoords = []
# FLX45_60_xcoords = [uniform(3.35,3.45) for value in FLX_45_60_all]
# 
# FLX60_75_xcoords = []
# FLX60_75_xcoords = [uniform(4.35,4.45) for value in FLX_60_75_all]
# # print FLX_xcoords
# 
# FLX75_90_xcoords = []
# FLX75_90_xcoords = [uniform(5.35,5.45) for value in FLX_75_90_all]
# # print FLX_xcoords
# 
# FLX90_105_xcoords = []
# FLX90_105_xcoords = [uniform(6.35,6.45) for value in FLX_90_105_all]
# # print FLX_xcoords
# 
# FLX105_120_xcoords = []
# FLX105_120_xcoords = [uniform(7.35,7.45) for value in FLX_105_120_all]
# # print FLX_xcoords
# 
# 
# FLX120_135_xcoords = []
# FLX120_135_xcoords = [uniform(8.35,8.45) for value in FLX_120_135_all]
# # print FLX_xcoords
# 
# FLX135_150_xcoords = []
# FLX135_150_xcoords = [uniform(9.35,9.45) for value in FLX_135_150_all]
# # print FLX_xcoords
# 
# FLX150_165_xcoords = []
# FLX150_165_xcoords = [uniform(10.35,10.45) for value in FLX_150_165_all]
# # print FLX_xcoords
# 
# FLX165_180_xcoords = []
# FLX165_180_xcoords = [uniform(11.35,11.45) for value in FLX_165_180_all]
# 
# FLX180_195_xcoords = []
# FLX180_195_xcoords = [uniform(12.35,12.45) for value in FLX_180_195_all]
# # print FLX_xcoords
# 
# FLX195_210_xcoords = []
# FLX195_210_xcoords = [uniform(13.35,13.45) for value in FLX_195_210_all]
# # print FLX_xcoords
# 
# FLX210_225_xcoords = []
# FLX210_225_xcoords = [uniform(14.35,14.45) for value in FLX_210_225_all]
# # print FLX_xcoords
# 
# FLX225_240_xcoords = []
# FLX225_240_xcoords = [uniform(15.35,15.45) for value in FLX_225_240_all]
# # print FLX_xcoords
# 
# 
# FLX240_255_xcoords = []
# FLX240_255_xcoords = [uniform(16.35,16.45) for value in FLX_240_255_all]
# # print FLX_xcoords
# 
# FLX255_270_xcoords = []
# FLX255_270_xcoords = [uniform(7.35,17.45) for value in FLX_255_270_all]
# # print FLX_xcoords
# 
# FLX270_285_xcoords = []
# FLX270_285_xcoords = [uniform(18.35,18.45) for value in FLX_270_285_all]
# # print FLX_xcoords
# 
# FLX285_300_xcoords = []
# FLX285_300_xcoords = [uniform(19.35,19.45) for value in FLX_285_300_all]
# 
# FLX300_315_xcoords = []
# FLX300_315_xcoords = [uniform(20.35,20.45) for value in FLX_300_315_all]
# # print FLX_xcoords
# 
# FLX315_330_xcoords = []
# FLX315_330_xcoords = [uniform(21.35,21.45) for value in FLX_315_330_all]
# # print FLX_xcoords
# 
# FLX330_345_xcoords = []
# FLX330_345_xcoords = [uniform(22.35,22.45) for value in FLX_330_345_all]
# # print FLX_xcoords
# 
# FLX345_360_xcoords = []
# FLX345_360_xcoords = [uniform(23.35,23.45) for value in FLX_345_360_all]
# # print FLX_xcoords

All_line_xvalue = (0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23)
ax.plot((All_line_xvalue),(wt_yvalue_all),color = '#343434')
ax.plot((All_line_xvalue),(FLX_yvalue_all),color = '#df3325')


ax.scatter(0,WT_0_15_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT0_15_xcoords,WT_0_15_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,WT_15_30_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT15_30_xcoords,WT_15_30_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,WT_30_45_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT30_45_xcoords,WT_30_45_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,WT_45_60_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT45_60_xcoords,WT_45_60_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,WT_60_75_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT60_75_xcoords,WT_60_75_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,WT_75_90_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT75_90_xcoords,WT_75_90_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,WT_90_105_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT90_105_xcoords,WT_90_105_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,WT_105_120_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT105_120_xcoords,WT_105_120_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,WT_120_135_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT120_135_xcoords,WT_120_135_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,WT_135_150_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT135_150_xcoords,WT_135_150_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,WT_150_165_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT150_165_xcoords,WT_150_165_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,WT_165_180_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT165_180_xcoords,WT_165_180_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,WT_180_195_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT180_195_xcoords,WT_180_195_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,WT_195_210_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT195_210_xcoords,WT_195_210_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,WT_210_225_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT210_225_xcoords,WT_210_225_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,WT_225_240_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT225_240_xcoords,WT_225_240_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,WT_240_255_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT240_255_xcoords,WT_240_255_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,WT_255_270_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT255_270_xcoords,WT_255_270_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,WT_270_285_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT270_285_xcoords,WT_270_285_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,WT_285_300_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT285_300_xcoords,WT_285_300_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20, WT_300_315_Mean_all, color='#343434', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(WT300_315_xcoords, WT_300_315_values, color='#838383', zorder='3', alpha='0.8', edgecolors='none', s=50)
ax.scatter(21,WT_315_330_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT315_330_xcoords,WT_315_330_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,WT_330_345_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT330_345_xcoords,WT_330_345_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,WT_345_360_Mean_all, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT345_360_xcoords,WT_345_360_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)



ax.scatter(0,FLX_0_15_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX0_15_xcoords,FLX_0_15_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,FLX_15_30_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX15_30_xcoords,FLX_15_30_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,FLX_30_45_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX30_45_xcoords,FLX_30_45_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,FLX_45_60_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX45_60_xcoords,FLX_45_60_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,FLX_60_75_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX60_75_xcoords,FLX_60_75_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,FLX_75_90_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX75_90_xcoords,FLX_75_90_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,FLX_90_105_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,FLX_105_120_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX105_120_xcoords,FLX_105_120_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,FLX_120_135_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX120_135_xcoords,FLX_120_135_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,FLX_135_150_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX135_150_xcoords,FLX_135_150_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,FLX_150_165_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX150_165_xcoords,FLX_150_165_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,FLX_165_180_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX165_180_xcoords,FLX_165_180_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,FLX_180_195_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX180_195_xcoords,FLX_180_195_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,FLX_195_210_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX195_210_xcoords,FLX_195_210_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,FLX_90_105_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,FLX_225_240_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX225_240_xcoords,FLX_225_240_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,FLX_240_255_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX240_255_xcoords,FLX_240_255_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,FLX_255_270_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX255_270_xcoords,FLX_255_270_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,FLX_270_285_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX270_285_xcoords,FLX_270_285_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,FLX_285_300_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX285_300_xcoords,FLX_285_300_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20,FLX_300_315_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX300_315_xcoords,FLX_300_315_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(21,FLX_315_330_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX315_330_xcoords,FLX_315_330_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,FLX_330_345_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX330_345_xcoords,FLX_330_345_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,FLX_345_360_Mean_all, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX345_360_xcoords,FLX_345_360_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(xvalue, wt_yvalue_all,wt_yerr_all,fmt='none',ecolor= '#343434',elinewidth='2',capsize=5,capthick='2')
ax.errorbar(xvalue, FLX_yvalue_all,FLX_yerr_all,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')


###Plot a genotype X polarity status graph with 4 total groups (WT p, WT np, FLX p, FLX np)
ax=axs[0,1]
# ax.set_ylim(0,1)
# ax.set_ylim(0,0.0006)
group_n = 24
xvalue = np.arange(group_n)


ax.scatter(0,WT_0_15_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT0_15_xcoords,WT_0_15_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,WT_15_30_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT15_30_xcoords,WT_15_30_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,WT_30_45_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT30_45_xcoords,WT_30_45_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,WT_45_60_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT45_60_xcoords,WT_45_60_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,WT_60_75_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT60_75_xcoords,WT_60_75_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,WT_75_90_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT75_90_xcoords,WT_75_90_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,WT_90_105_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT90_105_xcoords,WT_90_105_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,WT_105_120_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT105_120_xcoords,WT_105_120_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,WT_120_135_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT120_135_xcoords,WT_120_135_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,WT_135_150_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT135_150_xcoords,WT_135_150_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,WT_150_165_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT150_165_xcoords,WT_150_165_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,WT_165_180_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT165_180_xcoords,WT_165_180_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,WT_180_195_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT180_195_xcoords,WT_180_195_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,WT_195_210_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT195_210_xcoords,WT_195_210_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,WT_210_225_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT210_225_xcoords,WT_210_225_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,WT_225_240_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT225_240_xcoords,WT_225_240_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,WT_240_255_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT240_255_xcoords,WT_240_255_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,WT_255_270_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT255_270_xcoords,WT_255_270_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,WT_270_285_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT270_285_xcoords,WT_270_285_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,WT_285_300_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT285_300_xcoords,WT_285_300_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20, WT_300_315_Mean_nonpolar, color='#b4b4b4', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(WT300_315_xcoords, WT_300_315_values, color='#838383', zorder='3', alpha='0.8', edgecolors='none', s=50)
ax.scatter(21,WT_315_330_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT315_330_xcoords,WT_315_330_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,WT_330_345_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT330_345_xcoords,WT_330_345_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,WT_345_360_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT345_360_xcoords,WT_345_360_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)



ax.scatter(0,FLX_0_15_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX0_15_xcoords,FLX_0_15_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,FLX_15_30_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX15_30_xcoords,FLX_15_30_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,FLX_30_45_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX30_45_xcoords,FLX_30_45_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,FLX_45_60_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX45_60_xcoords,FLX_45_60_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,FLX_60_75_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX60_75_xcoords,FLX_60_75_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,FLX_75_90_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX75_90_xcoords,FLX_75_90_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,FLX_90_105_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,FLX_105_120_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX105_120_xcoords,FLX_105_120_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,FLX_120_135_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX120_135_xcoords,FLX_120_135_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,FLX_135_150_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX135_150_xcoords,FLX_135_150_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,FLX_150_165_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX150_165_xcoords,FLX_150_165_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,FLX_165_180_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX165_180_xcoords,FLX_165_180_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,FLX_180_195_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX180_195_xcoords,FLX_180_195_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,FLX_195_210_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX195_210_xcoords,FLX_195_210_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,FLX_90_105_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,FLX_225_240_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX225_240_xcoords,FLX_225_240_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,FLX_240_255_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX240_255_xcoords,FLX_240_255_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,FLX_255_270_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX255_270_xcoords,FLX_255_270_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,FLX_270_285_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX270_285_xcoords,FLX_270_285_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,FLX_285_300_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX285_300_xcoords,FLX_285_300_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20,FLX_300_315_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX300_315_xcoords,FLX_300_315_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(21,FLX_315_330_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX315_330_xcoords,FLX_315_330_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,FLX_330_345_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX330_345_xcoords,FLX_330_345_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,FLX_345_360_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX345_360_xcoords,FLX_345_360_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(xvalue, wt_yvalue_nonpolar,wt_yerr_nonpolar,fmt='none',ecolor= '#b4b4b4',elinewidth='2',capsize=5,capthick='2')
ax.errorbar(xvalue, FLX_yvalue_nonpolar,FLX_yerr_nonpolar,fmt='none',ecolor= '#fcd9cd',elinewidth='2',capsize=5,capthick='2')


ax.scatter(0,WT_0_15_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT0_15_xcoords,WT_0_15_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,WT_15_30_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT15_30_xcoords,WT_15_30_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,WT_30_45_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT30_45_xcoords,WT_30_45_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,WT_45_60_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT45_60_xcoords,WT_45_60_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,WT_60_75_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT60_75_xcoords,WT_60_75_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,WT_75_90_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT75_90_xcoords,WT_75_90_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,WT_90_105_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT90_105_xcoords,WT_90_105_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,WT_105_120_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT105_120_xcoords,WT_105_120_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,WT_120_135_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT120_135_xcoords,WT_120_135_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,WT_135_150_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT135_150_xcoords,WT_135_150_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,WT_150_165_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT150_165_xcoords,WT_150_165_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,WT_165_180_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT165_180_xcoords,WT_165_180_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,WT_180_195_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT180_195_xcoords,WT_180_195_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,WT_195_210_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT195_210_xcoords,WT_195_210_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,WT_210_225_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT210_225_xcoords,WT_210_225_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,WT_225_240_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT225_240_xcoords,WT_225_240_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,WT_240_255_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT240_255_xcoords,WT_240_255_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,WT_255_270_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT255_270_xcoords,WT_255_270_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,WT_270_285_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT270_285_xcoords,WT_270_285_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,WT_285_300_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT285_300_xcoords,WT_285_300_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20, WT_300_315_Mean_polar, color='#343434', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(WT300_315_xcoords, WT_300_315_values, color='#838383', zorder='3', alpha='0.8', edgecolors='none', s=50)
ax.scatter(21,WT_315_330_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT315_330_xcoords,WT_315_330_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,WT_330_345_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT330_345_xcoords,WT_330_345_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,WT_345_360_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT345_360_xcoords,WT_345_360_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)



ax.scatter(0,FLX_0_15_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX0_15_xcoords,FLX_0_15_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,FLX_15_30_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX15_30_xcoords,FLX_15_30_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,FLX_30_45_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX30_45_xcoords,FLX_30_45_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,FLX_45_60_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX45_60_xcoords,FLX_45_60_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,FLX_60_75_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX60_75_xcoords,FLX_60_75_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,FLX_75_90_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX75_90_xcoords,FLX_75_90_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,FLX_90_105_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,FLX_105_120_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX105_120_xcoords,FLX_105_120_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,FLX_120_135_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX120_135_xcoords,FLX_120_135_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,FLX_135_150_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX135_150_xcoords,FLX_135_150_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,FLX_150_165_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX150_165_xcoords,FLX_150_165_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,FLX_165_180_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX165_180_xcoords,FLX_165_180_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,FLX_180_195_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX180_195_xcoords,FLX_180_195_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,FLX_195_210_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX195_210_xcoords,FLX_195_210_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,FLX_210_225_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,FLX_225_240_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX225_240_xcoords,FLX_225_240_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,FLX_240_255_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX240_255_xcoords,FLX_240_255_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,FLX_255_270_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX255_270_xcoords,FLX_255_270_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,FLX_270_285_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX270_285_xcoords,FLX_270_285_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,FLX_285_300_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX285_300_xcoords,FLX_285_300_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20,FLX_300_315_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX300_315_xcoords,FLX_300_315_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(21,FLX_315_330_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX315_330_xcoords,FLX_315_330_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,FLX_330_345_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX330_345_xcoords,FLX_330_345_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,FLX_345_360_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX345_360_xcoords,FLX_345_360_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(xvalue, wt_yvalue_polar,wt_yerr_polar,fmt='none',ecolor= '#343434',elinewidth='2',capsize=5,capthick='2')
ax.errorbar(xvalue, FLX_yvalue_polar,FLX_yerr_polar,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')



###Plot a WT polar vs nonpolar graph. 2 total groups - WT p and WT np
ax=axs[1,0]
# ax.set_ylim(0,1)
# ax.set_ylim(0,0.0006)
group_n = 24
xvalue = np.arange(group_n)

WT_line_xvalue = (0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23)
ax.plot((WT_line_xvalue),(wt_yvalue_nonpolar),color = '#b4b4b4')
ax.plot((WT_line_xvalue),(wt_yvalue_polar),color = '#343434')

ax.scatter(0,WT_0_15_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT0_15_xcoords,WT_0_15_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,WT_15_30_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT15_30_xcoords,WT_15_30_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,WT_30_45_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT30_45_xcoords,WT_30_45_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,WT_45_60_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT45_60_xcoords,WT_45_60_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,WT_60_75_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT60_75_xcoords,WT_60_75_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,WT_75_90_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT75_90_xcoords,WT_75_90_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,WT_90_105_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT90_105_xcoords,WT_90_105_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,WT_105_120_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT105_120_xcoords,WT_105_120_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,WT_120_135_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT120_135_xcoords,WT_120_135_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,WT_135_150_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT135_150_xcoords,WT_135_150_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,WT_150_165_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT150_165_xcoords,WT_150_165_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,WT_165_180_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT165_180_xcoords,WT_165_180_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,WT_180_195_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT180_195_xcoords,WT_180_195_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,WT_195_210_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT195_210_xcoords,WT_195_210_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,WT_210_225_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT210_225_xcoords,WT_210_225_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,WT_225_240_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT225_240_xcoords,WT_225_240_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,WT_240_255_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT240_255_xcoords,WT_240_255_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,WT_255_270_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT255_270_xcoords,WT_255_270_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,WT_270_285_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT270_285_xcoords,WT_270_285_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,WT_285_300_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT285_300_xcoords,WT_285_300_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20, WT_300_315_Mean_nonpolar, color='#b4b4b4', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(WT300_315_xcoords, WT_300_315_values, color='#838383', zorder='3', alpha='0.8', edgecolors='none', s=50)
ax.scatter(21,WT_315_330_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT315_330_xcoords,WT_315_330_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,WT_330_345_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT330_345_xcoords,WT_330_345_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,WT_345_360_Mean_nonpolar, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT345_360_xcoords,WT_345_360_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(xvalue, wt_yvalue_nonpolar,wt_yerr_nonpolar,fmt='none',ecolor= '#b4b4b4',elinewidth='2',capsize=5,capthick='2')


ax.scatter(0,WT_0_15_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT0_15_xcoords,WT_0_15_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1,WT_15_30_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT15_30_xcoords,WT_15_30_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2,WT_30_45_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT30_45_xcoords,WT_30_45_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3,WT_45_60_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT45_60_xcoords,WT_45_60_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4,WT_60_75_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT60_75_xcoords,WT_60_75_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5,WT_75_90_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT75_90_xcoords,WT_75_90_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6,WT_90_105_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT90_105_xcoords,WT_90_105_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7,WT_105_120_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT105_120_xcoords,WT_105_120_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8,WT_120_135_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT120_135_xcoords,WT_120_135_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9,WT_135_150_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT135_150_xcoords,WT_135_150_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10,WT_150_165_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT150_165_xcoords,WT_150_165_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11,WT_165_180_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT165_180_xcoords,WT_165_180_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12,WT_180_195_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT180_195_xcoords,WT_180_195_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13,WT_195_210_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT195_210_xcoords,WT_195_210_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14,WT_210_225_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT210_225_xcoords,WT_210_225_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15,WT_225_240_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT225_240_xcoords,WT_225_240_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16,WT_240_255_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT240_255_xcoords,WT_240_255_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17,WT_255_270_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT255_270_xcoords,WT_255_270_values, color = '#838383',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18,WT_270_285_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT270_285_xcoords,WT_270_285_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19,WT_285_300_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT285_300_xcoords,WT_285_300_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20, WT_300_315_Mean_polar, color='#343434', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(WT300_315_xcoords, WT_300_315_values, color='#838383', zorder='3', alpha='0.8', edgecolors='none', s=50)
ax.scatter(21,WT_315_330_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT315_330_xcoords,WT_315_330_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22,WT_330_345_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT330_345_xcoords,WT_330_345_values, color = '#5b5b5b',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23,WT_345_360_Mean_polar, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(WT345_360_xcoords,WT_345_360_values, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(xvalue, wt_yvalue_polar,wt_yerr_polar,fmt='none',ecolor= '#343434',elinewidth='2',capsize=5,capthick='2')



###Plot a FLX polar vs nonpolar graph. 2 total groups - WT p and WT np
ax=axs[1,1]
# ax.set_ylim(0,1)
# ax.set_ylim(0,0.0006)
group_n = 24
xvalue = np.arange(group_n)

FLX_line_xvalue = (0.4,1.4,2.4,3.4,4.4,5.4,6.4,7.4,8.4,9.4,10.4,11.4,12.4,13.4,14.4,15.4,16.4,17.4,18.4,19.4,20.4,21.4,22.4,23.4)
ax.plot((FLX_line_xvalue),(FLX_yvalue_nonpolar),color = '#fcd9cd')
ax.plot((FLX_line_xvalue),(FLX_yvalue_polar),color = '#df3325')

ax.scatter(0.4,FLX_0_15_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX0_15_xcoords,FLX_0_15_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1.4,FLX_15_30_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX15_30_xcoords,FLX_15_30_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2.4,FLX_30_45_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX30_45_xcoords,FLX_30_45_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3.4,FLX_45_60_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX45_60_xcoords,FLX_45_60_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4.4,FLX_60_75_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX60_75_xcoords,FLX_60_75_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5.4,FLX_75_90_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX75_90_xcoords,FLX_75_90_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6.4,FLX_90_105_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7.4,FLX_105_120_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX105_120_xcoords,FLX_105_120_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8.4,FLX_120_135_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX120_135_xcoords,FLX_120_135_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9.4,FLX_135_150_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX135_150_xcoords,FLX_135_150_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10.4,FLX_150_165_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX150_165_xcoords,FLX_150_165_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11.4,FLX_165_180_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX165_180_xcoords,FLX_165_180_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12.4,FLX_180_195_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX180_195_xcoords,FLX_180_195_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13.4,FLX_195_210_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX195_210_xcoords,FLX_195_210_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14.4,FLX_210_225_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15.4,FLX_225_240_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX225_240_xcoords,FLX_225_240_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16.4,FLX_240_255_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX240_255_xcoords,FLX_240_255_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17.4,FLX_255_270_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX255_270_xcoords,FLX_255_270_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18.4,FLX_270_285_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX270_285_xcoords,FLX_270_285_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19.4,FLX_285_300_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX285_300_xcoords,FLX_285_300_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20.4,FLX_300_315_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX300_315_xcoords,FLX_300_315_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(21.4,FLX_315_330_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX315_330_xcoords,FLX_315_330_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22.4,FLX_330_345_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX330_345_xcoords,FLX_330_345_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23.4,FLX_345_360_Mean_nonpolar, color = '#fcd9cd',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX345_360_xcoords,FLX_345_360_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(xvalue+0.4, FLX_yvalue_nonpolar,FLX_yerr_nonpolar,fmt='none',ecolor= '#fcd9cd',elinewidth='2',capsize=5,capthick='2')



ax.scatter(0.4,FLX_0_15_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX0_15_xcoords,FLX_0_15_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(1.4,FLX_15_30_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX15_30_xcoords,FLX_15_30_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(2.4,FLX_30_45_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX30_45_xcoords,FLX_30_45_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(3.4,FLX_45_60_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX45_60_xcoords,FLX_45_60_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(4.4,FLX_60_75_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX60_75_xcoords,FLX_60_75_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(5.4,FLX_75_90_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX75_90_xcoords,FLX_75_90_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(6.4,FLX_90_105_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(7.4,FLX_105_120_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX105_120_xcoords,FLX_105_120_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(8.4,FLX_120_135_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX120_135_xcoords,FLX_120_135_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(9.4,FLX_135_150_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX135_150_xcoords,FLX_135_150_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(10.4,FLX_150_165_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX150_165_xcoords,FLX_150_165_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(11.4,FLX_165_180_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX165_180_xcoords,FLX_165_180_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(12.4,FLX_180_195_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX180_195_xcoords,FLX_180_195_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(13.4,FLX_195_210_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX195_210_xcoords,FLX_195_210_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(14.4,FLX_210_225_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX90_105_xcoords,FLX_90_105_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(15.4,FLX_225_240_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX225_240_xcoords,FLX_225_240_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(16.4,FLX_240_255_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX240_255_xcoords,FLX_240_255_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(17.4,FLX_255_270_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX255_270_xcoords,FLX_255_270_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(18.4,FLX_270_285_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX270_285_xcoords,FLX_270_285_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(19.4,FLX_285_300_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX285_300_xcoords,FLX_285_300_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(20.4,FLX_300_315_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX300_315_xcoords,FLX_300_315_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(21.4,FLX_315_330_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX315_330_xcoords,FLX_315_330_values, color = '#f26b47',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(22.4,FLX_330_345_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX330_345_xcoords,FLX_330_345_values, color = '#f8a793',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(23.4,FLX_345_360_Mean_polar, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(FLX345_360_xcoords,FLX_345_360_values, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(xvalue+0.4, FLX_yvalue_polar,FLX_yerr_polar,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')

plot.show()