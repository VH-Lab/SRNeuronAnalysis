from RFTDT_AnnotationReaderXML import *
import matplotlib.pyplot as plot
import numpy as np
import math as math
import mpl_toolkits.mplot3d
import matplotlib as mpl

# file_location = raw_input("Input data path.")
# os.chdir(file_location)
# annotation_files = annotation_finder(file_location)

def get_rotation_matrix(i_v, unit=None):
    # From http://www.j3d.org/matrix_faq/matrfaq_latest.html#Q38
    if unit is None:
        unit = [0.0, 1.0, 0.0]
    # Normalize vector length
    i_v = i_v/ np.linalg.norm(i_v)

    # Get axis
    uvw = np.cross(i_v, unit)

    # compute trig values - no need to go through arccos and back
    rcos = np.dot(i_v, unit)
    rsin = np.linalg.norm(uvw)

    #normalize and unpack axis
    if not np.isclose(rsin, 0):
        uvw /= rsin
    u, v, w = uvw

    # Compute rotation matrix - re-expressed to show structure
    return (
        rcos * np.eye(3) +
        rsin * np.array([
            [ 0, -w,  v],
            [ w,  0, -u],
            [-v,  u,  0]
        ]) +
        (1.0 - rcos) * uvw[:,None] * uvw[None,:]
    )


def polarity_index(source_target_dict, nodes, edges):

# for annotation_file in annotation_files:

    trans_node_locs = []

    #Start by finding the paths and getting the coordinates for each node in the paths
    #This will allow you to plot without having lines between the last node of each tree and the first
    #node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
    # nodes, edges = annotation_parser(annotation_file)

    # nodes, edges = annotation_parser(annotation_file)
    #
    # node_locations = node_location_finder(nodes, edges)
    #
    # source_target_dict = source_target(edges)

    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print len(tip_list)
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    node_locations = node_location_finder(nodes, edges)
    soma_location = [item for item in node_locations if item[0] == soma_node]

    #Start by finding the lateral indicator node, the apical indicator node and the soma node
    #also get the nodes only in the tree (i.e not the apical and lateral nodes)
    #including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
    node_id_list = [node.attrib['id'] for node in nodes]
    radii_list = [node.attrib['radius'] for node in nodes]
    lateral_node = node_id_list[radii_list.index('5.5')]
    lateral_node_list = [lateral_node]
    apical_node = node_id_list[radii_list.index('5')]
    radii_list.remove('5')
    radii_list.remove('5.5')
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    radii_list.remove(max(radii_list))
    tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
    tree_node_locations = [item for item in node_locations if item[0] in tree_node_id]
    int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]

    #get branching nodes and tips
    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    branch_node_tips = branch_node_list + tip_list
    branch_node_tips.remove(lateral_node_list[0])
    int_branch_node_tips = [int(node) for node in branch_node_tips]

    #special node locations (soma, apical, lateral)
    apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
    apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
    apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
    apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
    lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
    lateral_x = np.int16([node.attrib['x'] for node in apical_attribs])
    lateral_y = np.int16([node.attrib['y'] for node in apical_attribs])
    soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
    soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
    soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
    #Translate apical node the distances required for soma to be a 0,0,0
    trans_apical_x = (apical_x - soma_x)
    trans_apical_y = (apical_y - soma_y)
    trans_apical_z = (apical_z - soma_z)

    #define original vector as that of the sapical dendrite
    apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])

    # Compute the rotation matrix
    R = get_rotation_matrix(apicalv)

    # Apply the rotation matrix to the apical vector
    newv = np.dot(apicalv.T, R.T)

    # Get the 3D figure
    # fig = plot.figure()
    # ax = fig.gca(projection='3d')


    matches = [item for item in node_locations if item[0] in branch_node_tips]

    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

        #Apply the rotation matrix to tip-soma vector
    for node in int_tree_node_locations:
        branchv = np.array([node[1]-soma_x, node[2]-soma_y, node[3]-soma_z])
        # print branchv

        new_node = np.dot(branchv.T,R.T)
        # print new_node
        # ax.plot(*np.transpose([[0, 0, 0], trans_node]), color="b")

        # find tips that are on each side of the soma
        trans_node_locs.append([node[0], new_node[0], new_node[1], new_node[2]])

    # print trans_node_locs

    segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in
                    branch_node_tips]
    segment_list = [segment for segment in segment_list if segment is not None]
    segment_list = [segment for segment in segment_list if len(segment) > 1]
    # print segment_list


    # Plot the original and rotated vector
    # ax.plot(*np.transpose([[0, 0, 0], apicalv]), label="original vector", color="m")
    # ax.plot(*np.transpose([[0, 0, 0], newv]), label="rotated vector", color="k")


    # Plot some axes for reference
    # ax.plot([0, 1], [0, 0], [0, 0], color='k')
    # ax.plot([0, 0], [0, 1], [0, 0], color='k')
    # ax.plot([0, 0], [0, 0], [0, 1], color='k')


    negative_branch_nodes = [node[0] for node in  trans_node_locs if node[1] < 0 and node[0] in int_branch_node_tips]
    positive_branch_nodes = [node[0] for node in  trans_node_locs if node[1] > 0 and node[0] in int_branch_node_tips]

    segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in branch_node_tips]
    segment_list = [segment for segment in segment_list if segment is not None]
    segment_list = [segment for segment in segment_list if len(segment) > 1]

    unique_segment_list1 = []
    for segment in segment_list:
        # print segment
        branch_node_tip_found = 0
        for node in branch_node_tips:
            if node in segment[1:-1]:
                branch_node_tip_found = 1
        if branch_node_tip_found == 0:
            unique_segment_list1.append(segment)

            #
            # print unique_segment_list1
    unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
    unique_segment_list = [list(item) for item in unique_segment_list]
    # print len(unique_segment_list)

    real_segments = []
    for match in unique_segment_list:
        segment_found = 0
        for segment in unique_segment_list1:
            if segment_found == 0:
                segment_set = set(segment)
                match_set = set(match)
                if segment_set == match_set:
                    real_segments.append(segment)
                    segment_found = 1
    unique_segment_list = real_segments

    int_segment_list = [[int(coordinate) for coordinate in segment] for segment in unique_segment_list]


    #Reverse lines so that '1' is never the first node in order to make sorting much easier
    ordered_int_segments = []
    for segment in int_segment_list:
        if segment[0] == 1:
            ordered_int_segments.append(segment[::-1])
        else:
            ordered_int_segments.append(segment)

    #divide up segments by whether their branch node is ont the positive or negative side.
    #NOTE: this code considers a branch to be in whichever side it starts in.
    negative_segments = [segment for segment in ordered_int_segments if segment[0] in negative_branch_nodes]
    negative_segments_list = [[str(node) for node in segment] for segment in negative_segments]
    positive_segments = [segment for segment in ordered_int_segments if segment[0] in positive_branch_nodes]
    positive_segments_list = [[str(node) for node in segment] for segment in positive_segments]

    #caluclate the branch number index value
    negative_branch_number = len( negative_branch_nodes)
    positive_branch_number =  len(positive_branch_nodes)
    branch_number = (negative_branch_number + positive_branch_number)
    branch_polarity_index = abs(negative_branch_number - positive_branch_number)/float(branch_number)
    print branch_polarity_index

    #calculate the segment length for both positive and negative branches
    node_location = node_location_finder(nodes, edges)
    negative_segment_lengths = []
    for segment in range(0, len(negative_segments_list)):
        matches = [item for item in node_location if item[0] in negative_segments_list[segment]]
        # print matches
        if matches == []:
            negative_segment_lengths.append(0)
        else:
            matches_nodes = [match[0] for match in matches]
            matches_index = [negative_segments_list[segment].index(node) for node in matches_nodes]
            sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
            int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
            # print sorted_matches


            interpoint_distance = 0
            for match in range(0, len(int_matches) - 1):
                interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
                                                                               int_matches[match + 1][1:4])
            # print int_matches[match][1:4]
            negative_segment_lengths.append(interpoint_distance)

    negative_segment_lengths = set(negative_segment_lengths)
    negseg_total_length = sum(negative_segment_lengths)
    # print negseg_total_length

    positive_segment_lengths = []
    for segment in range(0, len(positive_segments_list)):
        matches = [item for item in node_location if item[0] in positive_segments_list[segment]]
        # print matches
        if matches == []:
            positive_segment_lengths.append(0)
        else:
            matches_nodes = [match[0] for match in matches]
            matches_index = [positive_segments_list[segment].index(node) for node in matches_nodes]
            sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
            int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
            # print sorted_matches


            interpoint_distance = 0
            for match in range(0, len(int_matches) - 1):
                interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
                                                                               int_matches[match + 1][1:4])
            # print int_matches[match][1:4]
            positive_segment_lengths.append(interpoint_distance)

    positive_segment_lengths = set(positive_segment_lengths)
    posseg_total_length = sum(positive_segment_lengths)
    # print posseg_total_length

    #caluclate segment length-based polarity index value
    seglen_polarity_index = (abs(negseg_total_length-posseg_total_length))/(negseg_total_length+posseg_total_length)
    print seglen_polarity_index

    #Apply the rotation matrix to tip-soma vector for each path
    #Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
    #This is so that the rotation can be applied and simple +/- integer used to determine lateral position
    trans_tips = []

    matches = [item for item in node_location if item[0] in tip_list]
    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

    for match in int_matches:
        tipv = np.array([match[1]-soma_x, match[2]-soma_y, match[3]- soma_z])
        newtip = np.dot(tipv.T,R.T)

        trans_tips.append(newtip[0])

    # find tips that are on each side of the soma
    negative_tips = [tip for tip in trans_tips if tip < 0 ]
    positive_tips = [tip for tip in trans_tips if tip > 0 ]

    # count number of tips on right and left of soma and count total number of tips
    neg_tip_num = len(negative_tips)
    pos_tip_num =  len(positive_tips)
    tip_num = neg_tip_num + pos_tip_num

    #calucalate the tip indiex by finding difference between tip number on each side div by total
    tip_polarity_index = abs(neg_tip_num - pos_tip_num)/float(tip_num)
    print tip_polarity_index

    return branch_polarity_index, seglen_polarity_index, tip_polarity_index


def polarity_absolute(source_target_dict, nodes, edges):

# for annotation_file in annotation_files:

    trans_node_locs = []

    #Start by finding the paths and getting the coordinates for each node in the paths
    #This will allow you to plot without having lines between the last node of each tree and the first
    #node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
    # nodes, edges = annotation_parser(annotation_file)

    node_locations = node_location_finder(nodes, edges)

    source_target_dict = source_target(edges)

    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print len(tip_list)
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    node_location = node_location_finder(nodes, edges)
    soma_location = [item for item in node_locations if item[0] == soma_node]

    #Start by finding the lateral indicator node, the apical indicator node and the soma node
    #also get the nodes only in the tree (i.e not the apical and lateral nodes)
    #including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
    node_id_list = [node.attrib['id'] for node in nodes]
    radii_list = [node.attrib['radius'] for node in nodes]
    lateral_node = node_id_list[radii_list.index('5.5')]
    lateral_node_list = [lateral_node]
    apical_node = node_id_list[radii_list.index('5')]
    radii_list.remove('5')
    radii_list.remove('5.5')
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    radii_list.remove(max(radii_list))
    tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
    tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
    int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]

    #get branching nodes and tips
    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    branch_node_tips = branch_node_list + tip_list
    branch_node_tips.remove(lateral_node_list[0])
    int_branch_node_tips = [int(node) for node in branch_node_tips]
    print int_branch_node_tips

    #special node locations (soma, apical, lateral)
    apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
    apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
    apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
    apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
    lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
    lateral_x = [int(node.attrib['x']) for node in lateral_attribs][0]
    lateral_y = [int(node.attrib['y']) for node in lateral_attribs][0]
    lateral_z = [int(node.attrib['z']) for node in lateral_attribs][0]
    soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
    soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
    soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
    #Translate apical node the distances required for soma to be a 0,0,0
    trans_apical_x = (apical_x - soma_x)
    trans_apical_y = (apical_y - soma_y)
    trans_apical_z = (apical_z - soma_z)
    #Translate lateral node the distances required for soma to be 0,0,0
    trans_lateral_x = (lateral_x - soma_x)
    trans_lateral_y = (lateral_y - soma_y)
    trans_lateral_z = (lateral_z - soma_z)



    #define original vector as that of the sapical dendrite
    apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])

    # Compute the rotation matrix
    R = get_rotation_matrix(apicalv)

    # Apply the rotation matrix to the apical vector
    newv = np.dot(apicalv.T, R.T)

    #make and rotate the lateral node vector
    latv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
    new_latv = np.dot(latv.T,R.T)
    # print new_latv

    matches = [item for item in node_location if item[0] in branch_node_tips]

    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

        #Apply the rotation matrix to tip-soma vector

    for node in int_tree_node_locations:
        branchv = np.array([node[1]-soma_x, node[2]-soma_y, node[3]-soma_z])
        # print branchv

        new_node = np.dot(branchv.T,R.T)

        # adds all the translated nodes to a list
        if new_latv[0] > 0:
            trans_node_locs.append([node[0], new_node[0], -(new_node[1]), new_node[2]])
        else:
            trans_node_locs.append([node[0], new_node[0], new_node[1], new_node[2]])
    # print trans_node_locs


    #find segments
    segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in
                    branch_node_tips]
    segment_list = [segment for segment in segment_list if segment is not None]
    segment_list = [segment for segment in segment_list if len(segment) > 1]


    medial_branch_nodes = [node[0] for node in  trans_node_locs if node[1] < 0 and node[0] in int_branch_node_tips]
    lateral_branch_nodes = [node[0] for node in  trans_node_locs if node[1] > 0 and node[0] in int_branch_node_tips]

    segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in branch_node_tips]
    segment_list = [segment for segment in segment_list if segment is not None]
    segment_list = [segment for segment in segment_list if len(segment) > 1]

    unique_segment_list1 = []
    for segment in segment_list:
        # print segment
        branch_node_tip_found = 0
        for node in branch_node_tips:
            if node in segment[1:-1]:
                branch_node_tip_found = 1
        if branch_node_tip_found == 0:
            unique_segment_list1.append(segment)

            #
            # print unique_segment_list1
    unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
    unique_segment_list = [list(item) for item in unique_segment_list]
    # print len(unique_segment_list)

    real_segments = []
    for match in unique_segment_list:
        segment_found = 0
        for segment in unique_segment_list1:
            if segment_found == 0:
                segment_set = set(segment)
                match_set = set(match)
                if segment_set == match_set:
                    real_segments.append(segment)
                    segment_found = 1
    unique_segment_list = real_segments

    int_segment_list = [[int(coordinate) for coordinate in segment] for segment in unique_segment_list]


    #Reverse lines so that '1' is never the first node in order to make sorting much easier
    ordered_int_segments = []
    for segment in int_segment_list:
        if segment[0] == 1:
            ordered_int_segments.append(segment[::-1])
        else:
            ordered_int_segments.append(segment)

    #divide up segments by whether their branch node is ont the positive or negative side.
    #NOTE: this code considers a branch to be in whichever side it starts in.
    medial_segments = [segment for segment in ordered_int_segments if segment[0] in medial_branch_nodes]
    medial_segments_list = [[str(node) for node in segment] for segment in medial_segments]
    lateral_segments = [segment for segment in ordered_int_segments if segment[0] in lateral_branch_nodes]
    lateral_segments_list = [[str(node) for node in segment] for segment in lateral_segments]

    #caluclate the branch number index value
    medial_branch_number = len(medial_branch_nodes)
    lateral_branch_number =  len(lateral_branch_nodes)
    branch_number = (medial_branch_number + lateral_branch_number)


    #calculate the segment length for both positive and negative branches
    node_location = node_location_finder(nodes, edges)
    medial_segment_lengths = []
    for segment in range(0, len(medial_segments_list)):
        matches = [item for item in node_location if item[0] in medial_segments_list[segment]]
        # print matches
        if matches == []:
            medial_segment_lengths.append(0)
        else:
            matches_nodes = [match[0] for match in matches]
            matches_index = [medial_segments_list[segment].index(node) for node in matches_nodes]
            sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
            int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
            # print sorted_matches


            interpoint_distance = 0
            for match in range(0, len(int_matches) - 1):
                interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
                                                                               int_matches[match + 1][1:4])
            # print int_matches[match][1:4]
            medial_segment_lengths.append(interpoint_distance)

    medial_segment_lengths = set(medial_segment_lengths)
    medseg_total_length = sum(medial_segment_lengths)
    print medseg_total_length

    lateral_segment_lengths = []
    for segment in range(0, len(lateral_segments_list)):
        matches = [item for item in node_location if item[0] in lateral_segments_list[segment]]
        # print matches
        if matches == []:
            lateral_segment_lengths.append(0)
        else:
            matches_nodes = [match[0] for match in matches]
            matches_index = [lateral_segments_list[segment].index(node) for node in matches_nodes]
            sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
            int_matches = [[int(coordinate) for coordinate in match] for match in sorted_matches]
            # print sorted_matches


            interpoint_distance = 0
            for match in range(0, len(int_matches) - 1):
                interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
                                                                               int_matches[match + 1][1:4])
            # print int_matches[match][1:4]
            lateral_segment_lengths.append(interpoint_distance)

    lateral_segment_lengths = set(lateral_segment_lengths)
    latseg_total_length = sum(lateral_segment_lengths)
    print latseg_total_length
    print type(latseg_total_length)




    #TIP BASED MEASURE
    #Apply the rotation matrix to tip-soma vector for each path
    #Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
    #This is so that the rotation can be applied and simple +/- integer used to determine lateral position
    trans_tips = []

    matches = [item for item in node_location if item[0] in tip_list]
    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

    for match in int_matches:
        tipv = np.array([match[1]-soma_x, match[2]-soma_y, match[3]- soma_z])
        newtip = np.dot(tipv.T,R.T)

        if new_latv[0] > 0:
            trans_tips.append(-newtip[1])
        else:
            trans_tips.append(newtip[0])


    # find tips that are on each side of the soma
    medial_tips = [tip for tip in trans_tips if tip < 0 ]
    lateral_tips = [tip for tip in trans_tips if tip > 0 ]

    # count number of tips on right and left of soma and count total number of tips
    med_tip_num = len(medial_tips)
    print med_tip_num
    lat_tip_num =  len(lateral_tips)
    print lat_tip_num
    print type(lat_tip_num)

    return medial_branch_number, lateral_branch_number, medseg_total_length, latseg_total_length, med_tip_num, lat_tip_num

def directionality(source_target_dict, nodes, edges):
    trans_node_locs = []

    # Start by finding the paths and getting the coordinates for each node in the paths
    # This will allow you to plot without having lines between the last node of each tree and the first
    # node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
    # nodes, edges = annotation_parser(annotation_file)

    node_locations = node_location_finder(nodes, edges)

    source_target_dict = source_target(edges)

    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    node_location = node_location_finder(nodes, edges)
    soma_location = [item for item in node_locations if item[0] == soma_node]

    # Start by finding the lateral indicator node, the apical indicator node and the soma node
    # also get the nodes only in the tree (i.e not the apical and lateral nodes)
    # including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
    node_id_list = [node.attrib['id'] for node in nodes]
    radii_list = [node.attrib['radius'] for node in nodes]
    lateral_node = node_id_list[radii_list.index('5.5')]
    lateral_node_list = [lateral_node]
    apical_node = node_id_list[radii_list.index('5')]
    radii_list.remove('5')
    radii_list.remove('5.5')
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    radii_list.remove(max(radii_list))
    tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
    tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
    int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]

    # get branching nodes and tips
    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    branch_node_tips = branch_node_list + tip_list
    branch_node_tips.remove(lateral_node_list[0])
    int_branch_node_tips = [int(node) for node in branch_node_tips]

    # special node locations (soma, apical, lateral)
    apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
    apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
    apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
    apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
    lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
    lateral_x = np.int16([node.attrib['x'] for node in lateral_attribs])
    lateral_y = np.int16([node.attrib['y'] for node in lateral_attribs])
    lateral_z = np.int16([node.attrib['z'] for node in lateral_attribs])
    soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
    soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
    soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
    # Translate apical node the distances required for soma to be a 0,0,0
    trans_apical_x = (apical_x - soma_x)
    trans_apical_y = (apical_y - soma_y)
    trans_apical_z = (apical_z - soma_z)

    # Translate lateral indicator node the distances required for soma to be 0,0,0
    trans_lateral_x = (lateral_x - soma_x)
    trans_lateral_y = (lateral_y - soma_y)
    trans_lateral_z = (lateral_z - soma_z)

    # remove the lateral node so that it isn't counted as a tip/path/vector
    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    tip_list.remove(lateral_node_list[0])

    # define original vector as that of the sapical dendrite
    apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])

    # Compute the rotation matrix
    R = get_rotation_matrix(apicalv)

    # Apply the rotation matrix to the apical vector
    newv = np.dot(apicalv.T, R.T)

    # roate the lateral vector to be in register with rotated cell
    lateralv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
    newlatv = np.dot(lateralv.T, R.T)
    newlatv_a_l = [[coordinate for coordinate in vector] for vector in newlatv]
    newlatv_int = [int(coord) for coord in newlatv_a_l[0]]

    newlatv_coords = []
    # flip lateral vector if it is on the wrong side
    if newlatv_int[0] < 1:
        newlatv_coords.append((newlatv_int[0], newlatv_int[1], newlatv_int[2]))
    else:
        newlatv_coords.append((-newlatv_int[0], newlatv_int[1], newlatv_int[2]))
    # print newlatv_coords
    # Apply the rotation matrix to tip-soma vector for each path
    # Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
    # This is so that the rotation can be applied and simple +/- integer used to determine lateral position
    trans_tips = []

    matches = [item for item in node_location if item[0] in tip_list]
    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

    for match in int_matches:
        tipv = np.array([match[1] - soma_x, match[2] - soma_y, match[3] - soma_z])
        newtip = np.dot(tipv.T, R.T)

        trans_tips.append([match[0], newtip[0], newtip[1], newtip[2]])
        # print trans_tips

    trans_tips_int = [[int(coords) for coords in tip] for tip in trans_tips]
    # print trans_tips_int
    # Flip the cells so that the lateral side is on the left, if necessary
    flipped_tips = []
    for tip in trans_tips_int:
        if newlatv_int[0] < 1:
            flipped_tips.append((tip[0], tip[1], tip[2], tip[3]))
        else:
            flipped_tips.append((tip[0], -tip[1], tip[2], tip[3]))

    # print flipped_tips

    # find tips that are on each side of the soma
    negative_tips = [tip[0] for tip in flipped_tips if tip[1] < 0]
    positive_tips = [tip[0] for tip in flipped_tips if tip[1] > 0]
    # print negative_tips
    # print positive_tips

    # find the distance from the soma (0,0,0) and each tip (radius)
    # Because the soma is always at (0,0,0), we can omit the subtraction present in the standard distance formula

    distance = []
    for tip in flipped_tips:
        distance.append(np.sqrt(tip[1] ** 2 + tip[2] ** 2))
    # print distance

    # make unit vectors for all the vectors
    # start with apical vector
    apical_mag = math.sqrt(newv[0] ** 2 + newv[1] ** 2)
    unit_apicalv = (newv[0] / apical_mag, newv[1] / apical_mag)
    # print unit_apicalv

    unit_tip_vectors = []
    for tip in flipped_tips:
        tip_mag = math.sqrt(tip[1] ** 2 + tip[2] ** 2)
        unit_tip_vectors.append((tip[0], tip[1] / tip_mag, tip[2] / tip_mag))

    # print unit_tip_vectors

    # find the angle between the apical vector and the vector that defines each path (soma to tip only)
    # return both the tip index (used later) and the angle in degrees.
    tip_angle = []
    for vector in unit_tip_vectors:
        # tip_coords = np.array(tip[1:4])
        v1_u = unit_apicalv
        v2_u = vector[1:3]
        tip_angle.append([vector[0], np.degrees(np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0)))])

    # print tip_angle

    # get just the angles of the tips for later calculations
    angles_180 = [angle[1] for angle in tip_angle]

    # print paths_180
    # correct the calculated angle by converting to 360 coordinates. The original calculation gives the smallest
    # angle between apical and tip (all <180), so subtract all "positive" tips to make 360 coordinates
    # "negative" tips are on the lateral side and chosen as a convention. This convention designates angles 0 to 360 from
    # the apical dendrite in a counterclockwise fashion.
    # Either "negative" or "positive" could be altered at users desire
    angles_360 = []
    for tip in tip_angle:
        if tip[0] in positive_tips:
            angles_360.append((360 - tip[1]))

        else:
            angles_360.append(tip[1])
    # print angles_360

    ## Calculate the length of the mean vector of the tips. Based on Batchelet 1981 bood Eq. 1.3.7-1.3.9 see ex. 1.3.2
    ## IMPORTANT: THIS VERSION USES LENGTH 1 FOR ALL PATHS (i.e. this is not weigthed by path lenght)

    # calculate X and y
    cos_angles_360 = [math.cos(math.radians(angle)) for angle in angles_360]
    # print cos_angles_360
    sum_cos = sum(cos_angles_360)
    sin_angles_360 = [math.sin(math.radians(angle)) for angle in angles_360]
    sum_sin = sum(sin_angles_360)
    x_bar = (sum_cos / len(angles_360))
    y_bar = (sum_sin / len(angles_360))

    # Use angle doubling calculate X and Y for orientation. First double angle then subtract 360 if resulting angle >360
    angle_doubling = [angle * 2 for angle in angles_360]

    corrected_angle_doubling = []
    for angle in angle_doubling:
        if angle >= 360:
            corrected_angle_doubling.append(angle - 360)
        else:
            corrected_angle_doubling.append(angle - 0)

    # print angle_doubling
    # print corrected_angle_doubling

    cos_angles_doub = [math.cos(math.radians(angle)) for angle in corrected_angle_doubling]
    sum_cos = sum(cos_angles_doub)
    sin_angles_doub = [math.sin(math.radians(angle)) for angle in corrected_angle_doubling]
    sum_sin = sum(sin_angles_doub)
    x_bar_2 = (sum_cos / len(corrected_angle_doubling))
    y_bar_2 = (sum_sin / len(corrected_angle_doubling))

    # calculate r, the length of the mean vector on unit circle
    r = ((x_bar ** 2) + (y_bar ** 2)) ** 0.5
    print type(r)
    r2 = ((x_bar_2 ** 2) + (y_bar_2 ** 2)) ** 0.5

    # calucalte the angle of the mean vector
    angle_r_raw = (str(np.degrees(np.arctan2(y_bar, x_bar))))
    angle_r2_raw = (str(np.degrees(np.arctan2(y_bar_2, x_bar_2))))
    # print "angle_r_raw"
    # print angle_r_raw
    # print "angle_r2_raw"
    # print angle_r2_raw

    angle_r = []
    angle_r2 = []

    if float(angle_r_raw) < 0:
        angle_r.append(360 + float(angle_r_raw))
    else:
        angle_r.append(0 + float(angle_r_raw))

    if float(angle_r2_raw) < 0:
        angle_r2.append((360 + float(angle_r2_raw)) * 0.5)
    else:
        angle_r2.append((0 + float(angle_r2_raw)) * 0.5)

    # print angle_r
    # print angle_r2
    angle_r = float(angle_r[0])
    angle_r2 = float(angle_r2[0])

    # calculate test statistic
    n = len(angles_360)
    z = (n * (r ** 2))
    z2 = (n * (r2 ** 2))
    # print n
    # print z
    # print z2


    return r, angle_r, z, r2, angle_r2, z2


def xz_directionality(source_target_dict, nodes, edges):


    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print len(tip_list)
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    node_location = node_location_finder(nodes, edges)
    soma_location = [item for item in node_location if item[0] == soma_node]

    #Start by finding the lateral indicator node, the apical indicator node and the soma node
    #also get the nodes only in the tree (i.e not the apical and lateral nodes)
    #including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
    node_id_list = [node.attrib['id'] for node in nodes]
    radii_list = [node.attrib['radius'] for node in nodes]
    lateral_node = node_id_list[radii_list.index('5.5')]
    lateral_node_list = [lateral_node]
    apical_node = node_id_list[radii_list.index('5')]
    radii_list.remove('5')
    radii_list.remove('5.5')
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    radii_list.remove(max(radii_list))
    tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
    tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
    int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]

    #get branching nodes and tips
    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    branch_node_tips = branch_node_list + tip_list
    branch_node_tips.remove(lateral_node_list[0])
    int_branch_node_tips = [int(node) for node in branch_node_tips]

    #special node locations (soma, apical, lateral)
    apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
    apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
    apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
    apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
    lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
    lateral_x = np.int16([node.attrib['x'] for node in lateral_attribs])
    lateral_y = np.int16([node.attrib['y'] for node in lateral_attribs])
    lateral_z = np.int16([node.attrib['z'] for node in lateral_attribs])
    soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
    soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
    soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
    #Translate apical node the distances required for soma to be a 0,0,0
    trans_apical_x = (apical_x - soma_x)
    trans_apical_y = (apical_y - soma_y)
    trans_apical_z = (apical_z - soma_z)

    # Translate lateral indicator node the distances required for soma to be 0,0,0
    trans_lateral_x = (lateral_x - soma_x)
    trans_lateral_y = (lateral_y - soma_y)
    trans_lateral_z = (lateral_z - soma_z)

    # remove the lateral node so that it isn't counted as a tip/path/vector
    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    tip_list.remove(lateral_node_list[0])

    # define original vector as that of the sapical dendrite
    apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])

    # Compute the rotation matrix
    R = get_rotation_matrix(apicalv)

    # Apply the rotation matrix to the apical vector
    newv = np.dot(apicalv.T, R.T)

    # roate the lateral vector to be in register with rotated cell
    lateralv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
    newlatv = np.dot(lateralv.T, R.T)
    newlatv_a_l = [[coordinate for coordinate in vector] for vector in newlatv]
    newlatv_int = [int(coord) for coord in newlatv_a_l[0]]

    newlatv_coords = []
    # flip lateral vector if it is on the wrong side
    if newlatv_int[0] < 1:
        newlatv_coords.append((newlatv_int[0], newlatv_int[1], newlatv_int[2]))
    else:
        newlatv_coords.append((-newlatv_int[0], newlatv_int[1], newlatv_int[2]))
    # print newlatv_coords
    # Apply the rotation matrix to tip-soma vector for each path
    # Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
    # This is so that the rotation can be applied and simple +/- integer used to determine lateral position
    trans_tips = []

    matches = [item for item in node_location if item[0] in tip_list]
    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

    for match in int_matches:
        tipv = np.array([match[1] - soma_x, match[2] - soma_y, match[3] - soma_z])
        newtip = np.dot(tipv.T, R.T)

        trans_tips.append([match[0], newtip[0], newtip[1], newtip[2]])
        # print trans_tips

    trans_tips_int = [[int(coords) for coords in tip] for tip in trans_tips]
    # print trans_tips_int
    # Flip the cells so that the lateral side is on the left, if necessary
    flipped_tips = []
    for tip in trans_tips_int:
        if newlatv_int[0] < 1:
            flipped_tips.append((tip[0], tip[1], tip[2], tip[3]))
        else:
            flipped_tips.append((tip[0], -tip[1], tip[2], tip[3]))

    # print flipped_tips

    # find tips that are on each side of the soma
    negative_tips = [tip[0] for tip in flipped_tips if tip[1] < 0]
    positive_tips = [tip[0] for tip in flipped_tips if tip[1] > 0]
    # print negative_tips
    # print positive_tips

    # find the distance from the soma (0,0,0) and each tip (radius)
    # Because the soma is always at (0,0,0), we can omit the subtraction present in the standard distance formula

    distance = []
    for tip in flipped_tips:
        distance.append(np.sqrt(tip[1] ** 2 + tip[3] ** 2))
    # print distance

    # make unit vectors for all the vectors
    # start with apical vector
    # print newv
    apical_mag = math.sqrt(newv[0] ** 2 + newv[1] ** 2)
    # print apical_mag
    unit_apicalv = (newv[0] / apical_mag, newv[1] / apical_mag)
    # print unit_apicalv

    unit_tip_vectors = []
    for tip in flipped_tips:
        tip_mag = math.sqrt(tip[1] ** 2 + tip[3] ** 2)
        if tip_mag == 0:
            continue
        unit_tip_vectors.append((tip[0], tip[1] / tip_mag, tip[3] / tip_mag))

    # print unit_tip_vectors

    # find the angle between the apical vector and the vector that defines each path (soma to tip only)
    # return both the tip index (used later) and the angle in degrees.
    tip_angle = []
    for vector in unit_tip_vectors:
        # tip_coords = np.array(tip[1:4])
        v1_u = unit_apicalv
        v2_u = vector[1:3]
        tip_angle.append([vector[0], np.degrees(np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0)))])

    # print tip_angle

    # get just the angles of the tips for later calculations
    angles_180 = [angle[1] for angle in tip_angle]
    print max(angles_180)

    # print paths_180
    # correct the calculated angle by converting to 360 coordinates. The original calculation gives the smallest
    # angle between apical and tip (all <180), so add 180 to all "negative" tips to make 360 coordinates
    # "negative" tips were chosen as a convention. Either "negative" or "positive" could be used at users desire
    angles_360 = []
    for tip in tip_angle:
        if tip[0] in positive_tips:
            angles_360.append((360 - tip[1]))

        else:
            angles_360.append(tip[1])
            # print angles_360
            # print angles_360
            # Calculate the length of the mean vector of the tips. Based on Batchelet 1981 bood Eq. 1.3.7-1.3.9 see ex. 1.3.2
            # IMPORTANT: THIS VERSION USES LENGTH 1 FOR ALL PATHS (i.e. this is not weigthed by path length)

    # calculate X and y
    cos_angles_360 = [math.cos(math.radians(angle)) for angle in angles_360]
    # print cos_angles_360
    sum_cos = sum(cos_angles_360)
    sin_angles_360 = [math.sin(math.radians(angle)) for angle in angles_360]
    sum_sin = sum(sin_angles_360)
    x_bar = (sum_cos / len(angles_360))
    y_bar = (sum_sin / len(angles_360))

    # calucate X and Y for orientation. Use angle doubling as suggested by Batchalet et al.
    angle_doubling = [angle * 2 for angle in angles_360]

    corrected_angle_doubling = []
    for angle in angle_doubling:
        if angle >= 360:
            corrected_angle_doubling.append(angle - 360)
        else:
            corrected_angle_doubling.append(angle - 0)

    # print angle_doubling
    # print corrected_angle_doubling
    cos_angles_doub = [math.cos(math.radians(angle)) for angle in corrected_angle_doubling]
    sum_cos = sum(cos_angles_doub)
    sin_angles_doub = [math.sin(math.radians(angle)) for angle in corrected_angle_doubling]
    sum_sin = sum(sin_angles_doub)
    x_bar_2 = (sum_cos / len(corrected_angle_doubling))
    y_bar_2 = (sum_sin / len(corrected_angle_doubling))

    # calculate r, the length of the mean vector on unit circle
    xz_r = ((x_bar ** 2) + (y_bar ** 2)) ** 0.5
    xz_r2 = ((x_bar_2 ** 2) + (y_bar_2 ** 2)) ** 0.5

    # caluclate the angle of the mean angle. This code returns the angle someitmes in negative degrees, so a correction
    # must be applied in those cases
    xz_angle_r_raw = (str(np.degrees(np.arctan2(y_bar, x_bar))))
    xz_angle_r2_raw = (str(np.degrees(np.arctan2(y_bar_2, x_bar_2))))
    # print 'angle_r_raw'
    # print xz_angle_r_raw
    # print 'angle_r2_raw'
    # print xz_angle_r2_raw

    # this is the correction for negative angles.
    xz_angle_r = []
    xz_angle_r2 = []

    if float(xz_angle_r_raw) < 0:
        xz_angle_r.append(360 + float(xz_angle_r_raw))
    else:
        xz_angle_r.append(0 + float(xz_angle_r_raw))

    if float(xz_angle_r2_raw) < 0:
        xz_angle_r2.append((360 + float(xz_angle_r2_raw)) * 0.5)
    else:
        xz_angle_r2.append((0 + float(xz_angle_r2_raw)) * 0.5)

    # print xz_angle_r
    # print xz_angle_r2

    xz_angle_r = float(xz_angle_r[0])
    xz_angle_r2 = float(xz_angle_r2[0])

    # calculate test statistic z for Raleigh test
    n = len(angles_360)
    xz_z = (n * (xz_r ** 2))
    xz_z2 = (n * (xz_r2 ** 2))
    # print n
    # print z
    # print z2

    return xz_r, xz_angle_r, xz_z,xz_r2, xz_angle_r2, xz_z2


def radial_sholl(source_target_dict, nodes, edges):

    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print len(tip_list)
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    node_location = node_location_finder(nodes, edges)
    soma_location = [item for item in node_location if item[0] == soma_node]

    #Start by finding the lateral indicator node, the apical indicator node and the soma node
    #also get the nodes only in the tree (i.e not the apical and lateral nodes)
    #including non-tree nodes will include "dendritic length" that is not dendrite but instead indicator
    node_id_list = [node.attrib['id'] for node in nodes]
    radii_list = [node.attrib['radius'] for node in nodes]
    lateral_node = node_id_list[radii_list.index('5.5')]
    lateral_node_list = [lateral_node]
    apical_node = node_id_list[radii_list.index('5')]
    radii_list.remove('5')
    radii_list.remove('5.5')
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    radii_list.remove(max(radii_list))
    tree_node_id = [node.attrib['id'] for node in nodes if node.attrib['radius'] in radii_list]
    tree_node_locations = [item for item in node_location if item[0] in tree_node_id]
    int_tree_node_locations = [[int(coordinate) for coordinate in node] for node in tree_node_locations]

    #get branching nodes and tips
    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    branch_node_tips = branch_node_list + tip_list
    branch_node_tips.remove(lateral_node_list[0])
    int_branch_node_tips = [int(node) for node in branch_node_tips]

    #special node locations (soma, apical, lateral)
    apical_attribs = [node for node in nodes if node.attrib['id'] == apical_node]
    apical_x = [int(node.attrib['x']) for node in apical_attribs][0]
    apical_y = [int(node.attrib['y']) for node in apical_attribs][0]
    apical_z = [int(node.attrib['z']) for node in apical_attribs][0]
    lateral_attribs = [node for node in nodes if node.attrib['id'] == lateral_node]
    lateral_x = np.int16([node.attrib['x'] for node in lateral_attribs])
    lateral_y = np.int16([node.attrib['y'] for node in lateral_attribs])
    lateral_z = np.int16([node.attrib['z'] for node in lateral_attribs])
    soma_attribs = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [int(node.attrib['x']) for node in soma_attribs][0]
    soma_y = [int(node.attrib['y']) for node in soma_attribs][0]
    soma_z = [int(node.attrib['z']) for node in soma_attribs][0]
    #Translate apical node the distances required for soma to be a 0,0,0
    trans_apical_x = (apical_x - soma_x)
    trans_apical_y = (apical_y - soma_y)
    trans_apical_z = (apical_z - soma_z)

    # Translate lateral indicator node the distances required for soma to be 0,0,0
    trans_lateral_x = (lateral_x - soma_x)
    trans_lateral_y = (lateral_y - soma_y)
    trans_lateral_z = (lateral_z - soma_z)

    #remove the lateral node so that it isn't counted as a tip/path/vector
    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    tip_list.remove(lateral_node_list[0])

    #define original vector as that of the sapical dendrite
    apicalv = np.array([trans_apical_x, trans_apical_y, trans_apical_z])

    # Compute the rotation matrix
    R = get_rotation_matrix(apicalv)

    # Apply the rotation matrix to the apical vector
    newv = np.dot(apicalv.T, R.T)

    # roate the lateral vector to be in register with rotated cell
    lateralv = np.array([trans_lateral_x, trans_lateral_y, trans_lateral_z])
    newlatv = np.dot(lateralv.T, R.T)
    newlatv_a_l = [[coordinate for coordinate in vector] for vector in newlatv]
    newlatv_int = [int(coord) for coord in newlatv_a_l[0]]

    newlatv_coords = []
    #flip lateral vector if it is on the wrong side
    if newlatv_int[0] <1 :
        newlatv_coords.append((newlatv_int[0], newlatv_int[1],newlatv_int[2]))
    else:
        newlatv_coords.append((-newlatv_int[0],newlatv_int[1],newlatv_int[2]))
    # print newlatv_coords
    #Apply the rotation matrix to tip-soma vector for each path
    #Note that each tip-to-soma path has been translated (subtraction) such that the soma is a 0,0,0
    #This is so that the rotation can be applied and simple +/- integer used to determine lateral position
    trans_tips = []

    matches = [item for item in node_location if item[0] in tip_list]
    int_matches = [[int(coordinate) for coordinate in match] for match in matches]

    for match in int_matches:
        tipv = np.array([match[1]-soma_x, match[2]-soma_y, match[3]- soma_z])
        newtip = np.dot(tipv.T,R.T)

        trans_tips.append([match[0], newtip[0],newtip[1],newtip[2]])
        # print trans_tips

    trans_tips_int = [[int(coords) for coords in tip] for tip in trans_tips]
    # print trans_tips_int
    #Flip the cells so that the lateral side is on the left, if necessary
    flipped_tips = []
    for tip in trans_tips_int:
        if newlatv_int[0] <1 :
            flipped_tips.append((tip[0], tip[1], tip[2], tip[3]))
        else:
            flipped_tips.append((tip[0], -tip[1], tip[2], tip[3]))

    # print flipped_tips

    # find tips that are on each side of the soma
    negative_tips = [tip[0] for tip in flipped_tips if tip[1] < 0]
    positive_tips = [tip[0] for tip in flipped_tips if tip[1] > 0]
    # print negative_tips
    # print positive_tips

    #find the distance from the soma (0,0,0) and each tip (radius)
    #Because the soma is always at (0,0,0), we can omit the subtraction present in the standard distance formula

    distance = []
    for tip in flipped_tips:
        distance.append(np.sqrt(tip[1]**2 + tip[2]**2))
    # print distance

    #make unit vectors for all the vectors
    #start with apical vector
    apical_mag = math.sqrt(newv[0]**2 + newv[1]**2 )
    unit_apicalv = (newv[0]/apical_mag, newv[1]/apical_mag)
    # print unit_apicalv

    unit_tip_vectors = []
    for tip in flipped_tips:
        tip_mag = math.sqrt(tip[1]**2 + tip[2]**2 )
        unit_tip_vectors.append((tip[0], tip[1]/tip_mag, tip[2]/tip_mag))

    # print unit_tip_vectors

    #find the angle between the apical vector and the vector that defines each path (soma to tip only)
    #return both the tip index (used later) and the angle in degrees.
    tip_angle = []
    for vector in unit_tip_vectors:
        # tip_coords = np.array(tip[1:4])
        v1_u = unit_apicalv
        v2_u = vector[1:3]
        tip_angle.append([vector[0],np.degrees(np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0)))])

    # print tip_angle

    #get just the angles of the tips for later calculations
    angles_180 = [angle[1] for angle in tip_angle]

    # print paths_180
    #correct the calculated angle by converting to 360 coordinates. The original calculation gives the smallest
    #angle between apical and tip (all <180), so add 180 to all "negative" tips to make 360 coordinates
    #"negative" tips were chosen as a convention. Either "negative" or "positive" could be used at users desire
    angles_360 = []
    for tip in tip_angle:
        if tip[0] in positive_tips:
            angles_360.append((360-tip[1]))

        else:
            angles_360.append(tip[1])
    # print angles_360

    #get the number and fraction of segments that fall into each 45degree interval
    angles_0_15 = []
    angles_15_30 = []
    angles_30_45 = []
    angles_45_60 = []
    angles_60_75 = []
    angles_75_90 = []
    angles_90_105 = []
    angles_105_120 = []
    angles_120_135 = []
    angles_135_150 = []
    angles_150_165 = []
    angles_165_180 = []
    angles_180_195 = []
    angles_195_210 = []
    angles_210_225 = []
    angles_225_240 = []
    angles_240_255 = []
    angles_255_270 = []
    angles_270_285 = []
    angles_285_300 = []
    angles_300_315 = []
    angles_315_330 = []
    angles_330_345 = []
    angles_345_360 = []

    for angle in angles_360:
        if 0< angle <15:
            angles_0_15.append(angle)
    for angle in angles_360:
        if 15< angle <30:
            angles_15_30.append(angle)
    for angle in angles_360:
        if 30< angle <45:
            angles_30_45.append(angle)
    for angle in angles_360:
        if 45< angle <60:
            angles_45_60.append(angle)
    for angle in angles_360:
        if 60< angle <75:
            angles_60_75.append(angle)
    for angle in angles_360:
        if 75< angle <90:
            angles_75_90.append(angle)
    for angle in angles_360:
        if 90< angle<105:
            angles_90_105.append(angle)
    for angle in angles_360:
        if 105< angle <120:
            angles_105_120.append(angle)

    for angle in angles_360:
        if 120 < angle < 135:
            angles_120_135.append(angle)
    for angle in angles_360:
        if 135 < angle < 150:
            angles_135_150.append(angle)
    for angle in angles_360:
        if 150 < angle < 165:
            angles_150_165.append(angle)
    for angle in angles_360:
        if 165 < angle < 180:
            angles_165_180.append(angle)
    for angle in angles_360:
        if 180 < angle < 195:
            angles_180_195.append(angle)
    for angle in angles_360:
        if 195 < angle < 210:
            angles_195_210.append(angle)
    for angle in angles_360:
        if 210 < angle < 225:
            angles_210_225.append(angle)
    for angle in angles_360:
        if 225 < angle < 240:
            angles_225_240.append(angle)

    for angle in angles_360:
        if 240 < angle < 255:
            angles_240_255.append(angle)
    for angle in angles_360:
        if 255 < angle < 270:
            angles_255_270.append(angle)
    for angle in angles_360:
        if 270 < angle < 285:
            angles_270_285.append(angle)
    for angle in angles_360:
        if 285 < angle < 300:
            angles_285_300.append(angle)
    for angle in angles_360:
        if 300 < angle < 315:
            angles_300_315.append(angle)
    for angle in angles_360:
        if 315 < angle < 330:
            angles_315_330.append(angle)
    for angle in angles_360:
        if 330 < angle < 345:
            angles_330_345.append(angle)
    for angle in angles_360:
        if 345 < angle < 360:
            angles_345_360.append(angle)


    #calculate number of paths in each zone
    total_number_tips =  float(len(angles_360))

    num_angles_0_15 = float(len(angles_0_15))
    num_angles_15_30 = float(len(angles_15_30))
    num_angles_30_45 = float(len(angles_30_45))
    num_angles_45_60 = float(len(angles_45_60))
    num_angles_60_75 = float(len(angles_60_75))
    num_angles_75_90 = float(len(angles_75_90))
    num_angles_90_105 = float(len(angles_90_105))
    num_angles_105_120 = float(len(angles_105_120))

    num_angles_120_135 = float(len(angles_120_135))
    num_angles_135_150 = float(len(angles_135_150))
    num_angles_150_165 = float(len(angles_150_165))
    num_angles_165_180 = float(len(angles_165_180))
    num_angles_180_195 = float(len(angles_180_195))
    num_angles_195_210 = float(len(angles_195_210))
    num_angles_210_225 = float(len(angles_210_225))
    num_angles_225_240 = float(len(angles_225_240))

    num_angles_240_255 = float(len(angles_240_255))
    num_angles_255_270 = float(len(angles_255_270))
    num_angles_270_285 = float(len(angles_270_285))
    num_angles_285_300 = float(len(angles_285_300))
    num_angles_300_315 = float(len(angles_300_315))
    num_angles_315_330 = float(len(angles_315_330))
    num_angles_330_345 = float(len(angles_330_345))
    num_angles_345_360 = float(len(angles_345_360))

    # calculate fractional number of paths in each zone
    fraction_angles_0_15 = float(num_angles_0_15/total_number_tips)*100
    fraction_angles_15_30 = float(num_angles_15_30/total_number_tips)*100
    fraction_angles_30_45 = float(num_angles_30_45/total_number_tips)*100
    fraction_angles_45_60 = float(num_angles_45_60/total_number_tips)*100
    fraction_angles_60_75 = float(num_angles_60_75/total_number_tips)*100
    fraction_angles_75_90 = float(num_angles_75_90/total_number_tips)*100
    fraction_angles_90_105 = float(num_angles_90_105/total_number_tips)*100
    fraction_angles_105_120 = float(num_angles_105_120/total_number_tips)*100

    fraction_angles_120_135 = float(num_angles_120_135/total_number_tips)*100
    fraction_angles_135_150 = float(num_angles_135_150/total_number_tips)*100
    fraction_angles_150_165 = float(num_angles_150_165/total_number_tips)*100
    fraction_angles_165_180 = float(num_angles_165_180/total_number_tips)*100
    fraction_angles_180_195 = float(num_angles_180_195/total_number_tips)*100
    fraction_angles_195_210 = float(num_angles_195_210/total_number_tips)*100
    fraction_angles_210_225 = float(num_angles_210_225/total_number_tips)*100
    fraction_angles_225_240 = float(num_angles_225_240/total_number_tips)*100

    fraction_angles_240_255 = float(num_angles_240_255/total_number_tips)*100
    fraction_angles_255_270 = float(num_angles_255_270/total_number_tips)*100
    fraction_angles_270_285 = float(num_angles_270_285/total_number_tips)*100
    fraction_angles_285_300 = float(num_angles_285_300/total_number_tips)*100
    fraction_angles_300_315 = float(num_angles_300_315/total_number_tips)*100
    fraction_angles_315_330 = float(num_angles_315_330/total_number_tips)*100
    fraction_angles_330_345 = float(num_angles_330_345/total_number_tips)*100
    fraction_angles_345_360 = float(num_angles_345_360/total_number_tips)*100

    return num_angles_0_15,num_angles_15_30,num_angles_30_45,num_angles_45_60,num_angles_60_75,num_angles_75_90,num_angles_90_105,\
           num_angles_105_120, num_angles_120_135,num_angles_135_150,num_angles_150_165, num_angles_165_180,num_angles_180_195,\
           num_angles_195_210,num_angles_210_225,num_angles_225_240,num_angles_240_255,num_angles_255_270,num_angles_270_285,\
           num_angles_285_300,num_angles_300_315,num_angles_315_330,num_angles_330_345,num_angles_345_360,fraction_angles_0_15,\
           fraction_angles_15_30,fraction_angles_30_45,fraction_angles_45_60,fraction_angles_60_75,fraction_angles_75_90,fraction_angles_90_105,\
           fraction_angles_105_120, fraction_angles_120_135,fraction_angles_135_150,fraction_angles_150_165, fraction_angles_165_180,fraction_angles_180_195,\
           fraction_angles_195_210,fraction_angles_210_225,fraction_angles_225_240,fraction_angles_240_255,fraction_angles_255_270,fraction_angles_270_285,\
           fraction_angles_285_300,fraction_angles_300_315,fraction_angles_315_330,fraction_angles_330_345,fraction_angles_345_360  

