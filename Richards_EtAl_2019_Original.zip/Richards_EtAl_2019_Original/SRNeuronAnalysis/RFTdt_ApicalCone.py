import math
import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
from scipy import stats
import statsmodels.api as sm
from random import *

from RFTdt_Database_Queries import polarity_apical_cone

WT_0_15_values, WT_345_360_values,FLX_0_15_values, FLX_345_360_values = polarity_apical_cone('fraction')

# print WT_0_15_values

###Start by getting the data formated###
#separate apical cone paths by whether cell is polar or not
#in 0-15 degrees range
WT_not_polar_0_15 = [item[0] for item in WT_0_15_values if item[1] < 0.315]
print len(WT_not_polar_0_15)
WT_polar_0_15  = [item[0] for item in WT_0_15_values if item[1] > 0.315]
# print len(WT_polar_0_15)
FLX_not_polar_0_15  = [item[0] for item in FLX_0_15_values if item[1] < 0.315]
# print len(FLX_not_polar_0_15)
FLX_polar_0_15  = [item[0] for item in FLX_0_15_values if item[1] > 0.315]
# print len(FLX_polar_0_15)

#in 345-360 degrees range
WT_not_polar_345_360 = [item[0] for item in WT_345_360_values if item[1] < 0.315]
# print len(WT_not_polar_345_360)
WT_polar_345_360  = [item[0] for item in WT_345_360_values if item[1] > 0.315]
# print len(WT_polar_345_360)
FLX_not_polar_345_360  = [item[0] for item in FLX_345_360_values if item[1] < 0.315]
# print len(FLX_not_polar_345_360)
FLX_polar_345_360  = [item[0] for item in FLX_345_360_values if item[1] > 0.315]
# print len(FLX_polar_345_360)


#calucate total number of paths in apical cone for each group
WT_not_polar_cone_paths = [pair[0] + pair[1] for pair in zip(WT_not_polar_0_15,WT_not_polar_345_360)]
WT_polar_cone_paths = [pair[0] + pair[1] for pair in zip(WT_polar_0_15,WT_polar_345_360)]
FLX_not_polar_cone_paths = [pair[0] + pair[1] for pair in zip(FLX_not_polar_0_15,FLX_not_polar_345_360)]
FLX_polar_cone_paths = [pair[0] + pair[1] for pair in zip(FLX_polar_0_15,FLX_polar_345_360)]

# print WT_not_polar_cone_paths
# print WT_polar_cone_paths
# print FLX_not_polar_cone_paths
# print FLX_polar_cone_paths


#calucalte Mean and SEM for each group
WT_non_polar_cone_paths_mean = np.mean(WT_not_polar_cone_paths)
WT_polar_cone_paths_mean = np.mean(WT_polar_cone_paths)
FLX_non_polar_cone_paths_mean = np.mean(FLX_not_polar_cone_paths)
FLX_polar_cone_paths_mean = np.mean(FLX_polar_cone_paths)

WT_non_polar_cone_paths_SEM  = np.std(WT_not_polar_cone_paths,ddof=1) / math.sqrt(len(WT_not_polar_cone_paths))
WT_polar_cone_paths_SEM  = np.std(WT_polar_cone_paths,ddof=1) / math.sqrt(len(WT_polar_cone_paths))
FLX_non_polar_cone_paths_SEM  = np.std(FLX_not_polar_cone_paths,ddof=1) / math.sqrt(len(FLX_not_polar_cone_paths))
FLX_polar_cone_paths_SEM  = np.std(FLX_polar_cone_paths,ddof=1) / math.sqrt(len(FLX_polar_cone_paths))

###Run Correlations###

WT_apical_cone_values = WT_not_polar_cone_paths + WT_polar_cone_paths
FLX_apical_cone_values = FLX_not_polar_cone_paths + FLX_polar_cone_paths
# print WT_apical_cone_values

#this refers to the vector length value R. NOT RELATED TO R-squared below!!
WT_r_values = [item[1] for item in WT_0_15_values]
FLX_r_values = [item[1] for item in FLX_0_15_values]

#WT
# print 'WT Apical Cone V. Polarity'
r_squared = stats.pearsonr(WT_apical_cone_values, WT_r_values)
# print r_squared
#FLX
# print 'FLX Apical Cone V. Polarity'
r_squared = stats.pearsonr(FLX_apical_cone_values, FLX_r_values)
# print r_squared



fig,axs = plot.subplots(nrows=1, ncols=4, sharex=False, sharey=False)

##This is the plot for Polar vs non-Polar in WT and FLX
ax=axs[0]
# ax.set_ylim(0,1)
# ax.set_ylim(0,0.0006)
group_n = 4


WT_not_polar_xcoords = [uniform(-0.05,0.05) for value in WT_not_polar_cone_paths]

WT_polar_xcoords = [uniform(0.45,0.55) for value in WT_polar_cone_paths]

FLX_not_polar_xcoords = [uniform(1.95,2.05) for value in FLX_not_polar_cone_paths]

FLX_polar_xcoords = [uniform(2.45,2.55) for value in FLX_polar_cone_paths]


ax.scatter(0,WT_non_polar_cone_paths_mean, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WT_not_polar_xcoords,WT_not_polar_cone_paths, color = '#b4b4b4',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(0.5,WT_polar_cone_paths_mean, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WT_polar_xcoords,WT_polar_cone_paths, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(2,FLX_non_polar_cone_paths_mean, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(FLX_not_polar_xcoords,FLX_not_polar_cone_paths, color = '#fcd9cd',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(2.5,FLX_non_polar_cone_paths_mean, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(FLX_polar_xcoords,FLX_polar_cone_paths, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(0, WT_non_polar_cone_paths_mean,WT_non_polar_cone_paths_SEM,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')
ax.errorbar(0.5, WT_polar_cone_paths_mean,WT_polar_cone_paths_SEM,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')
ax.errorbar(2, FLX_non_polar_cone_paths_mean,FLX_non_polar_cone_paths_SEM,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')
ax.errorbar(2.5, FLX_polar_cone_paths_mean,FLX_polar_cone_paths_SEM,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')


#These are the scatter plots of WT and FLX correlations

#zsore the data so that the axes look nice
WT_apical_cone_values_zscore = stats.zscore(WT_apical_cone_values)
WT_r_values_zscore = stats.zscore(WT_r_values)
FLX_apical_cone_values_zscore = stats.zscore(FLX_apical_cone_values)
FLX_r_values_zscore = stats.zscore(FLX_r_values)

ax=axs[1]
ax.set_ylim(-2,5)
ax.set_xlim(-1,7)
ax.scatter(WT_apical_cone_values_zscore,WT_r_values_zscore, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.plot((-1,5),(-1,5),'-b')
ax=axs[2]
ax.set_ylim(-2,5)
ax.set_xlim(-1,7)
ax.scatter(FLX_apical_cone_values_zscore,FLX_r_values_zscore, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.plot((-1,5),(-1,5),'-b')


###Some additional apical cone plotting code. Was originally in Radial_Sholl_Graphs, but didn't fit in there
ax=axs[3]
# ax.set_xlim(0,2)
# ax.set_ylim(0,20)
#Plot WT + KO Dev Graph

xvalue = np.arange(group_n)

WT_apical_cone_mean = np.mean(WT_apical_cone_values)
FLX_apical_cone_mean = np.mean(FLX_apical_cone_values)

WT_apical_cone_SEM  = np.std(WT_apical_cone_values,ddof=1) / math.sqrt(len(WT_apical_cone_values))
FLX_apical_cone_SEM  = np.std(FLX_apical_cone_values,ddof=1) / math.sqrt(len(FLX_apical_cone_values))

WT_apical_cone_xcoords = []
WT_apical_cone_xcoords = [uniform(0.95,1.05) for value in WT_apical_cone_values]
# print WT_xcoords

FLX_apical_cone_xcoords = []
FLX_apical_cone_xcoords = [uniform(1.45,1.55) for value in FLX_apical_cone_values]
# print WT_xcoords


ax.scatter(1,WT_apical_cone_mean, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WT_apical_cone_xcoords,WT_apical_cone_values, color = '#343434',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.scatter(1.5,FLX_apical_cone_mean, color = '#df3325',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(FLX_apical_cone_xcoords,FLX_apical_cone_values, color = '#df3325',zorder='3',alpha='0.8',edgecolors='none',s=50)

ax.errorbar(1, WT_apical_cone_mean,WT_apical_cone_SEM,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')
ax.errorbar(1.5, FLX_apical_cone_mean,FLX_apical_cone_SEM,fmt='none',ecolor= '#df3325',elinewidth='2',capsize=5,capthick='2')

plot.show()