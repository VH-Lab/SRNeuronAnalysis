def number_summary_graphs(dpi, metric):

    import sqlite3
    connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    cursor = connection.execute("select * from RFTdt_Neurons")
    # for row in cursor:
    #     print row

    #By Genotype and Condition
    WTTR = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR'")
    WTTR_values = [row[0] for row in WTTR]
    # print WTTR_values

    FLXTR = connection.execute("select "+metric+ " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='FLX' and condition='TR'")
    FLXTR_values = [row[0] for row in FLXTR]
    # print FLXTR_values

    return WTTR_values,FLXTR_values
#

def length_summary_graphs(dpi, metric):

    import sqlite3
    connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    # cursor = connection.execute("select * from RFTdt_Neurons")
    # for row in cursor:
    #     print row

    #By Genotype and Condition
    WTTR_124 = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR' and pix_to_um ='1.24'")
    WTTR_values_124 = [row[0] for row in WTTR_124]
    WTTR_scaled_values_124 = [value*1.24 for value in WTTR_values_124]
    WTTR_042 = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR' and pix_to_um ='0.415'")
    WTTR_values_042 = [row[0] for row in WTTR_042]
    WTTR_scaled_values_042 = [value * 0.415 for value in WTTR_values_042]

    WTTR_values = WTTR_scaled_values_124 + WTTR_scaled_values_042

    # print WTTR_values
#
#     WTDD = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD'")
#     WTDD_values = [row[0] for row in WTDD]
#     # print WTDD_values
#
    FLXTR_124 = connection.execute(
        "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and pix_to_um ='1.24'")
    FLXTR_values_124 = [row[0] for row in FLXTR_124]
    FLXTR_scaled_values_124 = [value * 1.24 for value in FLXTR_values_124]
    FLXTR_042 = connection.execute(
        "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and pix_to_um ='0.42'")
    FLXTR_values_042 = [row[0] for row in FLXTR_042]
    FLXTR_scaled_values_042 = [value * 0.42 for value in FLXTR_values_042]

    FLXTR_values = FLXTR_scaled_values_124 + FLXTR_scaled_values_042

    # print FLXTR_values
#
#     FLXDD = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD'")
#     FLXDD_values = [row[0] for row in FLXDD]
#     # print FLXDD_values
#
#
#     #By Genotype, Condition, and Sex
#     WTTRM = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR' and sex='M'")
#     WTTRM_values = [row[0] for row in WTTRM]
#     # print WTTRM_values
#     WTTRF= connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR' and sex='F'")
#     WTTRF_values = [row[0] for row in WTTRF]
#     # print WTTRF_values
#
#
#     WTDDM = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD' and sex='M'")
#     WTDDM_values = [row[0] for row in WTDDM]
#     # print WTDDM_values
#     WTDDF = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD' and sex='F'")
#     WTDDF_values = [row[0] for row in WTDDF]
#     # print WTDDF_values
#
#
#     FLXTRM = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and sex='M'")
#     FLXTRM_values = [row[0] for row in FLXTRM]
#     # print FLXTRM_values
#     FLXTRF = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR' and sex='F'")
#     FLXTRF_values = [row[0] for row in FLXTRF]
#     # print FLXTRF_values
#
#
#     FLXDDM = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD' and sex='M'")
#     FLXDDM_values = [row[0] for row in FLXDDM]
#     # print FLXDDM_values
#     FLXDDF = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD' and sex='F'")
#     FLXDDF_values = [row[0] for row in FLXDDF]
#     # print FLXDDF_values
#
    return WTTR_values,FLXTR_values
#
# # WTTR_values,WTDD_values,FLXTR_values,FLXDD_values,WTTRM_values,WTTRF_values,WTDDM_values,WTDDF_values,FLXTRM_values,FLXTRF_values,FLXDDM_values,FLXDDF_values = summary_graphs('09dpi','soma_size')

#
def number_dev_graphs(metric):
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    cursor = connection.execute("select * from RFTdt_Neurons")
    # for row in cursor:
    #     print row

    WT_03dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_values = [row[0] for row in  WT_03dpi]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute("select "+ metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_values = [row[0] for row in  WT_05dpi]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_values = [row[0] for row in  WT_07dpi]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_values = [row[0] for row in  WT_09dpi]
    # print WTTR_09dpi_values

    WT_12dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi12_values = [row[0] for row in  WT_12dpi]
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_values = [row[0] for row in  FLX_03dpi]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_values = [row[0] for row in FLX_05dpi]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_values = [row[0] for row in FLX_07dpi]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_values = [row[0] for row in FLX_09dpi]
    # print  FLXTR_09dpi_values

    FLX_12dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi12_values = [row[0] for row in  FLX_12dpi]
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values,WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values,FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def length_dev_graphs(metric):
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    cursor = connection.execute("select * from RFTdt_Neurons")
    # for row in cursor:
    #     print row

    WT_03dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_raw_values = [row[0] for row in  WT_03dpi]
    WTTR_dpi03_values = [value*0.42 for value in WTTR_dpi03_raw_values]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute("select "+ metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_raw_values = [row[0] for row in  WT_05dpi]
    WTTR_dpi05_values = [value * 0.42 for value in WTTR_dpi05_raw_values]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_raw_values = [row[0] for row in  WT_07dpi]
    WTTR_dpi07_values = [value * 0.42 for value in WTTR_dpi07_raw_values]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_raw_values = [row[0] for row in  WT_09dpi]
    WTTR_dpi09_values = [value * 0.42 for value in WTTR_dpi09_raw_values]
    # print WTTR_09dpi_values

    WT_12dpi_124_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR' and pix_to_um='1.24'")
    WT_12dpi_124 = [row[0] for row in WT_12dpi_124_raw]
    WT_12dpi_042_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'and pix_to_um='0.42'")
    WT_12dpi_042 = [row[0] for row in WT_12dpi_042_raw]
    WT_12dpi_124_scaled = [value*1.24 for value in WT_12dpi_124]
    WT_12dpi_042_scaled = [value*0.42 for value in WT_12dpi_042]
    WTTR_dpi12_values = WT_12dpi_124_scaled + WT_12dpi_042_scaled
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_raw_values = [row[0] for row in  FLX_03dpi]
    FLXTR_dpi03_values = [value * 0.42 for value in FLXTR_dpi03_raw_values]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_raw_values = [row[0] for row in FLX_05dpi]
    FLXTR_dpi05_values = [value * 0.42 for value in FLXTR_dpi05_raw_values]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_raw_values = [row[0] for row in FLX_07dpi]
    FLXTR_dpi07_values = [value * 0.42 for value in FLXTR_dpi07_raw_values]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_raw_values = [row[0] for row in FLX_09dpi]
    FLXTR_dpi09_values = [value * 0.42 for value in FLXTR_dpi09_raw_values]
    # print  FLXTR_09dpi_values

    FLX_12dpi_124_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR' and pix_to_um='1.24'")
    FLX_12dpi_124 = [row[0] for row in FLX_12dpi_124_raw]
    FLX_12dpi_042_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'and pix_to_um='0.42'")
    FLX_12dpi_042 = [row[0] for row in FLX_12dpi_042_raw]
    FLX_12dpi_124_scaled = [value * 1.24 for value in FLX_12dpi_124]
    FLX_12dpi_042_scaled = [value * 0.42 for value in FLX_12dpi_042]
    FLXTR_dpi12_values = FLX_12dpi_124_scaled + FLX_12dpi_042_scaled
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values,WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values,FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def volume_dev_graphs(metric):
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    cursor = connection.execute("select * from RFTdt_Neurons")
    # for row in cursor:
    #     print row

    WT_03dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_raw_values = [row[0] for row in  WT_03dpi]
    WTTR_dpi03_values = [value*0.42**3 for value in WTTR_dpi03_raw_values]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute("select "+ metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_raw_values = [row[0] for row in  WT_05dpi]
    WTTR_dpi05_values = [value * 0.42**3 for value in WTTR_dpi05_raw_values]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_raw_values = [row[0] for row in  WT_07dpi]
    WTTR_dpi07_values = [value * 0.42**3 for value in WTTR_dpi07_raw_values]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_raw_values = [row[0] for row in  WT_09dpi]
    WTTR_dpi09_values = [value * 0.42**3 for value in WTTR_dpi09_raw_values]
    # print WTTR_09dpi_values

    WT_12dpi_124_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR' and pix_to_um='1.24'")
    WT_12dpi_124 = [row[0] for row in WT_12dpi_124_raw]
    WT_12dpi_042_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'and pix_to_um='0.42'")
    WT_12dpi_042 = [row[0] for row in WT_12dpi_042_raw]
    WT_12dpi_124_scaled = [value*1.24**3 for value in WT_12dpi_124]
    WT_12dpi_042_scaled = [value*0.42**3 for value in WT_12dpi_042]
    WTTR_dpi12_values = WT_12dpi_124_scaled + WT_12dpi_042_scaled
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_raw_values = [row[0] for row in  FLX_03dpi]
    FLXTR_dpi03_values = [value * 0.42**3 for value in FLXTR_dpi03_raw_values]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_raw_values = [row[0] for row in FLX_05dpi]
    FLXTR_dpi05_values = [value * 0.42**3 for value in FLXTR_dpi05_raw_values]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_raw_values = [row[0] for row in FLX_07dpi]
    FLXTR_dpi07_values = [value * 0.42**3 for value in FLXTR_dpi07_raw_values]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_raw_values = [row[0] for row in FLX_09dpi]
    FLXTR_dpi09_values = [value * 0.42**3 for value in FLXTR_dpi09_raw_values]
    # print  FLXTR_09dpi_values

    FLX_12dpi_124_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR' and pix_to_um='1.24'")
    FLX_12dpi_124 = [row[0] for row in FLX_12dpi_124_raw]
    FLX_12dpi_042_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'and pix_to_um='0.42'")
    FLX_12dpi_042 = [row[0] for row in FLX_12dpi_042_raw]
    FLX_12dpi_124_scaled = [value * 1.24**3 for value in FLX_12dpi_124]
    FLX_12dpi_042_scaled = [value * 0.42**3 for value in FLX_12dpi_042]
    FLXTR_dpi12_values = FLX_12dpi_124_scaled + FLX_12dpi_042_scaled
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values,WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values,FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def density_dev_graphs(metric):
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    cursor = connection.execute("select * from RFTdt_Neurons")
    # for row in cursor:
    #     print row

    WT_03dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_raw_values = [row[0] for row in  WT_03dpi]
    WTTR_dpi03_values = [value/(0.42**2) for value in WTTR_dpi03_raw_values]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute("select "+ metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_raw_values = [row[0] for row in  WT_05dpi]
    WTTR_dpi05_values = [value/(0.42**2) for value in WTTR_dpi05_raw_values]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_raw_values = [row[0] for row in  WT_07dpi]
    WTTR_dpi07_values = [value/(0.42**2) for value in WTTR_dpi07_raw_values]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_raw_values = [row[0] for row in  WT_09dpi]
    WTTR_dpi09_values = [value/(0.42**2) for value in WTTR_dpi09_raw_values]
    # print WTTR_09dpi_values

    WT_12dpi_124_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR' and pix_to_um='1.24'")
    WT_12dpi_124 = [row[0] for row in WT_12dpi_124_raw]
    WT_12dpi_042_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'and pix_to_um='0.42'")
    WT_12dpi_042 = [row[0] for row in WT_12dpi_042_raw]
    WT_12dpi_124_scaled = [value/(1.24**2) for value in WT_12dpi_124]
    WT_12dpi_042_scaled = [value/(0.42**2) for value in WT_12dpi_042]
    WTTR_dpi12_values = WT_12dpi_124_scaled + WT_12dpi_042_scaled
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_raw_values = [row[0] for row in  FLX_03dpi]
    FLXTR_dpi03_values = [value/(0.42**2) for value in FLXTR_dpi03_raw_values]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_raw_values = [row[0] for row in FLX_05dpi]
    FLXTR_dpi05_values = [value/(0.42**2) for value in FLXTR_dpi05_raw_values]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_raw_values = [row[0] for row in FLX_07dpi]
    FLXTR_dpi07_values = [value/(0.42**2) for value in FLXTR_dpi07_raw_values]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute( "select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_raw_values = [row[0] for row in FLX_09dpi]
    FLXTR_dpi09_values = [value/(0.42**2) for value in FLXTR_dpi09_raw_values]
    # print  FLXTR_09dpi_values

    FLX_12dpi_124_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR' and pix_to_um='1.24'")
    FLX_12dpi_124 = [row[0] for row in FLX_12dpi_124_raw]
    FLX_12dpi_042_raw = connection.execute("select " + metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'and pix_to_um='0.42'")
    FLX_12dpi_042 = [row[0] for row in FLX_12dpi_042_raw]
    FLX_12dpi_124_scaled = [value/(1.24**2) for value in FLX_12dpi_124]
    FLX_12dpi_042_scaled = [value/(0.42**2) for value in FLX_12dpi_042]
    FLXTR_dpi12_values = FLX_12dpi_124_scaled + FLX_12dpi_042_scaled
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values,WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values,FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values



def sholl_values(dpi, metric):

    import sqlite3
    connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\RFTdt_Dendrite_Analysis.db')
    # cursor = connection.execute("select genotype from RFTdt_Neurons")
    # for row in cursor:
    #     print row

    #By Genotype and Condition
    WTTR = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='WT' and condition='TR'")
    WTTR_values = [row[0] for row in WTTR]
    # print WTTR_values
    WTTR_values = [strings.split(',') for strings in WTTR_values]
    # print WTTR_values
    WTTR_values = [[int(sholl_intersections) for sholl_intersections in values] for values in WTTR_values]
    # print WTTR_values

    # WTDD = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='DD'")
    # WTDD_values = [row[0] for row in WTDD]
    # # print WTDD_values
    # WTDD_values = [strings.split(',') for strings in WTDD_values]
    # # print WTDD_values
    # WTDD_values = [[int(sholl_intersections) for sholl_intersections in values] for values in WTDD_values]
    # # print WTDD_values

    FLXTR = connection.execute("select "+metric+ " from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '"+dpi+"'and genotype='FLX' and condition='TR'")
    FLXTR_values = [row[0] for row in FLXTR]
    FLXTR_values = [strings.split(',') for strings in FLXTR_values]
    FLXTR_values = [[int(sholl_intersections) for sholl_intersections in values] for values in FLXTR_values]
    # print FLXTR_values

    # FLXDD = connection.execute("select "+metric + " from RFTdt_Neurons left join RFTdt_Animals on neurons.animal_id = animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='DD'")
    # FLXDD_values = [row[0] for row in FLXDD]
    # FLXDD_values = [strings.split(',') for strings in FLXDD_values]
    # FLXDD_values = [[int(sholl_intersections) for sholl_intersections in values] for values in FLXDD_values]
    # # print FLXDD_values

    return WTTR_values, FLXTR_values

def polarity_summary_graphs(dpi,metric):

    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WTTR = connection.execute("select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR'")
    WTTR_values = [row[0] for row in WTTR]

    FLXTR = connection.execute("select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR'")
    FLXTR_values = [row[0] for row in FLXTR]

    return WTTR_values, FLXTR_values

def polarity_dev_graphs(metric):

    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WT_03dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_values = [row[0] for row in WT_03dpi]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_values = [row[0] for row in WT_05dpi]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_values = [row[0] for row in WT_07dpi]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_values = [row[0] for row in WT_09dpi]
    # print WTTR_09dpi_values

    WT_12dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi12_values = [row[0] for row in WT_12dpi]
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_values = [row[0] for row in FLX_03dpi]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_values = [row[0] for row in FLX_05dpi]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_values = [row[0] for row in FLX_07dpi]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_values = [row[0] for row in FLX_09dpi]
    # print  FLXTR_09dpi_values

    FLX_12dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi12_values = [row[0] for row in FLX_12dpi]
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values, WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values, FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def absolute_polarity_summary_graphs(med_metric,lat_metric):

    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WTTR_Med = connection.execute("select " + med_metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='WT' and condition='TR'")
    WTTR_Med_values = [row[0] for row in WTTR_Med]

    WTTR_Lat = connection.execute(
        "select " + lat_metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='WT' and condition='TR'")
    WTTR_Lat_values = [row[0] for row in WTTR_Lat]


    FLXTR_Med = connection.execute("select " + med_metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLXTR_Med_values = [row[0] for row in FLXTR_Med]

    FLXTR_Lat = connection.execute(
        "select " + lat_metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLXTR_Lat_values = [row[0] for row in FLXTR_Lat]

    return WTTR_Med_values,WTTR_Lat_values, FLXTR_Med_values, FLXTR_Lat_values

def absolute_polarity_dev_graphs(metric):

    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WT_03dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_values = [row[0] for row in WT_03dpi]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_values = [row[0] for row in WT_05dpi]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_values = [row[0] for row in WT_07dpi]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_values = [row[0] for row in WT_09dpi]
    # print WTTR_09dpi_values

    WT_12dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi12_values = [row[0] for row in WT_12dpi]
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_values = [row[0] for row in FLX_03dpi]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_values = [row[0] for row in FLX_05dpi]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_values = [row[0] for row in FLX_07dpi]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_values = [row[0] for row in FLX_09dpi]
    # print  FLXTR_09dpi_values

    FLX_12dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi12_values = [row[0] for row in FLX_12dpi]
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values, WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values, FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def directionality_summary_graphs(dpi,med_metric,lat_metric):

    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WTTR= connection.execute("select " + med_metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='WT' and condition='TR'")
    WTTR_values = [row[0] for row in WTTR]


    FLXTR = connection.execute("select " + med_metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '" + dpi + "'and genotype='FLX' and condition='TR'")
    FLXTR_values = [row[0] for row in FLXTR]


    return WTTR_values, FLXTR_values




def directionality_dev_graphs(metric):

    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WT_03dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi03_values = [row[0] for row in WT_03dpi]
    # print WTTR_03dpi_values

    WT_05dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi05_values = [row[0] for row in WT_05dpi]
    # print WTTR_05dpi_values

    WT_07dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi07_values = [row[0] for row in WT_07dpi]
    # print WTTR_07dpi_values

    WT_09dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi09_values = [row[0] for row in WT_09dpi]
    # print WTTR_09dpi_values

    WT_12dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'")
    WTTR_dpi12_values = [row[0] for row in WT_12dpi]
    # print WTTR_12dpi_values

    FLX_03dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi03_values = [row[0] for row in FLX_03dpi]
    # print  FLXTR_03dpi_values

    FLX_05dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi05_values = [row[0] for row in FLX_05dpi]
    # print  FLXTR_05dpi_values

    FLX_07dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi07_values = [row[0] for row in FLX_07dpi]
    # print  FLXTR_07dpi_values

    FLX_09dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi09_values = [row[0] for row in FLX_09dpi]
    # print  FLXTR_09dpi_values

    FLX_12dpi = connection.execute(
        "select " + metric + " from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'")
    FLXTR_dpi12_values = [row[0] for row in FLX_12dpi]
    # print  FLXTR_12dpi_values

    return WTTR_dpi03_values, WTTR_dpi05_values, WTTR_dpi07_values, WTTR_dpi09_values, WTTR_dpi12_values, FLXTR_dpi03_values, FLXTR_dpi05_values, FLXTR_dpi07_values, FLXTR_dpi09_values, FLXTR_dpi12_values

def radial_sholl(qualifier):
##argument designates whether you're asking for the number of paths in each "slice" (confusingly called "len" or the ratio of that number to the total
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WT_0_15 = connection.execute(
        "select " + qualifier + "_angles_0_15,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_0_15_values= [row for row in WT_0_15]
    # print WTTR_0_45_values

    WT_15_30 = connection.execute(
        "select " + qualifier + "_angles_15_30,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_15_30_values = [row for row in WT_15_30]
    # print WTTR_45_90_values


    WT_30_45 = connection.execute(
        "select " + qualifier + "_angles_30_45,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='WT' and condition='TR'")
    WT_30_45_values = [row for row in WT_30_45]
    # print WTTR_90_135_values


    WT_45_60 = connection.execute(
        "select " + qualifier + "_angles_45_60,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_45_60_values = [row for row in WT_45_60]
    # print WTTR_135_180_values


    WT_60_75 = connection.execute(
        "select " + qualifier + "_angles_60_75,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_60_75_values = [row for row in WT_60_75]
    # print WTTR_180_225_values


    WT_75_90 = connection.execute(
        "select " + qualifier + "_angles_75_90,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_75_90_values = [row for row in WT_75_90]
    # print WTTR_225_270_values

    WT_90_105 = connection.execute(
        "select " + qualifier + "_angles_90_105,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_90_105_values = [row for row in WT_90_105]
    # print WTTR_270_315_values


    WT_105_120 = connection.execute(
        "select " + qualifier + "_angles_105_120,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_105_120_values = [row for row in WT_105_120]
    # print WTTR_315_360_values

    
    WT_120_135 = connection.execute(
        "select " + qualifier + "_angles_120_135,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='WT' and condition='TR'")
    WT_120_135_values = [row for row in WT_120_135]
    # print WTTR_0_45_values
    
    WT_135_150 = connection.execute(
        "select " + qualifier + "_angles_135_150,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_135_150_values = [row for row in WT_135_150]
    # print WTTR_45_90_values
    
    
    WT_150_165 = connection.execute(
        "select " + qualifier + "_angles_150_165,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='WT' and condition='TR'")
    WT_150_165_values = [row for row in WT_150_165]
    # print WTTR_90_135_values
    
    
    WT_165_180 = connection.execute(
        "select " + qualifier + "_angles_165_180,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_165_180_values = [row for row in WT_165_180]
    # print WTTR_135_180_values
    
    
    WT_180_195 = connection.execute(
        "select " + qualifier + "_angles_180_195,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='WT' and condition='TR'")
    WT_180_195_values = [row for row in WT_180_195]
    # print WTTR_180_225_values
    
    
    WT_195_210 = connection.execute(
        "select " + qualifier + "_angles_195_210,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_195_210_values = [row for row in WT_195_210]
    # print WTTR_225_270_values
    
    WT_210_225 = connection.execute(
        "select " + qualifier + "_angles_210_225,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_210_225_values = [row for row in WT_210_225]
    # print WTTR_270_315_values
    
    
    WT_225_240 = connection.execute(
        "select " + qualifier + "_angles_225_240,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_225_240_values = [row for row in WT_225_240]
    # print WTTR_315_360_values


    WT_240_255 = connection.execute(
        "select " + qualifier + "_angles_240_255,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_240_255_values = [row for row in WT_240_255]
    # print WTTR_0_45_values
    
    WT_255_270 = connection.execute(
        "select " + qualifier + "_angles_255_270,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='WT' and condition='TR'")
    WT_255_270_values = [row for row in WT_255_270]
    # print WTTR_45_90_values
    
    
    WT_270_285 = connection.execute(
        "select " + qualifier + "_angles_270_285,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_270_285_values = [row for row in WT_270_285]
    # print WTTR_90_135_values
    
    
    WT_285_300 = connection.execute(
        "select " + qualifier + "_angles_285_300,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_285_300_values = [row for row in WT_285_300]
    # print WTTR_135_180_values
    
    
    WT_300_315 = connection.execute(
        "select " + qualifier + "_angles_300_315,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='WT' and condition='TR'")
    WT_300_315_values = [row for row in WT_300_315]
    # print WTTR_180_225_values
    
    
    WT_315_330 = connection.execute(
        "select " + qualifier + "_angles_315_330,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_315_330_values = [row for row in WT_315_330]
    # print WTTR_225_270_values
    
    WT_330_345 = connection.execute(
        "select " + qualifier + "_angles_330_345,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='WT' and condition='TR'")
    WT_330_345_values = [row for row in WT_330_345]
    # print WTTR_270_315_values
    
    
    WT_345_360 = connection.execute(
        "select " + qualifier + "_angles_345_360,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_345_360_values = [row for row in WT_345_360]
    # print WTTR_315_360_values


    FLX_0_15 = connection.execute(
        "select " + qualifier + "_angles_0_15,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_0_15_values = [row for row in FLX_0_15]
    # print FLXTR_0_45_values
    
    FLX_15_30 = connection.execute(
        "select " + qualifier + "_angles_15_30,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_15_30_values = [row for row in FLX_15_30]
    # print FLXTR_45_90_values
    
    
    FLX_30_45 = connection.execute(
        "select " + qualifier + "_angles_30_45,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_30_45_values = [row for row in FLX_30_45]
    # print FLXTR_90_135_values
    
    
    FLX_45_60 = connection.execute(
        "select " + qualifier + "_angles_45_60,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='FLX' and condition='TR'")
    FLX_45_60_values = [row for row in FLX_45_60]
    # print FLXTR_135_180_values
    
    
    FLX_60_75 = connection.execute(
        "select " + qualifier + "_angles_60_75,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where   genotype='FLX' and condition='TR'")
    FLX_60_75_values = [row for row in FLX_60_75]
    # print FLXTR_180_225_values
    
    
    FLX_75_90 = connection.execute(
        "select " + qualifier + "_angles_75_90,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_75_90_values = [row for row in FLX_75_90]
    # print FLXTR_225_270_values
    
    FLX_90_105 = connection.execute(
        "select " + qualifier + "_angles_90_105,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLX_90_105_values = [row for row in FLX_90_105]
    # print FLXTR_270_315_values
    
    
    FLX_105_120 = connection.execute(
        "select " + qualifier + "_angles_105_120,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_105_120_values = [row for row in FLX_105_120]
    # print FLXTR_315_360_values
    
    
    FLX_120_135 = connection.execute(
        "select " + qualifier + "_angles_120_135,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_120_135_values = [row for row in FLX_120_135]
    # print FLXTR_0_45_values
    
    FLX_135_150 = connection.execute(
        "select " + qualifier + "_angles_135_150,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_135_150_values = [row for row in FLX_135_150]
    # print FLXTR_45_90_values
    
    
    FLX_150_165 = connection.execute(
        "select " + qualifier + "_angles_150_165,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLX_150_165_values = [row for row in FLX_150_165]
    # print FLXTR_90_135_values
    
    
    FLX_165_180 = connection.execute(
        "select " + qualifier + "_angles_165_180,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_165_180_values = [row for row in FLX_165_180]
    # print FLXTR_135_180_values
    
    
    FLX_180_195 = connection.execute(
        "select " + qualifier + "_angles_180_195,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_180_195_values = [row for row in FLX_180_195]
    # print FLXTR_180_225_values
    
    
    FLX_195_210 = connection.execute(
        "select " + qualifier + "_angles_195_210,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_195_210_values = [row for row in FLX_195_210]
    # print FLXTR_225_270_values
    
    FLX_210_225 = connection.execute(
        "select " + qualifier + "_angles_210_225,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLX_210_225_values = [row for row in FLX_210_225]
    # print FLXTR_270_315_values
    
    
    FLX_225_240 = connection.execute(
        "select " + qualifier + "_angles_225_240,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_225_240_values = [row for row in FLX_225_240]
    # print FLXTR_315_360_values
    
    
    FLX_240_255 = connection.execute(
        "select " + qualifier + "_angles_240_255,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLX_240_255_values = [row for row in FLX_240_255]
    # print FLXTR_0_45_values
    
    FLX_255_270 = connection.execute(
        "select " + qualifier + "_angles_255_270,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_255_270_values = [row for row in FLX_255_270]
    # print FLXTR_45_90_values
    
    
    FLX_270_285 = connection.execute(
        "select " + qualifier + "_angles_270_285,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLX_270_285_values = [row for row in FLX_270_285]
    # print FLXTR_90_135_values
    
    
    FLX_285_300 = connection.execute(
        "select " + qualifier + "_angles_285_300,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_285_300_values = [row for row in FLX_285_300]
    # print FLXTR_135_180_values
    
    
    FLX_300_315 = connection.execute(
        "select " + qualifier + "_angles_300_315,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_300_315_values = [row for row in FLX_300_315]
    # print FLXTR_180_225_values
    
    
    FLX_315_330 = connection.execute(
        "select " + qualifier + "_angles_315_330,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_315_330_values = [row for row in FLX_315_330]
    # print FLXTR_225_270_values
    
    FLX_330_345 = connection.execute(
        "select " + qualifier + "_angles_330_345,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLX_330_345_values = [row for row in FLX_330_345]
    # print FLXTR_270_315_values
    
    
    FLX_345_360 = connection.execute(
        "select " + qualifier + "_angles_345_360,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_345_360_values = [row for row in FLX_345_360]
    # print FLXTR_315_360_values
    

    return WT_0_15_values, WT_15_30_values,WT_30_45_values,WT_45_60_values,WT_60_75_values,WT_75_90_values,WT_90_105_values,\
           WT_105_120_values,WT_120_135_values, WT_135_150_values,WT_150_165_values,WT_165_180_values,WT_180_195_values,WT_195_210_values,WT_210_225_values,\
           WT_225_240_values,WT_240_255_values, WT_255_270_values,WT_270_285_values,WT_285_300_values,WT_300_315_values,WT_315_330_values,WT_330_345_values,\
           WT_345_360_values, FLX_0_15_values, FLX_15_30_values,FLX_30_45_values,FLX_45_60_values,FLX_60_75_values,FLX_75_90_values,FLX_90_105_values,\
           FLX_105_120_values,FLX_120_135_values, FLX_135_150_values,FLX_150_165_values,FLX_165_180_values,FLX_180_195_values,FLX_195_210_values,FLX_210_225_values,\
           FLX_225_240_values,FLX_240_255_values, FLX_255_270_values,FLX_270_285_values,FLX_285_300_values,FLX_300_315_values,FLX_315_330_values,FLX_330_345_values,\
           FLX_345_360_values

def polarity_apical_cone(qualifier):
##argument designates whether you're asking for the number of paths in each "slice" (confusingly called "len" or the ratio of that number to the total
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

    WT_0_15 = connection.execute(
        "select " + qualifier + "_angles_0_15,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='WT' and condition='TR'")
    WT_0_15_values= [row for row in WT_0_15]

    WT_345_360 = connection.execute(
        "select " + qualifier + "_angles_345_360,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='WT' and condition='TR'")
    WT_345_360_values = [row for row in WT_345_360]

    FLX_0_15 = connection.execute(
        "select " + qualifier + "_angles_0_15,r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where  genotype='FLX' and condition='TR'")
    FLX_0_15_values= [row for row in FLX_0_15]

    FLX_345_360 = connection.execute(
        "select " + qualifier + "_angles_345_360, r from RFTdt_OriNeurons left join RFTdt_Animals on rftdt_orineurons.animal_id = rftdt_animals.animal_id where genotype='FLX' and condition='TR'")
    FLX_345_360_values = [row for row in FLX_345_360]

    return WT_0_15_values,WT_345_360_values, FLX_0_15_values, FLX_345_360_values

def geno_growth_components():
    import sqlite3
    connection = sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
    # cursor = connection.execute("select genotype from Neurons")
    # for row in cursor:
    #     print row

    # By Genotype and Condition
    dpi03_WT_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi'and genotype='WT' and condition='TR'")
    dpi03_raw_values = [row[0] for row in dpi03_WT_arbor]
    dpi03_WT_arbor = [value * 0.42 for value in dpi03_raw_values]

    dpi03_WT_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi'and genotype='WT' and condition='TR'")
    dpi03_raw_values = [row[0] for row in dpi03_WT_seglen]
    dpi03_WT_seglen = [value * 0.42 for value in dpi03_raw_values]

    dpi03_WT_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi'and genotype='WT' and condition='TR'")
    dpi03_WT_segnum = [row[0] for row in dpi03_WT_segnum]
    

    dpi05_WT_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi'and genotype='WT' and condition='TR'")
    dpi05_raw_values = [row[0] for row in dpi05_WT_arbor]
    dpi05_WT_arbor = [value * 0.42 for value in dpi05_raw_values]

    dpi05_WT_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi'and genotype='WT' and condition='TR'")
    dpi05_raw_values = [row[0] for row in dpi05_WT_seglen]
    dpi05_WT_seglen = [value * 0.42 for value in dpi05_raw_values]

    dpi05_WT_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi'and genotype='WT' and condition='TR'")
    dpi05_WT_segnum = [row[0] for row in dpi05_WT_segnum]


    dpi07_WT_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi'and genotype='WT' and condition='TR'")
    dpi07_raw_values = [row[0] for row in dpi07_WT_arbor]
    dpi07_WT_arbor = [value * 0.42 for value in dpi07_raw_values]

    dpi07_WT_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi'and genotype='WT' and condition='TR'")
    dpi07_raw_values = [row[0] for row in dpi07_WT_seglen]
    dpi07_WT_seglen = [value * 0.42 for value in dpi07_raw_values]

    dpi07_WT_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi'and genotype='WT' and condition='TR'")
    dpi07_WT_segnum = [row[0] for row in dpi07_WT_segnum]


    dpi09_WT_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi'and genotype='WT' and condition='TR'")
    dpi09_raw_values = [row[0] for row in dpi09_WT_arbor]
    dpi09_WT_arbor = [value * 0.42 for value in dpi09_raw_values]

    dpi09_WT_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi'and genotype='WT' and condition='TR'")
    dpi09_raw_values = [row[0] for row in dpi09_WT_seglen]
    dpi09_WT_seglen = [value * 0.42 for value in dpi09_raw_values]

    dpi09_WT_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi'and genotype='WT' and condition='TR'")
    dpi09_WT_segnum = [row[0] for row in dpi09_WT_segnum]


    WT_12dpi_124_raw = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR' and pix_to_um='1.24'")
    WT_12dpi_124 = [row[0] for row in WT_12dpi_124_raw]
    WT_12dpi_042_raw = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'and pix_to_um='0.42'")
    WT_12dpi_042 = [row[0] for row in WT_12dpi_042_raw]
    WT_12dpi_124_scaled = [value * 1.24 for value in WT_12dpi_124]
    WT_12dpi_042_scaled = [value * 0.42 for value in WT_12dpi_042]
    dpi12_WT_arbor = WT_12dpi_124_scaled + WT_12dpi_042_scaled

    WT_12dpi_124_raw = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR' and pix_to_um='1.24'")
    WT_12dpi_124 = [row[0] for row in WT_12dpi_124_raw]
    WT_12dpi_042_raw = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='WT' and condition='TR'and pix_to_um='0.42'")
    WT_12dpi_042 = [row[0] for row in WT_12dpi_042_raw]
    WT_12dpi_124_scaled = [value * 1.24 for value in WT_12dpi_124]
    WT_12dpi_042_scaled = [value * 0.42 for value in WT_12dpi_042]
    dpi12_WT_seglen = WT_12dpi_124_scaled + WT_12dpi_042_scaled
   
    dpi12_WT_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi'and genotype='WT' and condition='TR'")
    dpi12_WT_segnum = [row[0] for row in dpi12_WT_segnum]



    dpi03_FLX_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi'and genotype='FLX' and condition='TR'")
    dpi03_raw_values = [row[0] for row in dpi03_FLX_arbor]
    dpi03_FLX_arbor = [value * 0.42 for value in dpi03_raw_values]

    dpi03_FLX_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi'and genotype='FLX' and condition='TR'")
    dpi03_raw_values = [row[0] for row in dpi03_FLX_seglen]
    dpi03_FLX_seglen = [value * 0.42 for value in dpi03_raw_values]

    dpi03_FLX_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '03dpi'and genotype='FLX' and condition='TR'")
    dpi03_FLX_segnum = [row[0] for row in dpi03_FLX_segnum]


    dpi05_FLX_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi'and genotype='FLX' and condition='TR'")
    dpi05_raw_values = [row[0] for row in dpi05_FLX_arbor]
    dpi05_FLX_arbor = [value * 0.42 for value in dpi05_raw_values]
    
    dpi05_FLX_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi'and genotype='FLX' and condition='TR'")
    dpi05_raw_values = [row[0] for row in dpi05_FLX_seglen]
    dpi05_FLX_seglen = [value * 0.42 for value in dpi05_raw_values]

    dpi05_FLX_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '05dpi'and genotype='FLX' and condition='TR'")
    dpi05_FLX_segnum = [row[0] for row in dpi05_FLX_segnum]
    

    dpi07_FLX_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi'and genotype='FLX' and condition='TR'")
    dpi07_raw_values = [row[0] for row in dpi07_FLX_arbor]
    dpi07_FLX_arbor = [value * 0.42 for value in dpi07_raw_values]

    dpi07_FLX_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi'and genotype='FLX' and condition='TR'")
    dpi07_raw_values = [row[0] for row in dpi07_FLX_seglen]
    dpi07_FLX_seglen = [value * 0.42 for value in dpi07_raw_values]

    dpi07_FLX_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '07dpi'and genotype='FLX' and condition='TR'")
    dpi07_FLX_segnum = [row[0] for row in dpi07_FLX_segnum]


    dpi09_FLX_arbor = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi'and genotype='FLX' and condition='TR'")
    dpi09_raw_values = [row[0] for row in dpi09_FLX_arbor]
    dpi09_FLX_arbor = [value * 0.42 for value in dpi09_raw_values]

    dpi09_FLX_seglen = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi'and genotype='FLX' and condition='TR'")
    dpi09_raw_values = [row[0] for row in dpi09_FLX_seglen]
    dpi09_FLX_seglen = [value * 0.42 for value in dpi09_raw_values]

    dpi09_FLX_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '09dpi'and genotype='FLX' and condition='TR'")
    dpi09_FLX_segnum = [row[0] for row in dpi09_FLX_segnum]

    FLX_12dpi_124_raw = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR' and pix_to_um='1.24'")
    FLX_12dpi_124 = [row[0] for row in FLX_12dpi_124_raw]
    FLX_12dpi_042_raw = connection.execute(
        "select arbor_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'and pix_to_um='0.42'")
    FLX_12dpi_042 = [row[0] for row in FLX_12dpi_042_raw]
    FLX_12dpi_124_scaled = [value * 1.24 for value in FLX_12dpi_124]
    FLX_12dpi_042_scaled = [value * 0.42 for value in FLX_12dpi_042]
    dpi12_FLX_arbor = FLX_12dpi_124_scaled + FLX_12dpi_042_scaled

    FLX_12dpi_124_raw = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR' and pix_to_um='1.24'")
    FLX_12dpi_124 = [row[0] for row in FLX_12dpi_124_raw]
    FLX_12dpi_042_raw = connection.execute(
        "select mean_branch_length from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi' and genotype='FLX' and condition='TR'and pix_to_um='0.42'")
    FLX_12dpi_042 = [row[0] for row in FLX_12dpi_042_raw]
    FLX_12dpi_124_scaled = [value * 1.24 for value in FLX_12dpi_124]
    FLX_12dpi_042_scaled = [value * 0.42 for value in FLX_12dpi_042]
    dpi12_FLX_seglen = FLX_12dpi_124_scaled + FLX_12dpi_042_scaled

    dpi12_FLX_segnum = connection.execute(
        "select branch_number from RFTdt_Neurons left join RFTdt_Animals on rftdt_neurons.animal_id = rftdt_animals.animal_id where dpi = '12dpi'and genotype='FLX' and condition='TR'")
    dpi12_FLX_segnum = [row[0] for row in dpi12_FLX_segnum]

    return  dpi03_WT_arbor, dpi03_WT_seglen, dpi03_WT_segnum,dpi05_WT_arbor, dpi05_WT_seglen, dpi05_WT_segnum,dpi07_WT_arbor, dpi07_WT_seglen, dpi07_WT_segnum,dpi09_WT_arbor, dpi09_WT_seglen, dpi09_WT_segnum,dpi12_WT_arbor, dpi12_WT_seglen, dpi12_WT_segnum,\
            dpi03_FLX_arbor, dpi03_FLX_seglen, dpi03_FLX_segnum,dpi05_FLX_arbor, dpi05_FLX_seglen, dpi05_FLX_segnum,dpi07_FLX_arbor, dpi07_FLX_seglen, dpi07_FLX_segnum,dpi09_FLX_arbor, dpi09_FLX_seglen, dpi09_FLX_segnum,dpi12_FLX_arbor, dpi12_FLX_seglen, dpi12_FLX_segnum