import os
import xml.etree.ElementTree as ET
import glob
from scipy.spatial import distance
from scipy.spatial import ConvexHull
import numpy as np
import sqlite3

#connect to datebase where information on step size is stored in a cell-specific manner
connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')

#Start actual parsing operations
def annotation_finder(directory):
    os.chdir(directory)
    annotationfiles=glob.glob(directory + "\*.xml")
    # print annotationfiles
    return annotationfiles

def annotation_filename_getter(annotationfile):
    annot_neu_id = [annotationfile[87:99]]
    # print annot_neu_id
    return annot_neu_id

def annotation_parser (annotationfile):
    tree = ET.parse(annotationfile)
    root = tree.getroot()
    nodes = list(root.iter('node'))
    edges = list(root.iter('edge'))
    return nodes, edges

def step_size_corrector(id):

    #get the step size for each of the files as they are processed through
    #This allows for correct z spacing since the default is 1 unit (pixel) and actual step size was 1-2 um
    id_strip = id.strip('[]')
    database_info = connection.execute("select step from Steps where steps.neuron_id = "+id_strip+" ")
    step= [str(item[0]) for item in database_info]
    return step

def node_location_finder(nodes,edges,step):
    int_step = float(step[0])
    node_location_list = [[node.attrib['id'], node.attrib['x'], node.attrib['y'], node.attrib['z']]for node in nodes]
    #make it int() so that you can add in the step size to the z coordinate
    node_location_int = [[int(value) for value in node] for node in node_location_list]
    #add in the step size and make it back into a list (so that it plays well with the existing code)
    node_location = [[str(node[0]), str(node[1]), str(node[2]), str(node[3]+int_step)] for node in node_location_int]
    return node_location

def source_target(edges):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    source_target_dict = dict()


    for pair in combined_node_pairs:
        if pair[0] in source_target_dict:
            # append the new number to the existing array at this slot
            source_target_dict[pair[0]].append(pair[1])
        else:
            # create a new array in this slot
            source_target_dict[pair[0]] = [pair[1]]
    return source_target_dict

    # return source_target_dict.update(target_source_dict)

def path_finder(source_target_dict, start, end, path=[]):
    path = path + [start]
    # print path
    if start == end:
        return path
    if not source_target_dict.has_key(start):
        return None
    for node in source_target_dict[start]:
        if node not in path:
            newpath = path_finder(source_target_dict, node, end, path)
            if newpath: return newpath
    return None


#soma_size is biggest node
def soma_size(nodes,edges):
    radii_list=[node.attrib['radius'] for node in nodes]
    soma_diameter = max(radii_list)
    return soma_diameter


#tree_number is number of edges originating from the sources with the most edges (usually source '1')
def tree_number(nodes,edges):
    source_list = [edge.attrib['source'] for edge in edges]
    source_set = set(source_list)
    unique_sources=list(source_set)
    tree_count= max([source_list.count(source) for source in unique_sources])
    return tree_count

#branch_number is the count of duplicate sources
#NOTE: works regardless of directionality of path and how branch point is defined
def branch_number(nodes,edges):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    # print len(source_target_pairs)
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    # print len(target_source_pairs)
    combined_node_pairs = source_target_pairs + target_source_pairs
    # print combined_node_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    # print target_nodes
    source_nodes = [pair[1] for pair in combined_node_pairs]
    # print source_nodes
    combined_source_targets_flat = target_nodes + source_nodes
    # print combined_source_targets_flat
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)


    branch_node_count = [combined_source_targets_flat.count(node) if combined_source_targets_flat.count(node) > 5 else 0 for node in unique_nodes]
    branchpoint_number = sum([1 if node > 0 else 0 for node in branch_node_count])-1
    # print branchpoint_number
    # print branch_node_count
    connection_number_int = int(sum(branch_node_count))
    # print connection_number
    # print connection_number_int
    soma_connection_number = int(max(branch_node_count))
    # print soma_connection_number
    connections_soma_removed = connection_number_int-soma_connection_number
    # print connections_soma_removed
    tree_number = np.divide(soma_connection_number,2)
    # print tree_number
    non_soma_branches = np.divide(connections_soma_removed,2)-branchpoint_number
    branch_number = non_soma_branches + tree_number
    # print non_soma_branches

    return branch_number

#tip_number is the count of nodes/sources that have no targets
def tip_number(nodes,edges):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]

    return len(tip_list)

#path_length returns all the length of all paths for a neuron (path_lengths) and the average path length for a neuron (avg_path_length)
def path_length(source_target_dict, nodes, edges,step):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    # print combined_node_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    # print combined_source_targets_flat
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    # node_id_set= set(node_id_list)
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print tip_list
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    path_list = [path_finder(source_target_dict, soma_node, tip) for tip in tip_list]
    # print 'path list'
    # print path_list
    node_location = node_location_finder(nodes, edges,step)
    # print 'node location'
    # print node_location

    # print "matches"
    path_lengths_pix = []
    # print len(path_list)
    for path in range(0,len(path_list)):
        matches = [item for item in node_location if item[0] in path_list[path]]
        # print matches
        matches_nodes = [match[0] for match in matches]
        matches_index = [path_list[path].index(node) for node in matches_nodes]
        # print matches_index
        sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
        int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
        print sorted_matches
        # print int_matches

        interpoint_distance = 0
        for match in range(0,len(int_matches) - 1):
            interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4], int_matches[match + 1][1:4])

        path_lengths_pix.append(interpoint_distance)

    #apply correction for the pix/um conversion
    #microns per pixel are 0.649
    path_lengths = [(path*0.649) for path in path_lengths_pix]

    return path_lengths, np.mean(path_lengths)

#tortuosity is the ratio of the path_lengths to the euclidean distance between soma and path tip
def tortuosity(source_target_dict, nodes, edges,step):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)


    node_id_list= [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print tip_list
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    path_list = [path_finder(source_target_dict, soma_node, tip) for tip in tip_list]
    node_location = node_location_finder(nodes, edges,step)

    path_lengths = []
    soma_to_tip = []
    for path in range(0,len(path_list)):
        matches = [item for item in node_location if item[0] in path_list[path]]
        # print matches
        matches_nodes = [match[0] for match in matches]
        matches_index = [path_list[path].index(node) for node in matches_nodes]
        # print matches_index
        sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
        int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
        # print int_matches

        interpoint_distance = 0
        for match in range(0,len(int_matches) - 1):
            interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4], int_matches[match + 1][1:4])

        euc_distance = distance.euclidean(int_matches[0][1:4], int_matches[-1][1:4])
        #There is no (known) good reason that you have to use 1:4. by any indication it should be 1:3 but it IS NOT. DO NOT CHANGE IT
        # print int_matches[0][1:4]
        # print int_matches[-1][1:4]

        path_lengths.append(interpoint_distance)
        soma_to_tip.append(euc_distance)
        # print path_lengths
        # print soma_to_tip
    # print int_reordered_matches
    return np.divide(path_lengths, soma_to_tip), np.mean(np.divide(path_lengths, soma_to_tip))

#segment_length is the length of all segments (otherwise known as branches) returns all segment lengths and avg. segment length
def segment_length (source_target_dict, nodes, edges,step):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    # print branch_node_list
    # print 'len(branch_node_list)'
    # print len(branch_node_list)


    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print tip_list

    branch_node_tips = branch_node_list + tip_list

    segment_list = [path_finder(source_target_dict, node2, node)for node2 in branch_node_tips for node in branch_node_tips]
    segment_list = [segment for segment in segment_list if segment is not None]
    segment_list = [segment for segment in segment_list if len(segment) >1 ]
    # print segment_list
    # print len(segment_list)

    unique_segment_list1 = []
    for segment in segment_list:
        # print segment
        branch_node_tip_found = 0
        for node in branch_node_tips:
            if node in segment[1:-1]:
                branch_node_tip_found=1
        if branch_node_tip_found ==0:
            unique_segment_list1.append(segment)

    #
   # print unique_segment_list1
    unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
    unique_segment_list = [list(item) for item in unique_segment_list]
    # print len(unique_segment_list)

    real_segments = []
    for match in unique_segment_list:
        segment_found = 0
        for segment in unique_segment_list1:
            if segment_found == 0:
                segment_set = set(segment)
                match_set = set(match)
                if segment_set == match_set:
                    real_segments.append(segment)
                    segment_found = 1
    unique_segment_list = real_segments

    node_location = node_location_finder(nodes, edges,step)
    segment_lengths_pix = []
    for segment in range(0, len(unique_segment_list)):
        matches = [item for item in node_location if item[0] in unique_segment_list[segment]]
        # print matches
        if matches == []:
            segment_lengths_pix.append(0)
        else:
            matches_nodes = [match[0] for match in matches]
            matches_index = [unique_segment_list[segment].index(node) for node in matches_nodes]
            sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
            int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
            # print sorted_matches


            interpoint_distance = 0
            for match in range(0, len(int_matches) - 1):
                interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4], int_matches[match + 1][1:4])
            # print int_matches[match][1:4]
            segment_lengths_pix.append(interpoint_distance)

    segment_lengths_pix=set(segment_lengths_pix)
    # print segment_lengths
    # print len(segment_lengths)
    segment_lengths_pix=list(segment_lengths_pix)

    # apply correction for the pix/um conversion
    # microns per pixel are 0.649
    segment_lengths = [(path * 0.649) for path in segment_lengths_pix]

    return segment_lengths, np.mean(segment_lengths)


#arbor_length is the length of all segments added together
def arbor_length (source_target_dict, nodes, edges,step):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    # print branch_node_list


    # node_id_list= [node.attrib['id'] for node in nodes]
    # node_id_set= set(node_id_list)
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print tip_list

    branch_node_tips = branch_node_list + tip_list

    segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in
                    branch_node_tips]
    segment_list = [segment for segment in segment_list if segment is not None]
    segment_list = [segment for segment in segment_list if len(segment) > 1]
    # print segment_list
    # print len(segment_list)

    unique_segment_list1 = []
    for segment in segment_list:
        # print segment
        branch_node_tip_found = 0
        for node in branch_node_tips:
            if node in segment[1:-1]:
                branch_node_tip_found = 1
        if branch_node_tip_found == 0:
            unique_segment_list1.append(segment)
    # print unique_segment_list
    #
    unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
    unique_segment_list = [list(item) for item in unique_segment_list]

    real_segments = []
    for match in unique_segment_list:
        segment_found = 0
        for segment in unique_segment_list1:
            if segment_found == 0:
                segment_set = set(segment)
                match_set = set(match)
                if segment_set == match_set:
                    real_segments.append(segment)
                    segment_found = 1
    unique_segment_list = real_segments


    node_location = node_location_finder(nodes, edges,step)
    segment_lengths_pix = []
    for segment in range(0, len(unique_segment_list)):
        matches = [item for item in node_location if item[0] in unique_segment_list[segment]]
        if matches == []:
            segment_lengths_pix.append(0)
        else:
            matches_nodes = [match[0] for match in matches]
            matches_index = [unique_segment_list[segment].index(node) for node in matches_nodes]
            # print matches_index
            sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
            int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
            # print int_matches
            # pri print int_matches


            interpoint_distance = 0
            for match in range(0, len(int_matches) - 1):
                interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4], int_matches[match + 1][1:4])
                # print int_matches[match][1:4]

            segment_lengths_pix.append(interpoint_distance)

    segment_lengths_pix = set(segment_lengths_pix)
    segment_lengths_pix = list(segment_lengths_pix)

    # apply correction for the pix/um conversion
    # microns per pixel are 0.649
    segment_lengths = [(path * 0.649) for path in segment_lengths_pix]

    print segment_lengths
    return sum(segment_lengths)
#
# #Volume gives the 3D volume of space that each arbor fills within the tissue. It's a measure of how the cells
# #tile the cortical space in 3D
def volume(nodes, edges,step):
    int_step = float(step[0])
    node_location_list = [[node.attrib['id'], node.attrib['x'], node.attrib['y'], node.attrib['z']] for node in nodes]
    # make it int() so that you can add in the step size to the z coordinate
    node_location_int = [[int(value) for value in node] for node in node_location_list]
    # add in the step size and make it back into a list (so that it plays well with the existing code)
    node_locations = [[str(node[0]), str(node[1]), str(node[2]), str(node[3] + int_step)] for node in node_location_int]
    hull = ConvexHull(node_locations)
    area_pix = hull.area

    #apply pix/um conversion value of 0.649um per pix
    area = (area_pix*(0.649*0.649))
    volume = ((hull.volume)*(0.649*0.649*0.649))
    print volume
    print type(volume)

    # print node_locations
    # print area
    return volume

def density(source_target_dict, nodes, edges,step):
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
    # print branch_node_list


    # node_id_list= [node.attrib['id'] for node in nodes]
    # node_id_set= set(node_id_list)
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print tip_list

    branch_node_tips = branch_node_list + tip_list

    segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in
                    branch_node_tips]
    segment_list = [segment for segment in segment_list if segment is not None]
    segment_list = [segment for segment in segment_list if len(segment) > 1]
    # print segment_list
    # print len(segment_list)

    unique_segment_list1 = []
    for segment in segment_list:
        # print segment
        branch_node_tip_found = 0
        for node in branch_node_tips:
            if node in segment[1:-1]:
                branch_node_tip_found = 1
        if branch_node_tip_found == 0:
            unique_segment_list1.append(segment)
    # print unique_segment_list
    #
    unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
    unique_segment_list = [list(item) for item in unique_segment_list]

    real_segments = []
    for match in unique_segment_list:
        segment_found = 0
        for segment in unique_segment_list1:
            if segment_found == 0:
                segment_set = set(segment)
                match_set = set(match)
                if segment_set == match_set:
                    real_segments.append(segment)
                    segment_found = 1
    unique_segment_list = real_segments

    node_location = node_location_finder(nodes, edges,step)
    segment_lengths = []
    for segment in range(0, len(unique_segment_list)):
        matches = [item for item in node_location if item[0] in unique_segment_list[segment]]
        if matches == []:
            segment_lengths.append(0)
        else:
            matches_nodes = [match[0] for match in matches]
            matches_index = [unique_segment_list[segment].index(node) for node in matches_nodes]
            # print matches_index
            sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
            int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
            # print int_matches
            # pri print int_matches


            interpoint_distance = 0
            for match in range(0, len(int_matches) - 1):
                interpoint_distance = interpoint_distance + distance.euclidean(int_matches[match][1:4],
                                                                               int_matches[match + 1][1:4])
                # print int_matches[match][1:4]

            segment_lengths.append(interpoint_distance)

    segment_lengths = set(segment_lengths)
    segment_lengths = list(segment_lengths)
    #calucluate arbor length and correct by um per pixel conversion of 0.649 um per pixel
    arbor_length = (sum(segment_lengths))*0.649

    int_step = float(step[0])
    node_location_list = [[node.attrib['id'], node.attrib['x'], node.attrib['y'], node.attrib['z']] for node in nodes]
    # make it int() so that you can add in the step size to the z coordinate
    node_location_int = [[int(value) for value in node] for node in node_location_list]
    # add in the step size and make it back into a list (so that it plays well with the existing code)
    node_locations = [[str(node[0]), str(node[1]), str(node[2]), str(node[3] + int_step)] for node in node_location_int]
    hull = ConvexHull(node_locations)
    volume = (hull.volume)*(0.649*0.649*0.649)

    density = (arbor_length/volume)

    # print density
    return density



#Sholl gives the number of intersections at given distances from the soma. Distances can be chosen as desired
def sholl(source_target_dict, nodes, edges,step):
   #This stuff is a direct copy from branch_lengths. All is necessary for Sholl, but we want it to be independent
   source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
   target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
   combined_node_pairs = source_target_pairs + target_source_pairs
   target_nodes = [pair[0] for pair in combined_node_pairs]
   source_nodes = [pair[1] for pair in combined_node_pairs]
   combined_source_targets_flat = target_nodes + source_nodes
   unique_nodes_set = set(combined_source_targets_flat)
   unique_nodes = list(unique_nodes_set)

   branch_node_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) > 5]
   # print branch_node_list

   tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
   # print tip_list

   branch_node_tips = branch_node_list + tip_list

   segment_list = [path_finder(source_target_dict, node2, node) for node2 in branch_node_tips for node in
                   branch_node_tips]
   segment_list = [segment for segment in segment_list if segment is not None]
   segment_list = [segment for segment in segment_list if len(segment) > 1]
   # print segment_list
   # print len(segment_list)

   unique_segment_list1 = []
   for segment in segment_list:
       # print segment
       branch_node_tip_found = 0
       for node in branch_node_tips:
           if node in segment[1:-1]:
               branch_node_tip_found = 1
       if branch_node_tip_found == 0:
           unique_segment_list1.append(segment)

   unique_segment_list = set(frozenset(item) for item in unique_segment_list1)
   unique_segment_list = [list(item) for item in unique_segment_list]

   real_segments = []
   for match in unique_segment_list:
       segment_found = 0
       for segment in unique_segment_list1:
           if segment_found == 0:
               segment_set = set(segment)
               match_set = set(match)
               if segment_set == match_set:
                   real_segments.append(segment)
                   segment_found = 1
   unique_segment_list = real_segments


   node_location = node_location_finder(nodes, edges,step)
   node_id_list = [node.attrib['id'] for node in nodes]
   radii_list = [node.attrib['radius'] for node in nodes]
   soma_node = str((node_id_list[radii_list.index(max(radii_list))]))
   soma_node_index = radii_list.index(max(radii_list))
   soma_coords = node_location[soma_node_index]
   # print soma_coords
   soma_coords = [float(node) for node in soma_coords]

   soma_to_node_distances = []
   for segment in range(0, len(unique_segment_list)):
       matches = [item for item in node_location if item[0] in unique_segment_list[segment]]
       if matches == []:
           soma_to_node_distances.append(0)
       else:
           matches_nodes = [match[0] for match in matches]
           matches_index = [unique_segment_list[segment].index(node) for node in matches_nodes]
           # print matches_index
           sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
           int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
           # print int_matches
           int_matches = [[float(coordinate) for coordinate in match] for match in matches]
   #distance from soma to each node in each pair of nodes
       for match in range(0, len(int_matches) - 1):
           soma_to_node_pairs = []
           soma_to_node_pairs.append(distance.euclidean(soma_coords[1:4], int_matches[match][1:4]))
           soma_to_node_pairs.append(distance.euclidean(soma_coords[1:4],int_matches[match + 1][1:4]))
           soma_to_node_distances.append(soma_to_node_pairs)
    # return soma_to_node_distances
   # print len(soma_to_node_distances)
#Start original material here
# This bit specifies the radius of the "sholl circle" at which we're counting. We're starting with 0-300 in 10 pix steps
   radii_list = range(0,500,10)
   # print len(radii_list)
   sholl_intersections=[]
   for radius in radii_list:
       crosses = 0
       for pair in soma_to_node_distances:
           # print len(soma_to_node_distances)
           if sum([1 if radius - node_distance >= 0 else 0 for node_distance in pair]) == 1:
               crosses = crosses + 1
       sholl_intersections.append(crosses)
        # print crosses
   return list(np.divide(sholl_intersections,2))

def intersections(source_target_dict, nodes, edges,step):
#Start off using reused code from the path length function to get all the paths, connected nodes, etc.
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    # print combined_node_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    # print combined_source_targets_flat
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    # node_id_set= set(node_id_list)
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print tip_list
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    path_list = [path_finder(source_target_dict, soma_node, tip) for tip in tip_list]
    # print 'path list'
    # print path_list
    node_location = node_location_finder(nodes, edges,step)
    # print 'node location'
    # print node_location

#Find the connected pairs of nodes in each path
    node_subseg_pairs = []
    for path in path_list:
        for v, w in zip(path[:-1], path[1:]):
            node_subseg_pairs.append((v,w))
    #Get only the unique pairs
    unique_node_subseg_pairs = list(set(node_subseg_pairs))

# Get the coordinates for each of the nodes as add those to the existing unique node pairs list. Also string -> int
    unique_subseg_coords = []
    for pair in range(0, len(unique_node_subseg_pairs)):
        matches = [item for item in node_location if item[0] in unique_node_subseg_pairs[pair]]
        # print matches
        int_matches = [[float(coordinate) for coordinate in match] for match in matches]
        # print sorted_matches
        # print int_matches
        unique_subseg_coords.append(matches)
    # print unique_subseg_coords

#Loop through the whole list of unique pairs, comparing each to each. to determine whether they intersect.
#Gather the necessary coordinates. In all cases, coords (X,Y) will be designated Pair Number followed by Point Number
#Such that the coords from the first point in the first pair are (x11,y11) and from the second point are (x12,y12)
    intersection_list = []
    x_ints = []
    y_ints = []
    id_list = []
    id2_list = []
    for pair in unique_subseg_coords:
        x = [coord[1] for coord in pair]
        y = [coord[2] for coord in pair]
        id = [coord[0] for coord in pair]
        x11 = float(x[0])
        x12 = float(x[1])
        y11 = float(y[0])
        y12 = float(y[1])
        for pair in unique_subseg_coords:
            x2 = [coord[1] for coord in pair]
            id2 = [coord[0] for coord in pair]
            y2 = [coord[2] for coord in pair]
            x21 = float(x2[0])
            x22 = float(x2[1])
            y21 = float(y2[0])
            y22 = float(y2[1])
            colinearity_calc = float(((x11 * (y12 - y21)) + (x12 * (y21 - y11)) + (x21 * (y11 - y12))) + ((x11 * (y12 - y22)) + (x12 * (y22 - y11)) + (x22 * (y11 - y12))))
            # print colinearity_calc
            if colinearity_calc != 0.0:
                #If points are not colinear, find the linear equation of the line and proceed to find any intersections
                #Linear equation (aX + By = C) is solved as (y11-y12)X + (x12-x11)Y = -(x11y12-x12y11)
                #For Line 1
                a1 = float(y11-y12)
                b1 = float(x12-x11)
                c1 = -float(x11*y12 - x12*y11)
                # print a1
                # print b1
                # print c1

                #Same as above, for Line 2
                a2 = float(y21-y22)
                b2 = float(x22-x21)
                c2 = -float(x21*y22 - x22*y21)
                # print a2
                # print b2
                # print c2

                #Now solve for the X coord of intersection by multiplying Line 1 by b2 and Line 2 by b1 and subtracting them
                #The eqs resulting from the multiplication would be:
                #### 1)  a1b2X + b1b2Y = c1b2
                #### 2)  a2b1X + b2b1Y = c2b1
                # The subtraction results in (a1b2 - a2b1)X = c1b2-c2b1 and we solve from here
                x_int = np.divide(float(c1*b2 - c2*b1),float(a1*b2 - a2*b1))
                # print x_int
                #Now solve for the Y coord of the intersection by mulitplying Line 1 by a2 and line 2 by a1 and continuing as above
                # The eqs resulting from the multiplication would be:
                #### 1)  a1a2X + b1a2Y = c1a2
                #### 2)  a2a1X + b2a1Y = c2a1
                # The subtraction results in (b1a2 - b2a1)Y = c1a2 - c2a1 and we solve from here
                y_int = np.divide(float(c1*a2 - c2*a1),float(b1*a2 - b2*a1))

                #Now check that the intersection occurs within the bounds of the segment (i.e. not somewhere on an infinitely long line)
                min_x = float(min(x11,x12))
                max_x = float(max(x11,x12))
                min_x2 = float(min(x21,x22))
                max_x2 = float(max(x21,x22))
                min_y = float(min(y11,y12))
                max_y = float(max(y11,y12))
                min_y2 = float(min(y21, y22))
                max_y2 = float(max(y21, y22))

                if min_x < x_int < max_x and min_y < y_int < max_y and min_x2 < x_int < max_x2 and min_y2 < y_int < max_y2 :
                    # id_list.append(id)
                    # id2_list.append(id2)
                    x_ints.append(x_int)
                    y_ints.append(y_int)

    branch_node_count = [combined_source_targets_flat.count(node) if combined_source_targets_flat.count(node) > 5 else 0 for node in unique_nodes]
    branchpoint_number = sum([1 if node > 0 else 0 for node in branch_node_count])-1
    connection_number_int = int(sum(branch_node_count))
    soma_connection_number = int(max(branch_node_count))
    connections_soma_removed = connection_number_int-soma_connection_number
    tree_number = np.divide(soma_connection_number,2)
    non_soma_branches = np.divide(connections_soma_removed,2)-branchpoint_number
    branch_number = non_soma_branches + tree_number
    print branch_number
    norm_intersections = np.divide(len(set(zip(x_ints,y_ints))),float(branch_number))

    return len(set(zip(x_ints,y_ints))),norm_intersections



#### The following code finds the convex hull created by each path and then computes the overlap of that convex
#### polygon with each of the other paths' polygons. This gives a measure of "fasiculation" or close proximity of
#### paths within the arbor. Method based on Sutherland-Hodgeman Algorithm
#### Hypothesis: Rem2 KO cells have greater path proximity
def hull_overlap(source_target_dict,nodes, edges,step):

    ##Start by doing all the pre-processing stuff, like getting nodes, edges, etc
    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    # print combined_node_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    # print combined_source_targets_flat
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes = list(unique_nodes_set)

    ## Get the node locations
    node_id_list = [node.attrib['id'] for node in nodes]
    # node_id_set= set(node_id_list)
    tip_list = [node for node in unique_nodes if combined_source_targets_flat.count(node) == 2]
    # print tip_list
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    path_list = [path_finder(source_target_dict, soma_node, tip) for tip in tip_list]
    # print 'path list'
    # print path_list
    node_location = node_location_finder(nodes, edges, step)
    # print 'node location'
    # print node_location
    # print node_location

    ##Get path nodes and locations, the make them integers for easy math
    paths = []
    # print len(path_list)
    for path in range(0,len(path_list)):
        matches = [item for item in node_location if item[0] in path_list[path]]
        # print matches
        matches_nodes = [match[0] for match in matches]
        matches_index = [path_list[path].index(node) for node in matches_nodes]
        # print matches_index
        sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
        int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
        paths.append(int_matches)
        # print int_matches
    # print paths
    #get just the coordinates (drop the id) for each node in each path in preparation to make convex hulls
    paths_coords_only = [[coord[1:3] for coord in path]for path in paths]
    # print paths_coords_only
    # print len(paths_coords_only)
    path_lengths = [len(path) for path in paths_coords_only]
    # print path_lengths
    ## Get the vertices of the convex hull for each path. If there is a issue with it being co-planar (unable to make
    ## a convex hull) discard that path and continue the loop.
    vertex_indices = []
    for path in paths_coords_only:
        path_hull = ConvexHull(path)
        #verticies gives the index of the points making up the hull in counterclockwise order in a list
        vertices = list(path_hull.vertices)
        vertex_indices.append(vertices)


    vertex_indices = [[int(item) for item in vertex] for vertex in vertex_indices]
    # print vertex_indices
    # print len(vertex_indices)
    paths_and_vert = zip(paths_coords_only, vertex_indices)
    # print paths_and_vert
    ##Get the points and coords that make up each hull using the indices that are returned in vertices
    vertex_locations = []
    for pair in paths_and_vert:
        pair1=pair[0]
        coords = [pair1[i] for i in pair[1]]
        vertex_locations.append(coords)
    # print vertex_locations

    line_coords = []
    for hull in vertex_locations:
        offset_coords = hull[1:len(hull)] + [hull[0]]
        combined = zip(hull,offset_coords)
        line_coords.append(combined)
        # print offset_coords
        # print line_coords

    import matplotlib.pyplot as plot;plot.rcdefaults()

    fig, axs = plot.subplots(nrows=1, ncols=1, sharex=False, sharey='row')

    # Plot WT Dev Graph
    ax = axs

    for item in vertex_locations:
        print item
        for coord in item:
            x_coord = [coord[0] for coord in item]
            print x_coord
            y_coord = [coord[1] for coord in item]
            ax.plot(x_coord, y_coord,label='thing1')
    plot.legend()
    plot.show()
    # # hull = ConvexHull(node_locations)
    # # area_pix = hull.area
    #
    # #apply pix/um conversion value of 0.649um per pix
    # # area = (area_pix*0.649)
    #
    # print node_locations
    # # print area
    # return int(area)