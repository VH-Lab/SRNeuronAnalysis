SRNeuronAnalysis
================

Introduction
------------
SRNeuronAnalysis is an analysis package designed to work with existing free software for anatomical annotation to
provide users with a completely free reconstruction and analysis platform for any cell type that can be represented as
a branched node structure. The analyses can be divided up by whether they are cell-centric (having to do with invidivial
dendritic arbors belonging to one cells) and tissue-centric measures (having to do with how an arbor fills space or is
oriented compared to a larger tissue). Measures also differ by their fundamental unit of measurement - either 'segments'
or 'paths.' Segments are the smallest units of the dendritic arbor and can be conceptualized as the span of dendrite
between two branch points, between the soma and the first branch point or between a branch point and the terminal tip of
the dendrite. Paths are an intermediate-sized assembly that consist of one or more segments and span the distance from
the soma to the tip of a dendrite. Paths can be conceptualized as the distance a current originating at the tip or a
dendrite would travel to reach the soma. A second suite of analyses uses these same basic principles to specifically
analyze "dendritic trees," the portion of each arbor arising from a shared primary neurite. Along with these measures,
SRNeuronAnalysis also includes several data visualization tools. Please see Richards et al. 2019 (DOI: ####) for more
information as well as a demonstration of the package's capabilities.

Prerequisites
-------------

1) Annotation Software - SRNeuronAnalysis does not make reconstructions nor provide an interface form making dendrite
   reconstrcutions. We suggest using Knossos (url here), since SRNeuronAnalysis was particularly designed to work with
   annotations from this program and Knossos is available for download free of cost. Any program that provides (X,Y,Z)
   coordinates for nodes and associated edges can be used, but may require significant tweaking of the code.

2) Knossos Cuber (if using Knossos) - Python code freely available from the makers of Knossos that converts folders of
   8-bit images into stacks in a Knossos-compatible format for reconstruction. This is not necessary if you will not be
   using Knossos

3) Python Packages - There are several packages that are used extensively throughout the code or with Knossos Cuber.
    a) Numpy
    b) Scipy
    c) Pillow
    d) Pandas
    e) Stats
    f) Matplotlib
    g) Squlite3

Getting Started
---------------

1) Collect all .xml files for reconstuctions in a central location. You will need to direct the code to this directory
   any time you'd like to add more annotiations to your database, so make it somewhere that is easy to access.

2) Make a .csv describing the dataset you will be using. The code currently expects animal identifiers, age, condition,
   genotype, sex, and number of cells in columns with each animal having a designated row. These fields can be easily
   changed by editing Animal_Database.py

3) Make an animal information table. In Animal_Database.py, edit line 17 and 27 to reflect the location and file name of
   your .csv that has been created in step 2. Edit line 2 to reflect the path where your database is stored. You will
   not need to input any additional info.

4) Make a table containing analyss of each neuron. Edit Neuron_Calc_Database line 5 to reflect the path where your
   database is stored. Run Neuron_Calc_Database. You will be promted to enter the path where your .xml reconstructions
   are stored. You will not need to input any additional info.

5) Use infomation you have sotred in your tables. After the Neuron and Animal tables have been created, you are ready to
   access you data. Consider visualizing your data with one of the several data visualization tools included with
   SRNeuronAnalysis. Data can easily be accessed in any SQULIte-compatible environment.

Example:

---Experiment_Folder
    |
     ----- Animal01_Cell01.xml
     ----- Animal01_Cell02.xml
     ----- ...


---Animal_Folder
    |
     ----- Animal_Info_File.csv



Animal_Database.py

import sqlite3
connection=sqlite3.connect('C:\Users\You\PycharmProjects\SRNeuronAnalysis\Database_Name.db')
#cursor = connection.execute("select * from Animals")
#for row in cursor:
#    print row
#cursor = connection.execute("select animals.animal_id,genotype, age, sex, condition, avg(branch_number) from Neurons left join Animals on neurons.animal_id = animals.animal_id where age = 'P16' group by genotype, condition, sex")
# cursor = connection.execute("select * from Neurons left join Animals on neurons.animal_id = animals.animal_id where age='P16' group by animal_id, genotype, condition, sex")
#for row in cursor:
#    print row


# connection.execute('drop table Animals')
 connection.execute('''create table Animals(animal_id text primary key, age text, condition text, genotype text,
    sex text, number_of_cells text);''')

 import os
 os.chdir("C:\Users\You\Animal_Folder\Animal_Info_File.csb")
 import csv

 animal_id=[]
 age=[]
 condition=[]
 genotype=[]
 sex=[]
 number_of_cells=[]

 with open('Animal_Info_File.csv','rb') as csvfile:
     animal_info = csv.reader(csvfile, delimiter= ',')
     for row in animal_info:
         animal_id.append(row[0])
         age.append(row[1])
         condition.append(row[2])
         genotype.append(row[3])
         sex.append(row[4])
         number_of_cells.append(row[5])

 for index,animal in enumerate(animal_id):
     connection.execute("insert into Animals (animal_id, age, condition, genotype, sex, number_of_cells) values(?,?,?,?,?,?);",(animal_id[index], age[index], condition[index], genotype[index], sex[index], number_of_cells[index]))

 connection.commit()

>> Run Animal_Database.py



Neuron_Calc_Database.py

import os
import sqlite3
import AnnotationReaderXML

connection=sqlite3.connect('C:\Users\You\PycharmProjects\SRNeuronAnalysis\Database_Name.db')
# cursor = connection.execute("select * from Neurons")
# # for row in cursor:
# #     print row
# # cursor = connection.execute("select * from Neurons")
# # cursor = connection.execute("select avg(soma_radius) from Neurons")
# #
# #
# for row in cursor:
#      # print row
#      print 'animal_id', row[0]
#      print 'neuron_id =', row[1]
#      # print 'soma_size =', row[2]
#      # print 'tree_number=', row[3]
#      print 'arbor_length', row[10]
#      print 'branch_number', row [6]
#      # # print 'mean_branch_number=', row[5]
#      # print 'branch_lengths',row[6]
#      # print 'mean_branch_length',row[5]
#      # print 'volume', row[14]
#      # print 'density', row[15]

#connection.execute('drop table Neurons')
# # # # #connection.execute('''create table Neurons(animal_id text, neuron_id text primary key,soma_radius real,tree_number int, mean_branch_length real, branch_lengths text, branch_number int, path_lengths text, mean_path_length real,tip_number int);''')
connection.execute('''create table Neurons(animal_id text, neuron_id text primary key,soma_radius real, primary_arbor_number int, mean_segment_length real, segment_lengths text,
    segment_number int, path_lengths text, mean_path_length real, tip_number int, arbor_length real, tortuosity text, mean_tortuosity real, volume int, density real, sholl text, intersections int, norm_intersections real);''')

file_location = raw_input("Input data path.")
os.chdir(file_location)
annotation_files = AnnotationReaderXML.annotation_finder(file_location)

for annotation_file in annotation_files:

    nodes,edges = AnnotationReaderXML.annotation_parser(annotation_file)
    source_target_dict = AnnotationReaderXML.source_target(edges)

    id = str(AnnotationReaderXML.annotation_filename_getter(annotation_file))
    print id

    step = AnnotationReaderXML.step_size_corrector(id)
    print step

    animal_id = annotation_file[-29:-23]
    print animal_id

    neuron_id = annotation_file[-29:-16]
    print neuron_id
    soma_radius = AnnotationReaderXML.soma_size(nodes,edges)

    primary_arbor_num = AnnotationReaderXML.primary_arbor_number(nodes,edges)

    segment_num = AnnotationReaderXML.segment_number(nodes,edges)

    tip_num = AnnotationReaderXML.tip_number(nodes,edges)

    segment_lengths, mean_segment_length = AnnotationReaderXML.segment_length(source_target_dict, nodes, edges,step)
    segment_lengths = str(segment_lengths).strip('[]')

    arbor_length = AnnotationReaderXML.arbor_length(source_target_dict, nodes, edges,step)

    path_lengths, mean_path_length = AnnotationReaderXML.path_length(source_target_dict, nodes, edges,step)
    path_lengths = str(path_lengths).strip('[]')
    mean_path_length = mean_path_length


    tortuosity, mean_tortuosity = AnnotationReaderXML.tortuosity(source_target_dict, nodes, edges,step)
    tortuosity = str(tortuosity).strip('[]')


    volume = AnnotationReaderXML.volume(nodes, edges,step)

    density = AnnotationReaderXML.density(source_target_dict, nodes, edges,step)

    sholl = AnnotationReaderXML.sholl(source_target_dict, nodes, edges,step)
    sholl = str(sholl).strip('[]')

    intersections,norm_intersections = AnnotationReaderXML.intersections(source_target_dict, nodes, edges,step)
    intersections = str(intersections).strip('[]')
    norm_intersections = norm_intersections

    #connection.execute("insert into Neurons (animal_id,neuron_id,soma_radius,tree_number,mean_branch_length,branch_lengths, branch_number, path_lengths,mean_path_length, tip_number,volume,density) values(?,?,?,?,?,?,?,?,?,?,?,?);",(animal_id,neuron_id,soma_radius, tree_num,mean_branch_length,branch_lengths, branch_num, path_lengths, mean_path_length,tip_num,volume,density))
    connection.execute("insert into Neurons (animal_id,neuron_id,soma_radius, primary_arbor_number, mean_segment_length, segment_lengths, segment_number, path_lengths, mean_path_length, tip_number, arbor_length, tortuosity, mean_tortuosity, volume, density, sholl, intersections, norm_intersections) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);",(animal_id,neuron_id,soma_radius, tree_num, mean_branch_length, branch_lengths, branch_num, path_lengths, mean_path_length, tip_num, arbor_length, tortuosity, mean_tortuosity, volume, density, sholl, intersections,norm_intersections))

connection.commit()

>>Run Neuron_Calc_Database.py
>>Input data path.
>>C:\Users\You\Experiment_Folder