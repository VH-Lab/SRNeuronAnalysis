### Test code to calculate the fraction development stats for Steve ###
import numpy as np
import math
import matplotlib.pyplot as plot;plot.rcdefaults()
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *


from Database_Queries import growth_components
P12_Age1_arbor, P12_Age1_seglen, P12_Age1_segnum, P12_Age2_arbor, P12_Age2_seglen, P12_Age2_segnum = growth_components('P7','P12')
P16_Age1_arbor, P16_Age1_seglen, P16_Age1_segnum, P16_Age2_arbor, P16_Age2_seglen, P16_Age2_segnum = growth_components('P7','P16')
P21_Age1_arbor, P21_Age1_seglen, P21_Age1_segnum, P21_Age2_arbor, P21_Age2_seglen, P21_Age2_segnum = growth_components('P7','P21')
P30_Age1_arbor, P30_Age1_seglen, P30_Age1_segnum, P30_Age2_arbor, P30_Age2_seglen, P30_Age2_segnum = growth_components('P7','P30')
# print len(Age1_arbor)
# print len(Age2_arbor)
# print Age2_seglen
# print Age2_segnum

P12_Age1_values = zip(P12_Age1_arbor,P12_Age1_seglen,P12_Age1_segnum)
P16_Age1_values = zip(P16_Age1_arbor,P16_Age1_seglen,P16_Age1_segnum)
P21_Age1_values = zip(P21_Age1_arbor,P21_Age1_seglen,P21_Age1_segnum)
P30_Age1_values = zip(P30_Age1_arbor,P30_Age1_seglen,P30_Age1_segnum)
# print Age1_values

P12_deltaArbor = []
P12_deltaSegNum =[]
P12_deltaSegLen =[]
P12_Len_value = []
P12_Num_value = []
P12_LenNum_value =[]

for value in P12_Age1_values:
    delta_A = [arbor-value[0] for arbor in P12_Age2_arbor]
    delta_L = [seglen-value[1] for seglen in P12_Age2_seglen]
    delta_N = [segnum - value[2] for segnum in P12_Age2_segnum]
    P12_deltaArbor.append(delta_A)
    P12_deltaSegNum.append(delta_N)
    P12_deltaSegLen.append(delta_L)
    len_v = [(seglen-value[1]) * value[2] for seglen in P12_Age2_seglen]
    P12_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in P12_Age2_segnum]
    P12_Num_value.append(num_v)

    len_num_zip = zip(delta_L,delta_N)
    len_num_v = [item[0]* item[1] for item in len_num_zip]
    P12_LenNum_value.append(len_num_v)

P16_deltaArbor = []
P16_deltaSegNum =[]
P16_deltaSegLen =[]
P16_Len_value = []
P16_Num_value = []
P16_LenNum_value =[]

for value in P16_Age1_values:
    delta_A = [arbor-value[0] for arbor in P16_Age2_arbor]
    delta_L = [seglen-value[1] for seglen in P16_Age2_seglen]
    delta_N = [segnum - value[2] for segnum in P16_Age2_segnum]
    P16_deltaArbor.append(delta_A)
    P16_deltaSegNum.append(delta_N)
    P16_deltaSegLen.append(delta_L)
    len_v = [(seglen-value[1]) * value[2] for seglen in P16_Age2_seglen]
    P16_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in P16_Age2_segnum]
    P16_Num_value.append(num_v)

    len_num_zip = zip(delta_L,delta_N)
    len_num_v = [item[0]* item[1] for item in len_num_zip]
    P16_LenNum_value.append(len_num_v)

P21_deltaArbor = []
P21_deltaSegNum = []
P21_deltaSegLen = []
P21_Len_value = []
P21_Num_value = []
P21_LenNum_value = []

for value in P21_Age1_values:
    delta_A = [arbor - value[0] for arbor in P21_Age2_arbor]
    delta_L = [seglen - value[1] for seglen in P21_Age2_seglen]
    delta_N = [segnum - value[2] for segnum in P21_Age2_segnum]
    P21_deltaArbor.append(delta_A)
    P21_deltaSegNum.append(delta_N)
    P21_deltaSegLen.append(delta_L)
    len_v = [(seglen - value[1]) * value[2] for seglen in P21_Age2_seglen]
    P21_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in P21_Age2_segnum]
    P21_Num_value.append(num_v)

    len_num_zip = zip(delta_L, delta_N)
    len_num_v = [item[0] * item[1] for item in len_num_zip]
    P21_LenNum_value.append(len_num_v)

P30_deltaArbor = []
P30_deltaSegNum =[]
P30_deltaSegLen =[]
P30_Len_value = []
P30_Num_value = []
P30_LenNum_value =[]

for value in P30_Age1_values:
    delta_A = [arbor-value[0] for arbor in P30_Age2_arbor]
    delta_L = [seglen-value[1] for seglen in P30_Age2_seglen]
    delta_N = [segnum - value[2] for segnum in P30_Age2_segnum]
    P30_deltaArbor.append(delta_A)
    P30_deltaSegNum.append(delta_N)
    P30_deltaSegLen.append(delta_L)
    len_v = [(seglen-value[1]) * value[2] for seglen in P30_Age2_seglen]
    P30_Len_value.append(len_v)
    num_v = [(segnum - value[2]) * value[1] for segnum in P30_Age2_segnum]
    P30_Num_value.append(num_v)

    len_num_zip = zip(delta_L,delta_N)
    len_num_v = [item[0]* item[1] for item in len_num_zip]
    P30_LenNum_value.append(len_num_v)


P12_flat_deltaArbor  = [value for cell in P12_deltaArbor for value in cell]
P12_flat_Num_value = [value for cell in P12_Num_value for value in cell]
P12_flat_Len_value  = [value for cell in P12_Len_value for value in cell]
P12_flat_LenNum_value  = [value for cell in P12_LenNum_value for value in cell]

P16_flat_deltaArbor  = [value for cell in P16_deltaArbor for value in cell]
P16_flat_Num_value = [value for cell in P16_Num_value for value in cell]
P16_flat_Len_value  = [value for cell in P16_Len_value for value in cell]
P16_flat_LenNum_value  = [value for cell in P16_LenNum_value for value in cell]

P21_flat_deltaArbor  = [value for cell in P21_deltaArbor for value in cell]
P21_flat_Num_value = [value for cell in P21_Num_value for value in cell]
P21_flat_Len_value  = [value for cell in P21_Len_value for value in cell]
P21_flat_LenNum_value  = [value for cell in P21_LenNum_value for value in cell]

P30_flat_deltaArbor  = [value for cell in P30_deltaArbor for value in cell]
P30_flat_Num_value = [value for cell in P30_Num_value for value in cell]
P30_flat_Len_value  = [value for cell in P30_Len_value for value in cell]
P30_flat_LenNum_value  = [value for cell in P30_LenNum_value for value in cell]


#Calculate Means
P12_deltaArbor_mean = np.mean(P12_flat_deltaArbor)
P12_Num_value_mean = np.mean(P12_flat_Num_value)
P12_Len_value_mean = np.mean(P12_flat_Len_value)
P12_LenNum_value_mean = np.mean(P12_flat_LenNum_value)
print P12_Num_value_mean
print P12_Len_value_mean
print P12_LenNum_value_mean

P16_deltaArbor_mean = np.mean(P16_flat_deltaArbor)
P16_Num_value_mean = np.mean(P16_flat_Num_value)
P16_Len_value_mean = np.mean(P16_flat_Len_value)
P16_LenNum_value_mean = np.mean(P16_flat_LenNum_value)
print P16_Num_value_mean
print P16_Len_value_mean
print P16_LenNum_value_mean

P21_deltaArbor_mean = np.mean(P21_flat_deltaArbor)
P21_Num_value_mean = np.mean(P21_flat_Num_value)
P21_Len_value_mean = np.mean(P21_flat_Len_value)
P21_LenNum_value_mean = np.mean(P21_flat_LenNum_value)
print P21_Num_value_mean
print P21_Len_value_mean
print P21_LenNum_value_mean

P30_deltaArbor_mean = np.mean(P30_flat_deltaArbor)
P30_Num_value_mean = np.mean(P30_flat_Num_value)
P30_Len_value_mean = np.mean(P30_flat_Len_value)
P30_LenNum_value_mean = np.mean(P30_flat_LenNum_value)
print P30_Num_value_mean
print P30_Len_value_mean
print P30_LenNum_value_mean



#Calculate SEM
# deltaArbor_SEM  = np.std(flat_deltaArbor,ddof=1) / math.sqrt(len(flat_deltaArbor))
# Num_value_SEM = np.std(flat_Num_value,ddof=1) / math.sqrt(len(flat_Num_value))
# Len_value_SEM = np.std(flat_Len_value,ddof=1) / math.sqrt(len(flat_Len_value))
# LenNum_value_SEM = np.std(flat_LenNum_value,ddof=1) / math.sqrt(len(flat_LenNum_value))

#Caluculate Standard Error
P12_deltaArbor_STD = np.std(P12_flat_deltaArbor,ddof=1)
P12_Num_value_STD = np.std(P12_flat_Num_value,ddof=1)
P12_Len_value_STD = np.std(P12_flat_Len_value,ddof=1)
P12_LenNum_value_STD = np.std(P12_flat_LenNum_value,ddof=1)

P16_deltaArbor_STD = np.std(P16_flat_deltaArbor,ddof=1)
P16_Num_value_STD = np.std(P16_flat_Num_value,ddof=1)
P16_Len_value_STD = np.std(P16_flat_Len_value,ddof=1)
P16_LenNum_value_STD = np.std(P16_flat_LenNum_value,ddof=1)

P21_deltaArbor_STD = np.std(P21_flat_deltaArbor,ddof=1)
P21_Num_value_STD = np.std(P21_flat_Num_value,ddof=1)
P21_Len_value_STD = np.std(P21_flat_Len_value,ddof=1)
P21_LenNum_value_STD = np.std(P21_flat_LenNum_value,ddof=1)

P30_deltaArbor_STD = np.std(P30_flat_deltaArbor,ddof=1)
P30_Num_value_STD = np.std(P30_flat_Num_value,ddof=1)
P30_Len_value_STD = np.std(P30_flat_Len_value,ddof=1)
P30_LenNum_value_STD = np.std(P30_flat_LenNum_value,ddof=1)


#Make Blank Figure
fig,axs = plot.subplots(nrows=2, ncols=1, sharex=False, sharey='row')
#Plot growth graph
ax=axs[0]
objects = ('WT P12', 'WT P16', 'WT P21')
ax.set_xlim(0,12)
ax.set_ylim(-4000,6000)
xvalue = [1,1.5,2, 4,4.5,5, 7,7.5,8, 10,10.5,11]
yvalue = [P12_Num_value_mean, P12_Len_value_mean,P12_LenNum_value_mean,P16_Num_value_mean,P16_Len_value_mean,P16_LenNum_value_mean,
          P21_Num_value_mean,P21_Len_value_mean,P21_LenNum_value_mean,P30_Num_value_mean,P30_Len_value_mean,P30_LenNum_value_mean]

yerr = [P12_Num_value_STD, P12_Len_value_STD,P12_LenNum_value_STD,P16_Num_value_STD,P16_Len_value_STD,P16_LenNum_value_STD,
          P21_Num_value_STD,P21_Len_value_STD,P21_LenNum_value_STD,P30_Num_value_STD,P30_Len_value_STD,P30_LenNum_value_STD]


# ax.violinplot(P12_flat_deltaArbor,[0])
ax.violinplot(P12_flat_Num_value,[1])
ax.violinplot(P12_flat_Len_value,[1.5])
ax.violinplot(P12_flat_LenNum_value,[2])


ax.violinplot(P16_flat_Num_value,[4])
ax.violinplot(P16_flat_Len_value,[4.5])
ax.violinplot(P16_flat_LenNum_value,[5])


ax.violinplot(P21_flat_Num_value,[7])
ax.violinplot(P21_flat_Len_value,[7.5])
ax.violinplot(P21_flat_LenNum_value,[8])

ax.violinplot(P30_flat_Num_value,[10])
ax.violinplot(P30_flat_Len_value,[10.5])
ax.violinplot(P30_flat_LenNum_value,[11])



# ax.scatter(0,P12_deltaArbor_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(1,P12_Num_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(1.5,P12_Len_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(2,P12_LenNum_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(4,P16_Num_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(4.5,P16_Len_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(5,P16_LenNum_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)


ax.scatter(7,P21_Num_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(7.5,P21_Len_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(8,P21_LenNum_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(10,P30_Num_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(10.5,P30_Len_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(11,P30_LenNum_value_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.errorbar(xvalue,yvalue,yerr,fmt='none',ecolor= '#0d0d0d',elinewidth='2',capsize=10,capthick='2')
ax.plot((0,12),(0,12), '--', linewidth=2)


# Plot FLX DPI boxplots
ax =axs[1]

ax.set_xlim(0,12)
ax.set_ylim(-4000,6000)

data=(P12_flat_Num_value,P12_flat_Len_value,P12_flat_LenNum_value, P16_flat_Num_value, P16_flat_Len_value,P16_flat_LenNum_value,
      P21_flat_Num_value,P21_flat_Len_value,P21_flat_LenNum_value,P30_flat_Num_value,P30_flat_Len_value,P30_flat_LenNum_value)

position=[1,1.5,2, 4,4.5,5, 7,7.5,8, 10,10.5,11]


boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0AF25', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data,positions = position, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops,widths=0.4)
# colors = ['#838383', '#838383','#838383', '#5b5b5b','#5b5b5b','#5b5b5b','#343434','#343434','#343434','#0d0d0d','#0d0d0d','#0d0d0d']
colors = ['#6DB7BA', '#6DB7BA', '#6DB7BA', '#289498', '#289498', '#289498', '#008287',
          '#008287', '#008287', '#025F64', '#025F64', '#025F64']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

# ax.scatter(0,P12_deltaArbor_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(1,P12_Num_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(1.5,P12_Len_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(2,P12_LenNum_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(4,P16_Num_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(4.5,P16_Len_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(5,P16_LenNum_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)


ax.scatter(7,P21_Num_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(7.5,P21_Len_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(8,P21_LenNum_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(10,P30_Num_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(10.5,P30_Len_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(11,P30_LenNum_value_mean, color = '#F26B47',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.errorbar(xvalue,yvalue,yerr,fmt='none',ecolor= '#F26B47',elinewidth='2',capsize=10,capthick='2')
ax.plot((0,12),(0,12), '--', linewidth=2)



plot.show()

# ### Test code to calculate the fraction development stats for Steve ###
# import numpy as np
# import math
# import matplotlib.pyplot as plot;
#
# plot.rcdefaults()
# import matplotlib.pyplot as plot
# import statsmodels.api as sm
# from random import *
#
# from Database_Queries import geno_growth_components
#
# P7_WT_arbor, P7_WT_seglen, P7_WT_segnum, P12_WT_arbor, P12_WT_seglen, P12_WT_segnum, P16_WT_arbor, P16_WT_seglen, P16_WT_segnum, \
# P21_WT_arbor, P21_WT_seglen, P21_WT_segnum, P30_WT_arbor, P30_WT_seglen, P30_WT_segnum, P7_KO_arbor, P7_KO_seglen, P7_KO_segnum, \
# P12_KO_arbor, P12_KO_seglen, P12_KO_segnum, P16_KO_arbor, P16_KO_seglen, P16_KO_segnum, P21_KO_arbor, P21_KO_seglen, P21_KO_segnum, \
# P30_KO_arbor, P30_KO_seglen, P30_KO_segnum = geno_growth_components()
#
# print P16_KO_arbor
#
# P7_WT_values = zip(P7_WT_arbor, P7_WT_seglen, P7_WT_segnum)
# P12_WT_values = zip(P12_WT_arbor, P12_WT_seglen, P12_WT_segnum)
# P16_WT_values = zip(P16_WT_arbor, P16_WT_seglen, P16_WT_segnum)
# P21_WT_values = zip(P21_WT_arbor, P21_WT_seglen, P21_WT_segnum)
# P30_WT_values = zip(P30_WT_arbor, P30_WT_seglen, P30_WT_segnum)
#
# P7_KO_values = zip(P7_KO_arbor, P7_KO_seglen, P7_KO_segnum)
# P12_KO_values = zip(P12_KO_arbor, P12_KO_seglen, P12_KO_segnum)
# P16_KO_values = zip(P16_KO_arbor, P16_KO_seglen, P16_KO_segnum)
# P21_KO_values = zip(P21_KO_arbor, P21_KO_seglen, P21_KO_segnum)
# P30_KO_values = zip(P30_KO_arbor, P30_KO_seglen, P30_KO_segnum)
#
# P7_deltaArbor = []
# P7_deltaSegNum = []
# P7_deltaSegLen = []
# P7_Len_value = []
# P7_Num_value = []
# P7_LenNum_value = []
#
# for value in P7_WT_values:
#     delta_A = [arbor - value[0] for arbor in P7_KO_arbor]
#     delta_L = [seglen - value[1] for seglen in P7_KO_seglen]
#     delta_N = [segnum - value[2] for segnum in P7_KO_segnum]
#     P7_deltaArbor.append(delta_A)
#     P7_deltaSegNum.append(delta_N)
#     P7_deltaSegLen.append(delta_L)
#     len_v = [(seglen - value[1]) * value[2] for seglen in P7_KO_seglen]
#     P7_Len_value.append(len_v)
#     num_v = [(segnum - value[2]) * value[1] for segnum in P7_KO_segnum]
#     P7_Num_value.append(num_v)
#
#     len_num_zip = zip(delta_L, delta_N)
#     len_num_v = [item[0] * item[1] for item in len_num_zip]
#     P7_LenNum_value.append(len_num_v)
#
# P12_deltaArbor = []
# P12_deltaSegNum = []
# P12_deltaSegLen = []
# P12_Len_value = []
# P12_Num_value = []
# P12_LenNum_value = []
#
# for value in P12_WT_values:
#     delta_A = [arbor - value[0] for arbor in P12_KO_arbor]
#     delta_L = [seglen - value[1] for seglen in P12_KO_seglen]
#     delta_N = [segnum - value[2] for segnum in P12_KO_segnum]
#     P12_deltaArbor.append(delta_A)
#     P12_deltaSegNum.append(delta_N)
#     P12_deltaSegLen.append(delta_L)
#     len_v = [(seglen - value[1]) * value[2] for seglen in P12_KO_seglen]
#     P12_Len_value.append(len_v)
#     num_v = [(segnum - value[2]) * value[1] for segnum in P12_KO_segnum]
#     P12_Num_value.append(num_v)
#
#     len_num_zip = zip(delta_L, delta_N)
#     len_num_v = [item[0] * item[1] for item in len_num_zip]
#     P12_LenNum_value.append(len_num_v)
#
# P16_deltaArbor = []
# P16_deltaSegNum = []
# P16_deltaSegLen = []
# P16_Len_value = []
# P16_Num_value = []
# P16_LenNum_value = []
#
# for value in P16_WT_values:
#     delta_A = [arbor - value[0] for arbor in P16_KO_arbor]
#     delta_L = [seglen - value[1] for seglen in P16_KO_seglen]
#     delta_N = [segnum - value[2] for segnum in P16_KO_segnum]
#     P16_deltaArbor.append(delta_A)
#     P16_deltaSegNum.append(delta_N)
#     P16_deltaSegLen.append(delta_L)
#     len_v = [(seglen - value[1]) * value[2] for seglen in P16_KO_seglen]
#     P16_Len_value.append(len_v)
#     num_v = [(segnum - value[2]) * value[1] for segnum in P16_KO_segnum]
#     P16_Num_value.append(num_v)
#
#     len_num_zip = zip(delta_L, delta_N)
#     len_num_v = [item[0] * item[1] for item in len_num_zip]
#     P16_LenNum_value.append(len_num_v)
#
# P21_deltaArbor = []
# P21_deltaSegNum = []
# P21_deltaSegLen = []
# P21_Len_value = []
# P21_Num_value = []
# P21_LenNum_value = []
#
# for value in P21_WT_values:
#     delta_A = [arbor - value[0] for arbor in P21_KO_arbor]
#     delta_L = [seglen - value[1] for seglen in P21_KO_seglen]
#     delta_N = [segnum - value[2] for segnum in P21_KO_segnum]
#     P21_deltaArbor.append(delta_A)
#     P21_deltaSegNum.append(delta_N)
#     P21_deltaSegLen.append(delta_L)
#     len_v = [(seglen - value[1]) * value[2] for seglen in P21_KO_seglen]
#     P21_Len_value.append(len_v)
#     num_v = [(segnum - value[2]) * value[1] for segnum in P21_KO_segnum]
#     P21_Num_value.append(num_v)
#
#     len_num_zip = zip(delta_L, delta_N)
#     len_num_v = [item[0] * item[1] for item in len_num_zip]
#     P21_LenNum_value.append(len_num_v)
#
# P30_deltaArbor = []
# P30_deltaSegNum = []
# P30_deltaSegLen = []
# P30_Len_value = []
# P30_Num_value = []
# P30_LenNum_value = []
#
# for value in P30_WT_values:
#     delta_A = [arbor - value[0] for arbor in P30_KO_arbor]
#     delta_L = [seglen - value[1] for seglen in P30_KO_seglen]
#     delta_N = [segnum - value[2] for segnum in P30_KO_segnum]
#     P30_deltaArbor.append(delta_A)
#     P30_deltaSegNum.append(delta_N)
#     P30_deltaSegLen.append(delta_L)
#     len_v = [(seglen - value[1]) * value[2] for seglen in P30_KO_seglen]
#     P30_Len_value.append(len_v)
#     num_v = [(segnum - value[2]) * value[1] for segnum in P30_KO_segnum]
#     P30_Num_value.append(num_v)
#
#     len_num_zip = zip(delta_L, delta_N)
#     len_num_v = [item[0] * item[1] for item in len_num_zip]
#     P30_LenNum_value.append(len_num_v)
#
# P7_flat_deltaArbor = [value for cell in P7_deltaArbor for value in cell]
# P7_flat_Num_value = [value for cell in P7_Num_value for value in cell]
# P7_flat_Len_value = [value for cell in P7_Len_value for value in cell]
# P7_flat_LenNum_value = [value for cell in P7_LenNum_value for value in cell]
#
# P12_flat_deltaArbor = [value for cell in P12_deltaArbor for value in cell]
# P12_flat_Num_value = [value for cell in P12_Num_value for value in cell]
# P12_flat_Len_value = [value for cell in P12_Len_value for value in cell]
# P12_flat_LenNum_value = [value for cell in P12_LenNum_value for value in cell]
#
# P16_flat_deltaArbor = [value for cell in P16_deltaArbor for value in cell]
# P16_flat_Num_value = [value for cell in P16_Num_value for value in cell]
# P16_flat_Len_value = [value for cell in P16_Len_value for value in cell]
# P16_flat_LenNum_value = [value for cell in P16_LenNum_value for value in cell]
# print P16_flat_deltaArbor
# # print P16_flat_Num_value
# # print P16_flat_Len_value
# # print P16_flat_LenNum_value
#
# P21_flat_deltaArbor = [value for cell in P21_deltaArbor for value in cell]
# P21_flat_Num_value = [value for cell in P21_Num_value for value in cell]
# P21_flat_Len_value = [value for cell in P21_Len_value for value in cell]
# P21_flat_LenNum_value = [value for cell in P21_LenNum_value for value in cell]
#
# P30_flat_deltaArbor = [value for cell in P30_deltaArbor for value in cell]
# P30_flat_Num_value = [value for cell in P30_Num_value for value in cell]
# P30_flat_Len_value = [value for cell in P30_Len_value for value in cell]
# P30_flat_LenNum_value = [value for cell in P30_LenNum_value for value in cell]
#
# # Calculate Means
# P7_deltaArbor_mean = np.mean(P7_flat_deltaArbor)
# P7_Num_value_mean = np.mean(P7_flat_Num_value)
# P7_Len_value_mean = np.mean(P7_flat_Len_value)
# P7_LenNum_value_mean = np.mean(P7_flat_LenNum_value)
# # print P7_Num_value_mean
# # print P7_Len_value_mean
# # print P7_LenNum_value_mean
#
# P12_deltaArbor_mean = np.mean(P12_flat_deltaArbor)
# P12_Num_value_mean = np.mean(P12_flat_Num_value)
# P12_Len_value_mean = np.mean(P12_flat_Len_value)
# P12_LenNum_value_mean = np.mean(P12_flat_LenNum_value)
# # print P12_Num_value_mean
# # print P12_Len_value_mean
# # print P12_LenNum_value_mean
#
# P16_deltaArbor_mean = np.mean(P16_flat_deltaArbor)
# P16_Num_value_mean = np.mean(P16_flat_Num_value)
# P16_Len_value_mean = np.mean(P16_flat_Len_value)
# P16_LenNum_value_mean = np.mean(P16_flat_LenNum_value)
# # print P16_Num_value_mean
# # print P16_Len_value_mean
# # print P16_LenNum_value_mean
#
# P21_deltaArbor_mean = np.mean(P21_flat_deltaArbor)
# P21_Num_value_mean = np.mean(P21_flat_Num_value)
# P21_Len_value_mean = np.mean(P21_flat_Len_value)
# P21_LenNum_value_mean = np.mean(P21_flat_LenNum_value)
# # print P21_Num_value_mean
# # print P21_Len_value_mean
# # print P21_LenNum_value_mean
#
# P30_deltaArbor_mean = np.mean(P30_flat_deltaArbor)
# P30_Num_value_mean = np.mean(P30_flat_Num_value)
# P30_Len_value_mean = np.mean(P30_flat_Len_value)
# P30_LenNum_value_mean = np.mean(P30_flat_LenNum_value)
# # print P30_Num_value_mean
# # print P30_Len_value_mean
# # print P30_LenNum_value_mean
#
# # Calculate SEM
# # deltaArbor_SEM  = np.std(flat_deltaArbor,ddof=1) / math.sqrt(len(flat_deltaArbor))
# # Num_value_SEM = np.std(flat_Num_value,ddof=1) / math.sqrt(len(flat_Num_value))
# # Len_value_SEM = np.std(flat_Len_value,ddof=1) / math.sqrt(len(flat_Len_value))
# # LenNum_value_SEM = np.std(flat_LenNum_value,ddof=1) / math.sqrt(len(flat_LenNum_value))
#
# # Caluculate Standard Error
# P7_deltaArbor_STD = np.std(P7_flat_deltaArbor, ddof=1)
# P7_Num_value_STD = np.std(P7_flat_Num_value, ddof=1)
# P7_Len_value_STD = np.std(P7_flat_Len_value, ddof=1)
# P7_LenNum_value_STD = np.std(P7_flat_LenNum_value, ddof=1)
#
# P12_deltaArbor_STD = np.std(P12_flat_deltaArbor, ddof=1)
# P12_Num_value_STD = np.std(P12_flat_Num_value, ddof=1)
# P12_Len_value_STD = np.std(P12_flat_Len_value, ddof=1)
# P12_LenNum_value_STD = np.std(P12_flat_LenNum_value, ddof=1)
#
# P16_deltaArbor_STD = np.std(P16_flat_deltaArbor, ddof=1)
# P16_Num_value_STD = np.std(P16_flat_Num_value, ddof=1)
# P16_Len_value_STD = np.std(P16_flat_Len_value, ddof=1)
# P16_LenNum_value_STD = np.std(P16_flat_LenNum_value, ddof=1)
#
# P21_deltaArbor_STD = np.std(P21_flat_deltaArbor, ddof=1)
# P21_Num_value_STD = np.std(P21_flat_Num_value, ddof=1)
# P21_Len_value_STD = np.std(P21_flat_Len_value, ddof=1)
# P21_LenNum_value_STD = np.std(P21_flat_LenNum_value, ddof=1)
#
# P30_deltaArbor_STD = np.std(P30_flat_deltaArbor, ddof=1)
# P30_Num_value_STD = np.std(P30_flat_Num_value, ddof=1)
# P30_Len_value_STD = np.std(P30_flat_Len_value, ddof=1)
# P30_LenNum_value_STD = np.std(P30_flat_LenNum_value, ddof=1)
#
# # Make Blank Figure
# fig, axs = plot.subplots(nrows=2, ncols=1, sharex=False, sharey='row')
# # Plot growth graph
# ax = axs[0]
#
# ax.set_xlim(0, 15)
# xvalue = [1, 1.5, 2, 4, 4.5, 5, 7, 7.5, 8, 10, 10.5, 11, 13, 13.5, 14]
# yvalue = [P7_Num_value_mean, P7_Len_value_mean, P7_LenNum_value_mean, P12_Num_value_mean, P12_Len_value_mean,
#           P12_LenNum_value_mean, P16_Num_value_mean, P16_Len_value_mean,
#           P16_LenNum_value_mean, P21_Num_value_mean, P21_Len_value_mean, P21_LenNum_value_mean, P30_Num_value_mean,
#           P30_Len_value_mean, P30_LenNum_value_mean]
#
# yerr = [P7_Num_value_STD, P7_Len_value_STD, P7_LenNum_value_STD, P12_Num_value_STD, P12_Len_value_STD,
#         P12_LenNum_value_STD, P16_Num_value_STD, P16_Len_value_STD,
#         P16_LenNum_value_STD, P21_Num_value_STD, P21_Len_value_STD, P21_LenNum_value_STD, P30_Num_value_STD,
#         P30_Len_value_STD, P30_LenNum_value_STD]
#
# # ax.violinplot(P12_flat_deltaArbor,[0])
# ax.violinplot(P7_flat_Num_value, [1])
# ax.violinplot(P7_flat_Len_value, [1.5])
# ax.violinplot(P7_flat_LenNum_value, [2])
#
# ax.violinplot(P12_flat_Num_value, [4])
# ax.violinplot(P12_flat_Len_value, [4.5])
# ax.violinplot(P12_flat_LenNum_value, [25])
#
# ax.violinplot(P16_flat_Num_value, [7])
# ax.violinplot(P16_flat_Len_value, [7.5])
# ax.violinplot(P16_flat_LenNum_value, [8])
#
# ax.violinplot(P21_flat_Num_value, [10])
# ax.violinplot(P21_flat_Len_value, [10.5])
# ax.violinplot(P21_flat_LenNum_value, [11])
#
# ax.violinplot(P30_flat_Num_value, [13])
# ax.violinplot(P30_flat_Len_value, [13.5])
# ax.violinplot(P30_flat_LenNum_value, [14])
#
# # ax.scatter(0,P12_deltaArbor_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(1, P7_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(1.5, P7_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(2, P7_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(4, P12_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(4.5, P12_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(5, P12_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(7, P16_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(7.5, P16_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(8, P16_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(10, P21_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(10.5, P21_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(11, P21_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(13, P30_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(13.5, P30_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(14, P30_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.errorbar(xvalue, yvalue, yerr, fmt='none', ecolor='#F26B47', elinewidth='2', capsize=10, capthick='2')
# ax.plot((0, 15), (0, 15), '--', linewidth=2)
#
# # Plot FLX DPI boxplots
# ax = axs[1]
#
# data = (P7_flat_Num_value, P7_flat_Len_value, P7_flat_LenNum_value, P12_flat_Num_value, P12_flat_Len_value,
#         P12_flat_LenNum_value, P16_flat_Num_value, P16_flat_Len_value,
#         P16_flat_LenNum_value,
#         P21_flat_Num_value, P21_flat_Len_value, P21_flat_LenNum_value, P30_flat_Num_value, P30_flat_Len_value,
#         P30_flat_LenNum_value)
#
# position = [1, 1.5, 2, 4, 4.5, 5, 7, 7.5, 8, 10, 10.5, 11, 13, 13.5, 14]
#
# boxprops = dict(linestyle='-', linewidth=0, color='none', facecolor=('#035069'))
# flierprops = dict(marker='o', markerfacecolor='#E0AF25', markersize=4, markeredgecolor='none')
# medianprops = dict(linestyle='-', linewidth=2.5, color='white')
# whiskerprops = dict(linestyle='-', color='#666666', linewidth=2)
# capprops = dict(linewidth=2, color='#666666')
#
# box = ax.boxplot(data, positions=position, patch_artist=True, sym='o', boxprops=boxprops, flierprops=flierprops,
#                  medianprops=medianprops, whiskerprops=whiskerprops, capprops=capprops, widths=0.4)
# colors = ['#C2DCDE', '#C2DCDE', '#C2DCDE', '#6DB7BA', '#6DB7BA', '#6DB7BA', '#289498', '#289498', '#289498', '#008287',
#           '#008287', '#008287', '#025F64', '#025F64', '#025F64']
# for patch, color in zip(box['boxes'], colors):
#     patch.set_facecolor(color)
#
# # ax.scatter(0,P12_deltaArbor_mean, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=80)
# ax.scatter(1, P7_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(1.5, P7_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(2, P7_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(4, P12_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(4.5, P12_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(5, P12_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(7, P16_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(7.5, P16_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(8, P16_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(10, P21_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(10.5, P21_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(11, P21_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.scatter(13, P30_Num_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(13.5, P30_Len_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
# ax.scatter(14, P30_LenNum_value_mean, color='#F26B47', zorder='2', alpha='0.8', edgecolors='none', s=80)
#
# ax.errorbar(xvalue, yvalue, yerr, fmt='none', ecolor='#F26B47', elinewidth='2', capsize=10, capthick='2')
# ax.plot((0, 15), (0, 15), '--', linewidth=2)
#
# plot.show()
