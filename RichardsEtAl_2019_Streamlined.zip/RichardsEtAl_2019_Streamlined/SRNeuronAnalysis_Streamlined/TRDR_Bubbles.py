import math
import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *
from Database_Queries import dev_graphs

WTTR_P7_values, WTTR_P12_values, WTTR_P16_values, WTTR_P21_values, WTTR_P30_values, KOTR_P7_values, KOTR_P12_values, KOTR_P16_values, KOTR_P21_values, KOTR_P30_values, WTDD_P16_values, WTDD_P21_values, WTDD_P30_values, KODD_P16_values, KODD_P21_values, KODD_P30_values = dev_graphs('arbor_length')

# #print len
# print len(WTTR_P7_values)
# print len(WTTR_P12_values)
# print len(WTTR_P16_values)
# print len(WTTR_P21_values)
# print len(WTTR_P30_values)


#Calculate Means
WTTR_P16_Mean = np.mean(WTTR_P16_values)
WTDD_P16_Mean = np.mean(WTDD_P16_values)
WTTR_P21_Mean = np.mean(WTTR_P21_values)
WTDD_P21_Mean = np.mean(WTDD_P21_values)
WTTR_P30_Mean = np.mean(WTTR_P30_values)
WTDD_P30_Mean = np.mean(WTDD_P30_values)

KOTR_P16_Mean = np.mean(KOTR_P16_values)
KODD_P16_Mean = np.mean(KODD_P16_values)
KOTR_P21_Mean = np.mean(KOTR_P21_values)
KODD_P21_Mean = np.mean(KODD_P21_values)
KOTR_P30_Mean = np.mean(KOTR_P30_values)
KODD_P30_Mean = np.mean(KODD_P30_values)

#Calculate SEM

WTTR_P16_SEM = np.std(WTTR_P16_values,ddof=1) / math.sqrt(len(WTTR_P16_values))
WTDD_P16_SEM = np.std(WTDD_P16_values,ddof=1) / math.sqrt(len(WTDD_P16_values))
WTTR_P21_SEM = np.std(WTTR_P21_values,ddof=1) / math.sqrt(len(WTTR_P21_values))
WTDD_P21_SEM = np.std(WTDD_P21_values,ddof=1) / math.sqrt(len(WTDD_P21_values))
WTTR_P30_SEM = np.std(WTTR_P30_values,ddof=1) / math.sqrt(len(WTTR_P30_values))
WTDD_P30_SEM = np.std(WTDD_P30_values,ddof=1) / math.sqrt(len(WTDD_P30_values))

KOTR_P16_SEM = np.std(KOTR_P16_values,ddof=1) / math.sqrt(len(KOTR_P16_values))
KODD_P16_SEM = np.std(KODD_P16_values,ddof=1) / math.sqrt(len(KODD_P16_values))
KOTR_P21_SEM = np.std(KOTR_P21_values,ddof=1) / math.sqrt(len(KOTR_P21_values))
KODD_P21_SEM = np.std(KODD_P21_values,ddof=1) / math.sqrt(len(KODD_P21_values))
KOTR_P30_SEM = np.std(KOTR_P30_values,ddof=1) / math.sqrt(len(KOTR_P30_values))
KODD_P30_SEM = np.std(KODD_P30_values,ddof=1) / math.sqrt(len(KODD_P30_values))

#Make Blank Figure
fig,axs = plot.subplots(nrows=1, ncols=3, sharex=False, sharey='row')

#Plot WT Dev Graph
ax=axs[0]

objects = ('WTTR P16', 'WTDD P16','WTTR P21', 'WTDD P21', 'WTTR P30', 'WTDD P30')
xvalue = [0.5,1.0,2.0,2.5,3.5,4.0]
yvalue = [WTTR_P16_Mean, WTDD_P16_Mean, WTTR_P21_Mean, WTDD_P21_Mean, WTTR_P30_Mean, WTDD_P30_Mean]
yerr = [WTTR_P16_SEM, WTDD_P16_SEM, WTTR_P21_SEM, WTDD_P21_SEM, WTTR_P30_SEM, WTDD_P30_SEM]

WTTRP16_xcoords = []
WTTRP16_xcoords = [uniform(0.4,0.6) for value in WTTR_P16_values]
WTDDP16_xcoords = []
WTDDP16_xcoords = [uniform(0.9,1.1) for value in WTDD_P16_values]

WTTRP21_xcoords = []
WTTRP21_xcoords = [uniform(1.9,2.1) for value in WTTR_P21_values]
WTDDP21_xcoords = []
WTDDP21_xcoords = [uniform(2.4,2.6) for value in WTDD_P21_values]

WTTRP30_xcoords = []
WTTRP30_xcoords  = [uniform(3.4,3.6) for value in WTTR_P30_values]
WTDDP30_xcoords = []
WTDDP30_xcoords  = [uniform(3.9,4.1) for value in WTDD_P30_values]


ax.scatter(WTTRP16_xcoords,WTTR_P16_values, color = '#5b5b5b',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(0.5,WTTR_P16_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WTDDP16_xcoords,WTDD_P16_values, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(1.0,WTDD_P16_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(WTTRP21_xcoords,WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(2.0,WTTR_P21_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WTDDP21_xcoords,WTDD_P21_values, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(2.5,WTDD_P21_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(WTTRP30_xcoords,WTTR_P30_values, color = '#0d0d0d',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(3.5,WTTR_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WTDDP30_xcoords,WTDD_P30_values, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(4.0,WTDD_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)

# ax.bar(xvalue, yvalue, align='center', alpha=1, color=('#b4b4b4','#838383','#5b5b5b','#343434','#0d0d0d'), linewidth=0)
ax.set_title('WT Development')
ax.errorbar(xvalue,yvalue,yerr,fmt='none',ecolor= '#DFB125',elinewidth='2',capsize=10,capthick='2')


#Plot KO Dev Graph
ax=axs[1]
# ax.set_ylim(0,0.0004)
objects = ('KOTR P16', 'KODD P16','KOTR P21', 'KODD P21', 'KOTR P30', 'KODD P30')
xvalue = [0.5,1.0,2.0,2.5,3.5,4.0]
yvalue = [KOTR_P16_Mean, KODD_P16_Mean, KOTR_P21_Mean, KODD_P21_Mean, KOTR_P30_Mean, KODD_P30_Mean]
yerr = [KOTR_P16_SEM, KODD_P16_SEM, KOTR_P21_SEM, KODD_P21_SEM, KOTR_P30_SEM, KODD_P30_SEM]

KOTRP16_xcoords = []
KOTRP16_xcoords = [uniform(0.4,0.6) for value in KOTR_P16_values]
KODDP16_xcoords = []
KODDP16_xcoords = [uniform(0.9,1.1) for value in KODD_P16_values]

KOTRP21_xcoords = []
KOTRP21_xcoords = [uniform(1.9,2.1) for value in KOTR_P21_values]
KODDP21_xcoords = []
KODDP21_xcoords = [uniform(2.4,2.6) for value in KODD_P21_values]

KOTRP30_xcoords = []
KOTRP30_xcoords  = [uniform(3.4,3.6) for value in KOTR_P30_values]
KODDP30_xcoords = []
KODDP30_xcoords  = [uniform(3.9,4.1) for value in KODD_P30_values]


ax.scatter(KOTRP16_xcoords,KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(0.5,KOTR_P16_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(KODDP16_xcoords,KODD_P16_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(1.0,KODD_P16_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(KOTRP21_xcoords,KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(2.0,KOTR_P21_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(KODDP21_xcoords,KODD_P21_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(2.5,KODD_P21_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(KOTRP30_xcoords,KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(3.5,KOTR_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(KODDP30_xcoords,KODD_P30_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(4.0,KODD_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)

# ax.bar(xvalue, yvalue, align='center', alpha=1, color=('#b4b4b4','#838383','#5b5b5b','#343434','#0d0d0d'), linewidth=0)
ax.set_title('KO Development')
ax.errorbar(xvalue,yvalue,yerr,fmt='none',ecolor= '#DFB125',elinewidth='2',capsize=10,capthick='2')

#WTvsKO TRvsDD
ax=axs[2]

objects = ('WTTR P16', 'WTDD P16', 'KOTR P16', 'KODD P16', 'WTTR P21', 'WTDD P21', 'KOTR P21', 'KODD P21', 'WTTR P30', 'WTDD P30', 'KOTR P30', 'KODD P30')
xvalue = [3.5,4.0,5.0,5.5]
yvalue = [ WTTR_P30_Mean, WTDD_P30_Mean, KOTR_P30_Mean, KODD_P30_Mean]
yerr = [WTTR_P30_SEM, WTDD_P30_SEM,  KOTR_P30_SEM, KODD_P30_SEM]


WTTRP30_xcoords = []
WTTRP30_xcoords  = [uniform(3.4,3.6) for value in WTTR_P30_values]
WTDDP30_xcoords = []
WTDDP30_xcoords  = [uniform(3.9,4.1) for value in WTDD_P30_values]

KOTRP30_xcoords = []
KOTRP30_xcoords = [uniform(4.9,5.1) for value in KOTR_P30_values]
KODDP30_xcoords  = []
KODDP30_xcoords = [uniform(5.4,5.6) for value in KODD_P30_values]


ax.scatter(WTTRP30_xcoords,WTTR_P30_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(3.5,WTTR_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(WTDDP30_xcoords,WTDD_P30_values, color = '#b4b4b4',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(4.0,WTDD_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)

ax.scatter(KOTRP30_xcoords,KOTR_P30_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(5.0,KOTR_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)
ax.scatter(KODDP30_xcoords,KODD_P30_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none',s=40)
ax.scatter(5.5,KODD_P30_Mean, color = '#DFB125',zorder='2',alpha='0.8',edgecolors='none',s=80)


# ax.bar(xvalue, yvalue, align='center', alpha=1, color=('#b4b4b4','#838383','#5b5b5b','#343434','#0d0d0d'), linewidth=0)
ax.set_title('WT Development')
ax.errorbar(xvalue,yvalue,yerr,fmt='none',ecolor= '#DFB125',elinewidth='2',capsize=10,capthick='2')



plot.show()