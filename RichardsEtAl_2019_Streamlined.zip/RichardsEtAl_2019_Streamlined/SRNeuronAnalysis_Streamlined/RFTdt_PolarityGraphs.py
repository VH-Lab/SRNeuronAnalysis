import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
import math

from RFTdt_Database_Queries import polarity_summary_graphs
from RFTdt_Database_Queries import absolute_polarity_summary_graphs

WTTR_Med_values,WTTR_Lat_values, FLXTR_Med_values, FLXTR_Lat_values = absolute_polarity_summary_graphs('medial_branch_number','lateral_branch_number')
print len(WTTR_Med_values)
print len(WTTR_Lat_values)
print len(FLXTR_Med_values)
print len(FLXTR_Lat_values)
# print FLXTR_values

#Calculate Means
WTTR_Med_Mean = np.mean(WTTR_Med_values)
print WTTR_Med_Mean
WTTR_Lat_Mean = np.mean(WTTR_Lat_values)
print WTTR_Lat_Mean
FLXTR_Med_Mean = np.mean(FLXTR_Med_values)
print FLXTR_Med_Mean
FLXTR_Lat_Mean = np.mean(FLXTR_Lat_values)
print FLXTR_Lat_Mean

#Calculate SEM
WTTR_Med_SEM = np.std(WTTR_Med_values,ddof=1) / math.sqrt(len(WTTR_Med_values))
WTTR_Lat_SEM = np.std(WTTR_Lat_values,ddof=1) / math.sqrt(len(WTTR_Lat_values))
FLXTR_Med_SEM = np.std(FLXTR_Med_values,ddof=1) / math.sqrt(len(FLXTR_Med_values))
FLXTR_Lat_SEM = np.std(FLXTR_Lat_values,ddof=1) / math.sqrt(len(FLXTR_Lat_values))


fig,axs = plot.subplots(nrows=1, ncols=2, sharex=False)

#Plot WT/FLX graph
ax =axs[0]
objects = ('WT Med', 'WT Lat', 'FLX Med', 'FLX Lat')
xvalue = np.arange(len(objects))
yvalue = [WTTR_Med_Mean, WTTR_Lat_Mean,FLXTR_Med_Mean,FLXTR_Lat_Mean]
yerr = [WTTR_Med_SEM, WTTR_Lat_SEM,FLXTR_Med_SEM,FLXTR_Lat_SEM]
bar_width=0.35
from random import *


# print WTTR_values
WT_Med_xcoords = []
WT_Med_xcoords = [uniform(-0.05,0.05) for value in WTTR_Med_values]
# print WT_xcoords
WT_Lat_xcoords = []
WT_Lat_xcoords = [uniform(0.95,1.05) for value in WTTR_Lat_values]


FLX_Med_xcoords = []
FLX_Med_xcoords = [uniform(1.95,2.05) for value in FLXTR_Med_values]
FLX_Lat_xcoords = []
FLX_Lat_xcoords = [uniform(2.95,3.05) for value in FLXTR_Lat_values]

ax.scatter(WT_Med_xcoords,WTTR_Med_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(WT_Lat_xcoords,WTTR_Lat_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(FLX_Med_xcoords,FLXTR_Med_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(FLX_Lat_xcoords,FLXTR_Lat_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.bar(xvalue, yvalue,bar_width, align='center', alpha=1,color=('#0d0d0d','#0d0d0d','#DFB125','#DFB125'),linewidth=0)
ax.set_ylabel('Metric')
ax.set_title('WT vs. FLX')
ax.errorbar(xvalue, yvalue, yerr, fmt='none', ecolor='#666666', elinewidth='2', capsize=10, capthick='2', zorder='1')


#
#Plot WT vs FLX boxplot
ax =axs[1]
WTTR_Med_data = WTTR_Med_values
WTTR_Lat_data = WTTR_Lat_values
FLXTR_Med_data = FLXTR_Med_values
FLXTR_Lat_data = FLXTR_Lat_values
data=(WTTR_Med_data,WTTR_Lat_data,FLXTR_Med_data,FLXTR_Lat_data)

WT_Med_xcoords = []
WT_Med_xcoords = [uniform(0.95,1.05) for value in WTTR_Med_values]
# print WT_xcoords
WT_Lat_xcoords = []
WT_Lat_xcoords = [uniform(1.95,2.05) for value in WTTR_Lat_values]


FLX_Med_xcoords = []
FLX_Med_xcoords = [uniform(2.95,3.05) for value in FLXTR_Med_values]
FLX_Lat_xcoords = []
FLX_Lat_xcoords = [uniform(3.95,4.05) for value in FLXTR_Lat_values]

ax.scatter(WT_Med_xcoords,WTTR_Med_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(WT_Lat_xcoords,WTTR_Lat_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(FLX_Med_xcoords,FLXTR_Med_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)
ax.scatter(FLX_Lat_xcoords,FLXTR_Lat_values, color = '#035069',zorder='3',alpha='0.8',edgecolors='none',s=50)


boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#DFB125'))
flierprops = dict(marker='o', markerfacecolor='#5E4FC9', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops)
colors = ['#0d0d0d','#0d0d0d','#DFB125','#DFB125']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)
ax.set_title('WT vs. FLX')


#
# # # Plot WT vs FLX * TR vs DR boxplot
# # ax =axs[1,1]
# #
# # WTTR_data = WTTR_values
# # FLXTR_data = FLXTR_values
# # WTDD_data = WTDD_values
# # FLXDD_data = FLXDD_values
# # data=(WTTR_data,WTDD_data,FLXTR_data,FLXDD_data)
# #
# # boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
# # flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
# # medianprops = dict(linestyle='-', linewidth=2.5, color='white')
# # whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
# # capprops= dict(linewidth=2,color='#666666')
# #
# # box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops)
# # colors = ['#0d0d0d','#878787','#035069','#3D9CBC']
# # for patch, color in zip(box['boxes'], colors):
# #     patch.set_facecolor(color)
# # ax.set_title('WT/FLX * TR/DR')
# #
# #
# #
# # # Plot WT/FLX * TR/DR * M/F
# # ax =axs[1,2]
# # WTTRM_data = WTTRM_values
# # WTTRF_data = WTTRF_values
# # FLXTRM_data = FLXTRM_values
# # FLXTRF_data = FLXTRF_values
# # WTDDM_data = WTDDM_values
# # WTDDF_data = WTDDF_values
# # FLXDDM_data = FLXDDM_values
# # FLXDDF_data = FLXDDF_values
# # data=(WTTRM_data,WTTRF_data,WTDDM_data,WTDDF_data,FLXTRM_data,FLXTRF_data,FLXDDM_data,FLXDDF_data)
# #
# # position=[1,2,4,5,7,8,10,11]
# #
# #
# # boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
# # flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
# # medianprops = dict(linestyle='-', linewidth=2.5, color='white')
# # whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
# # capprops= dict(linewidth=2,color='#666666')
# #
# # box=ax.boxplot(data,positions = position, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops)
# # colors = ['#0d0d0d','#0d0d0d','#878787', '#878787', '#035069', '#035069','#3D9CBC','#3D9CBC']
# # for patch, color in zip(box['boxes'], colors):
# #     patch.set_facecolor(color)
# # ax.set_title('WT/FLX * TR/DR * M/F')


plot.show()





