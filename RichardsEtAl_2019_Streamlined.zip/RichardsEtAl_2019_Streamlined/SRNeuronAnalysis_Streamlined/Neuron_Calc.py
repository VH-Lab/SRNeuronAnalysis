from AnnotationReaderXML import *
file_location = raw_input("Input data path.")
os.chdir(file_location)
annotation_files = annotation_finder(file_location)

for annotation_file in annotation_files:
    nodes,edges = annotation_parser(annotation_file)

    # print edges
    print 'annotation file name'
    id = str(annotation_filename_getter(annotation_file))
    print id

    print 'step correction'
    step = step_size_corrector(id)
    print step

    print 'node_location'
    node_locations =  node_location_finder(nodes,edges,step)
    print node_locations

    print 'source_target'
    # print source_target(edges)
    source_target_dict=source_target(edges)
    print source_target_dict

    print 'path finder'
    print path_finder(source_target_dict, '1', '38')

    print 'soma size:'
    print soma_size(nodes,edges)

    print 'tree number:'
    print primary_arbor_number(nodes,edges)

    print 'segment number:'
    print segment_number(nodes,edges)

    print 'tip number:'
    print tip_number(nodes,edges)

    print 'path_length'
    print path_length(source_target_dict, nodes, edges,step)

    print 'tortuosity'
    print tortuosity(source_target_dict, nodes, edges,step)

    print 'segment length'
    print segment_length(source_target_dict, nodes, edges,step)

    print 'arbor length'
    print arbor_length(source_target_dict, nodes, edges,step)

    print 'volume'
    print volume(nodes,edges,step)

    print 'density'
    print density (source_target_dict, nodes, edges,step)

    print 'sholl'
    print sholl(source_target_dict, nodes, edges,step)

    print 'intersections'
    print intersections(source_target_dict, nodes, edges,step)

    print 'hull overlap'
    print hull_overlap(source_target_dict, nodes, edges, step)