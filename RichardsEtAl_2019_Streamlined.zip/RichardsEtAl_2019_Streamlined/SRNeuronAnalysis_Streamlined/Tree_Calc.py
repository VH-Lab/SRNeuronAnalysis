from AnnotationReaderXML_Trees import *
file_location = raw_input("Input data path.")
os.chdir(file_location)
annotation_files = annotation_finder(file_location)

for annotation_file in annotation_files:
    nodes,edges = annotation_parser(annotation_file)

    # print edges
    # print edges
    print 'annotation file name'
    id = str(annotation_filename_getter(annotation_file))
    print id

    print 'step correction'
    step = step_size_corrector(id)
    print step

    print 'node_location'
    node_locations =  node_location_finder(nodes, edges,step)
    print node_locations

    # print 'source_target'
    # print source_target(edges)
    source_target_dict = source_target(edges)
    # print source_target_dict

    print 'find_trees'
    tree_paths = find_trees(nodes, edges, source_target_dict)

    for treepath in tree_paths:
        flat_treepath = list(set([item for sublist in treepath for item in sublist]))
        tree_nodes = [node for node in nodes if node.attrib['id'] in flat_treepath]
        tree_edges = [edge for edge in edges if edge.attrib['source'] in flat_treepath and edge.attrib['target'] in flat_treepath]

        # print 'source_target'
        # print source_target(edges)
        source_target_dict = source_target(tree_edges)
        # print source_target_dict

        # print 'tree nodes'
        # print tree_nodes
        # print tree_edges
        #
        #
        # print 'path finder'
        # print path_finder(source_target_dict, '1', '38')
        #
        # print 'branch number:'
        # print branch_number(tree_nodes,tree_edges)
        #
        # print 'tip number:'
        # print tip_number(tree_nodes,tree_edges)
        #
        # print 'path_length'
        # print path_length(source_target_dict, tree_nodes, tree_edges,step)
        #
        # print 'tortuosity'
        # print tortuosity(source_target_dict, tree_nodes, tree_edges,step)
        #
        # print 'segment length'
        # print segment_length(source_target_dict, tree_nodes, tree_edges,step)
        #
        # print 'tree length'
        # print tree_length(source_target_dict, tree_nodes, tree_edges,step)

        print 'volume'
        print volume(tree_nodes,tree_edges,step)
        #
        print 'density'
        print density (source_target_dict, tree_nodes, tree_edges, step)

        # print 'sholl'
        # print sholl(source_target_dict, tree_nodes, tree_edges, step)
