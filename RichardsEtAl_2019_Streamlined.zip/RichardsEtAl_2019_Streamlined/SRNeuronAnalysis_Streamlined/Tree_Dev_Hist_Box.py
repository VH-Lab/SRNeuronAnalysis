import matplotlib.pyplot as plot;plot.rcdefaults()
from scipy.optimize import curve_fit
from scipy.stats import poisson
from scipy.special import factorial
# from scipy.stats import distributions
import numpy as np
import matplotlib.pyplot as plot
import random
import statsmodels.api as sm
from Tree_Database_Queries import dev_graphs
WTTR_P7_values, WTTR_P12_values, WTTR_P16_values, WTTR_P21_values, WTTR_P30_values, KOTR_P7_values, KOTR_P12_values, KOTR_P16_values, KOTR_P21_values, KOTR_P30_values  = dev_graphs('mean_branch_length')

def exponential_pdf(x,pdf_lambda):
    return pdf_lambda*np.exp(-pdf_lambda*x)
def power_law_pdf(x,a,C):
    return C*np.power(x,-a)
def poisson_pmf(x,pmf_lambda):
    return (np.power(pmf_lambda,x)*np.exp(-pmf_lambda))/factorial(x)


print max(WTTR_P7_values)
print max(WTTR_P12_values)
print max(WTTR_P16_values)
print max(WTTR_P21_values)
print max(WTTR_P30_values)
print max(KOTR_P7_values)
print max(KOTR_P12_values)
print max(KOTR_P16_values)
print max(KOTR_P21_values)
print max(KOTR_P30_values)


WTTR_P7_Median=np.median(WTTR_P7_values)
WTTR_P12_Median=np.median(WTTR_P12_values)
WTTR_P16_Median=np.median(WTTR_P16_values)
WTTR_P21_Median=np.median(WTTR_P21_values)
WTTR_P30_Median=np.median(WTTR_P30_values)
KOTR_P7_Median=np.median(KOTR_P7_values)
KOTR_P12_Median=np.median(KOTR_P12_values)
KOTR_P16_Median=np.median(KOTR_P16_values)
KOTR_P21_Median=np.median(KOTR_P21_values)
KOTR_P30_Median=np.median(KOTR_P30_values)

WTTR_P7_Mean=np.mean(WTTR_P7_values)
WTTR_P12_Mean=np.mean(WTTR_P12_values)
WTTR_P16_Mean=np.mean(WTTR_P16_values)
WTTR_P21_Mean=np.mean(WTTR_P21_values)
WTTR_P30_Mean=np.mean(WTTR_P30_values)
KOTR_P7_Mean=np.mean(KOTR_P7_values)
KOTR_P12_Mean=np.mean(KOTR_P12_values)
KOTR_P16_Mean=np.mean(KOTR_P16_values)
KOTR_P21_Mean=np.mean(KOTR_P21_values)
KOTR_P30_Mean=np.mean(KOTR_P30_values)


fig,axs = plot.subplots(nrows=4, ncols=5, sharex=False)

#Plot WT Dev Graphs of Tree characteristic
#WTTR P7 Data
ax =axs[0,0]

ax.set_xlim(0,400)
ax.set_ylim(0,0.05)


ax.hist(WTTR_P7_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#B4B4B4')
ax.plot([WTTR_P7_Median,WTTR_P7_Median],[0,0.0000008], color = '#f26b47', linewidth='2')
ax.plot([WTTR_P7_Mean,WTTR_P7_Mean],[0,0.0000008], color = '#f26b47', linewidth='2', linestyle="--")

hist_values = plot.hist(WTTR_P7_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#B4B4B4')
hist_y = hist_values[0]
hist_x = hist_values[1]+((hist_values[1][1] - hist_values[1][0])/2)
hist_x = hist_x[0:-1]
print hist_y
# print hist_x

popt, pcov = curve_fit(exponential_pdf,hist_x,hist_y)
# print "popt"
# print popt
# print pcov
# print exponential_pdf(hist_x,.005)
ax.plot(hist_x,exponential_pdf(hist_x,1/WTTR_P7_Mean), color = '#f26b47', linewidth='2')

popt, pcov = curve_fit(power_law_pdf,hist_x,hist_y)
print popt
print pcov
ax.plot(hist_x,power_law_pdf(hist_x,popt[0],popt[1]), color = '#233E90', linewidth='2')

hist_x_int = [int(item) for item in hist_x]
# popt, pcov = curve_fit(poisson.pmf,hist_x_int,hist_y)
# print popt
# print "pcov"
# print pcov
ax.plot(hist_x_int, poisson.pmf(hist_x_int,WTTR_P7_Mean),color = '#233E90', linewidth='2')
print poisson.pmf(hist_x_int,1/WTTR_P7_Mean)


#WTTR P12 Data
ax =axs[0,1]

ax.set_xlim(0,400)
ax.set_ylim(0,0.05)

ax.hist(WTTR_P12_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#838383')
ax.plot([WTTR_P12_Median,WTTR_P12_Median],[0,0.0000008],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P12_Mean,WTTR_P12_Mean],[0,0.0000008], color = '#f26b47', linewidth='2', linestyle="--")

hist_values = plot.hist(WTTR_P12_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#B4B4B4')
hist_y = hist_values[0]
hist_x = hist_values[1]+((hist_values[1][1] - hist_values[1][0])/2)
hist_x = hist_x[0:-1]
# print hist_y
# print hist_x

popt, pcov = curve_fit(exponential_pdf,hist_x,hist_y)
# print "popt"
# print popt
# print pcov
# print exponential_pdf(hist_x,.005)
ax.plot(hist_x,exponential_pdf(hist_x,1/WTTR_P12_Mean), color = '#f26b47', linewidth='2')

popt, pcov = curve_fit(power_law_pdf,hist_x,hist_y)
print popt
print pcov
ax.plot(hist_x,power_law_pdf(hist_x,popt[0],popt[1]), color = '#233E90', linewidth='2')

hist_x_int = [int(item) for item in hist_x]
ax.plot(hist_x_int, poisson.pmf(hist_x_int,WTTR_P12_Mean),color = '#233E90', linewidth='2')
print "fishy"
print poisson_pmf(hist_x_int,WTTR_P12_Mean/100)

#WTTR P16 Data
ax =axs[0,2]

ax.set_xlim(0,400)
ax.set_ylim(0,0.05)


ax.hist(WTTR_P16_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#5B5B5B')
ax.plot([WTTR_P16_Median,WTTR_P16_Median],[0,0.0000008],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P16_Mean,WTTR_P16_Mean],[0,0.0000008], color = '#f26b47', linewidth='2', linestyle="--")

hist_values = plot.hist(WTTR_P16_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#B4B4B4')
hist_y = hist_values[0]
hist_x = hist_values[1]+((hist_values[1][1] - hist_values[1][0])/2)
hist_x = hist_x[0:-1]
# print hist_y
# print hist_x

popt, pcov = curve_fit(exponential_pdf,hist_x,hist_y)
# print "popt"
# print popt
# print pcov
# print exponential_pdf(hist_x,.005)
ax.plot(hist_x,exponential_pdf(hist_x,1/WTTR_P16_Mean), color = '#f26b47', linewidth='2')

popt, pcov = curve_fit(power_law_pdf,hist_x,hist_y)
# print popt
# print pcov
ax.plot(hist_x,power_law_pdf(hist_x,popt[0],popt[1]), color = '#233E90', linewidth='2')

hist_x_int = [int(item) for item in hist_x]
ax.plot(hist_x, poisson.pmf(hist_x_int,WTTR_P16_Mean),color = '#233E90', linewidth='2')

#WTTR P21 Data
ax =axs[0,3]

ax.set_xlim(0,400)
ax.set_ylim(0,0.05)


ax.hist(WTTR_P21_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#5B5B5B')
ax.plot([WTTR_P21_Median,WTTR_P21_Median],[0,0.0000008],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P21_Mean,WTTR_P21_Mean],[0,0.0000008], color = '#f26b47', linewidth='2', linestyle="--")

hist_values = plot.hist(WTTR_P21_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#B4B4B4')
hist_y = hist_values[0]
hist_x = hist_values[1]+((hist_values[1][1] - hist_values[1][0])/2)
hist_x = hist_x[0:-1]
# print hist_y
# print hist_x

popt, pcov = curve_fit(exponential_pdf,hist_x,hist_y)
# print "popt"
# print popt
# print pcov
# print exponential_pdf(hist_x,.005)
ax.plot(hist_x,exponential_pdf(hist_x,1/WTTR_P21_Mean), color = '#f26b47', linewidth='2')

popt, pcov = curve_fit(power_law_pdf,hist_x,hist_y)
# print popt
# print pcov
ax.plot(hist_x,power_law_pdf(hist_x,popt[0],popt[1]), color = '#233E90', linewidth='2')

hist_x_int = [int(item) for item in hist_x]
ax.plot(hist_x, poisson.pmf(hist_x_int,WTTR_P21_Mean),color = '#233E90', linewidth='2')

#WTTR P30 Data
ax =axs[0,4]

ax.set_xlim(0,400)
ax.set_ylim(0,0.05)

ax.hist(WTTR_P30_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#0d0d0d')
ax.plot([WTTR_P30_Median,WTTR_P30_Median],[0,0.0000008],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P30_Mean,WTTR_P30_Mean],[0,0.0000008], color = '#f26b47', linewidth='2', linestyle="--")

hist_values = plot.hist(WTTR_P30_values, 30, normed=1, alpha=0.5, label='WT P7 TR',color='#B4B4B4')
hist_y = hist_values[0]
hist_x = hist_values[1]+((hist_values[1][1] - hist_values[1][0])/2)
hist_x = hist_x[0:-1]
# print hist_y
# print hist_x

popt, pcov = curve_fit(exponential_pdf,hist_x,hist_y)
# print "popt"
# print popt
# print pcov
# print exponential_pdf(hist_x,.005)
ax.plot(hist_x,exponential_pdf(hist_x,1/WTTR_P30_Mean), color = '#f26b47', linewidth='2')

popt, pcov = curve_fit(power_law_pdf,hist_x,hist_y)
# print popt
# print pcov
ax.plot(hist_x,power_law_pdf(hist_x,popt[0],popt[1]), color = '#233E90', linewidth='2')

hist_x_int = [int(item) for item in hist_x]
ax.plot(hist_x, poisson.pmf(hist_x_int,WTTR_P30_Mean),color = '#233E90', linewidth='2')

#Plot P7 boxplot
ax =axs[1,0]
ax.set_xlim(0,400)
ax.set_ylim(5,10)
WTTR_data = WTTR_P7_values
data=(WTTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=1.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#B4B4B4','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

#Plot P12 boxplot
ax =axs[1,1]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
WTTR_data = WTTR_P12_values
data=(WTTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=1.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#838383','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

#Plot P16 boxplot
ax =axs[1,2]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
WTTR_data = WTTR_P16_values
data=(WTTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=1.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#5B5B5B','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)


#Plot P21 boxplot
ax =axs[1,3]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
WTTR_data = WTTR_P21_values
data=(WTTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=1.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#5B5B5B','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)


#Plot P30 boxplot
ax =axs[1,4]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
WTTR_data = WTTR_P30_values
data=(WTTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=1.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#0d0d0d','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)


#Plot KO Dev Graphs of Tree characteristic
#KOTR P7 Data
ax =axs[2,0]
ax.set_xlim(0,400)
ax.set_ylim(0,0.05)

bins = np.linspace(0, 3000, 50)
ax.hist(KOTR_P7_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P7_Median,KOTR_P7_Median],[0,0.0000008], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P7_Mean,KOTR_P7_Mean],[0,0.0000008], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P12 Data
ax =axs[2,1]
ax.set_xlim(0,400)
ax.set_ylim(0,0.05)

bins = np.linspace(0, 3000, 50)
ax.hist(KOTR_P12_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P12_Median,KOTR_P12_Median],[0,0.0000008], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P12_Mean,KOTR_P12_Mean],[0,0.0000008], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P16 Data
ax =axs[2,2]
ax.set_xlim(0,400)
ax.set_ylim(0,0.05)

bins = np.linspace(0, 3000, 50)
ax.hist(KOTR_P16_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P16_Median,KOTR_P16_Median],[0,0.0000008], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P16_Mean,KOTR_P16_Mean],[0,0.0000008], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P21 Data
ax =axs[2,3]
ax.set_xlim(0,400)
ax.set_ylim(0,0.05)

bins = np.linspace(0, 3000, 50)
ax.hist(KOTR_P21_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P21_Median,KOTR_P21_Median],[0,0.0000008], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P21_Mean,KOTR_P21_Mean],[0,0.0000008], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P30 Data
ax =axs[2,4]
ax.set_xlim(0,400)
ax.set_ylim(0,0.05)

bins = np.linspace(0, 3000, 50)
ax.hist(KOTR_P30_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P30_Median,KOTR_P30_Median],[0,0.0000008], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P30_Mean,KOTR_P30_Mean],[0,0.0000008], color = '#E0AF25', linewidth='2', linestyle="--")

#Plot KO Boxplots
#Plot P7 boxplot
ax =axs[3,0]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
KOTR_data = KOTR_P7_values
data=(KOTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#0d0d0d','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

#Plot P12 boxplot
ax =axs[3,1]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
KOTR_data = KOTR_P12_values
data=(KOTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#0d0d0d','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)

#Plot P16 boxplot
ax =axs[3,2]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
KOTR_data = KOTR_P16_values
data=(KOTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#0d0d0d','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)


#Plot P21 boxplot
ax =axs[3,3]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
KOTR_data = KOTR_P21_values
data=(KOTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#0d0d0d','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)


#Plot P30 boxplot
ax =axs[3,4]
ax.set_xlim(0,400)
ax.set_ylim(0,10)
KOTR_data = KOTR_P30_values
data=(KOTR_data)

boxprops = dict(linestyle='-', linewidth=0, color ='none',facecolor=('#035069'))
flierprops = dict(marker='o', markerfacecolor='#E0B104', markersize=4,markeredgecolor='none')
medianprops = dict(linestyle='-', linewidth=2.5, color='white')
whiskerprops=dict(linestyle='-',color='#666666',linewidth=2)
capprops= dict(linewidth=2,color='#666666')

box=ax.boxplot(data, patch_artist=True, sym='o',boxprops=boxprops, flierprops=flierprops,medianprops=medianprops, whiskerprops=whiskerprops,capprops=capprops, vert=False)
colors = ['#0d0d0d','#035069']
for patch, color in zip(box['boxes'], colors):
    patch.set_facecolor(color)






plot.show()


