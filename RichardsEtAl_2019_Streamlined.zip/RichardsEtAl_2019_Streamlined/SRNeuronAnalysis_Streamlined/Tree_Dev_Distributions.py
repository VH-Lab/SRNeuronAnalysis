import matplotlib.pyplot as plot;plot.rcdefaults()
import numpy as np
import matplotlib.pyplot as plot
import random
import statsmodels.api as sm
from Tree_Database_Queries import dev_graphs
WTTR_P7_values, WTTR_P12_values, WTTR_P16_values, WTTR_P21_values, WTTR_P30_values, KOTR_P7_values, KOTR_P12_values, KOTR_P16_values, KOTR_P21_values, KOTR_P30_values  = dev_graphs('tree_len')

WTTR_P7_Median=np.median(WTTR_P7_values)
WTTR_P12_Median=np.median(WTTR_P12_values)
WTTR_P16_Median=np.median(WTTR_P16_values)
WTTR_P21_Median=np.median(WTTR_P21_values)
WTTR_P30_Median=np.median(WTTR_P30_values)
KOTR_P7_Median=np.median(KOTR_P7_values)
KOTR_P12_Median=np.median(KOTR_P12_values)
KOTR_P16_Median=np.median(KOTR_P16_values)
KOTR_P21_Median=np.median(KOTR_P21_values)
KOTR_P30_Median=np.median(KOTR_P30_values)

WTTR_P7_Mean=np.mean(WTTR_P7_values)
WTTR_P12_Mean=np.mean(WTTR_P12_values)
WTTR_P16_Mean=np.mean(WTTR_P16_values)
WTTR_P21_Mean=np.mean(WTTR_P21_values)
WTTR_P30_Mean=np.mean(WTTR_P30_values)
KOTR_P7_Mean=np.mean(KOTR_P7_values)
KOTR_P12_Mean=np.mean(KOTR_P12_values)
KOTR_P16_Mean=np.mean(KOTR_P16_values)
KOTR_P21_Mean=np.mean(KOTR_P21_values)
KOTR_P30_Mean=np.mean(KOTR_P30_values)


fig,axs = plot.subplots(nrows=3, ncols=5, sharex=False)

#Plot WT Dev Graphs of Tree characteristic
#WTTR P7 Data
ax =axs[0,0]

bins = np.linspace(0, 500, 50)
ax.hist(WTTR_P7_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#0d0d0d')
ax.plot([WTTR_P7_Median,WTTR_P7_Median],[0,0.01], color = '#f26b47', linewidth='2')
ax.plot([WTTR_P7_Mean,WTTR_P7_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")


#WTTR P12 Data
ax =axs[0,1]

bins = np.linspace(0, 500, 50)
ax.hist(WTTR_P12_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#0d0d0d')
ax.plot([WTTR_P12_Median,WTTR_P12_Median],[0,0.01],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P12_Mean,WTTR_P12_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")

#WTTR P16 Data
ax =axs[0,2]

bins = np.linspace(0, 500, 50)
ax.hist(WTTR_P16_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#0d0d0d')
ax.plot([WTTR_P16_Median,WTTR_P16_Median],[0,0.01],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P16_Mean,WTTR_P16_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")

#WTTR P21 Data
ax =axs[0,3]

bins = np.linspace(0, 500, 50)
ax.hist(WTTR_P21_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#0d0d0d')
ax.plot([WTTR_P21_Median,WTTR_P21_Median],[0,0.01],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P21_Mean,WTTR_P21_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")

#WTTR P30 Data
ax =axs[0,4]

bins = np.linspace(0, 500, 50)
ax.hist(WTTR_P30_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#0d0d0d')
ax.plot([WTTR_P30_Median,WTTR_P30_Median],[0,0.01],color = '#f26b47', linewidth='2')
ax.plot([WTTR_P30_Mean,WTTR_P30_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")


#Plot KO Dev Graphs of Tree characteristic
#KOTR P7 Data
ax =axs[1,0]

bins = np.linspace(0, 500, 50)
ax.hist(KOTR_P7_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P7_Median,KOTR_P7_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P7_Mean,KOTR_P7_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P12 Data
ax =axs[1,1]

bins = np.linspace(0, 500, 50)
ax.hist(KOTR_P12_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P12_Median,KOTR_P12_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P12_Mean,KOTR_P12_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P16 Data
ax =axs[1,2]

bins = np.linspace(0, 500, 50)
ax.hist(KOTR_P16_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P16_Median,KOTR_P16_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P16_Mean,KOTR_P16_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P21 Data
ax =axs[1,3]

bins = np.linspace(0, 500, 50)
ax.hist(KOTR_P21_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P21_Median,KOTR_P21_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P21_Mean,KOTR_P21_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

#KOTR P30 Data
ax =axs[1,4]

bins = np.linspace(0, 500, 50)
ax.hist(KOTR_P30_values, bins, normed=1, alpha=0.5, label='WT P7 TR',color='#289498')
ax.plot([KOTR_P30_Median,KOTR_P30_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([KOTR_P30_Mean,KOTR_P30_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

#Plot WT*KO Graphs
# P7
ax =axs[2,0]

bins = np.linspace(0, 500, 50)

ax.hist(WTTR_P7_values, bins, normed=1,alpha=0.5, label='WT TR',color='#0d0d0d')
ax.hist(KOTR_P7_values, bins, normed=1,alpha=0.5, label='WT DR',color='#289498')
ax.plot([WTTR_P7_Median,WTTR_P7_Median],[0,0.01], color = '#f26b47', linewidth='2')
ax.plot([KOTR_P7_Median,KOTR_P7_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([WTTR_P7_Mean,WTTR_P7_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")
ax.plot([KOTR_P7_Mean,KOTR_P7_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

# P12
ax =axs[2,1]

bins = np.linspace(0, 500, 50)

ax.hist(WTTR_P12_values, bins, normed=1,alpha=0.5, label='WT TR',color='#0d0d0d')
ax.hist(KOTR_P12_values, bins, normed=1,alpha=0.5, label='WT DR',color='#289498')
ax.plot([WTTR_P12_Median,WTTR_P12_Median],[0,0.01], color = '#f26b47', linewidth='2')
ax.plot([KOTR_P12_Median,KOTR_P12_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([WTTR_P12_Mean,WTTR_P12_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")
ax.plot([KOTR_P12_Mean,KOTR_P12_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

# P16
ax =axs[2,2]

bins = np.linspace(0, 500, 50)

ax.hist(WTTR_P16_values, bins, normed=1,alpha=0.5, label='WT TR',color='#0d0d0d')
ax.hist(KOTR_P16_values, bins, normed=1,alpha=0.5, label='WT DR',color='#289498')
ax.plot([WTTR_P16_Median,WTTR_P16_Median],[0,0.01], color = '#f26b47', linewidth='2')
ax.plot([KOTR_P16_Median,KOTR_P16_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([WTTR_P16_Mean,WTTR_P16_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")
ax.plot([KOTR_P16_Mean,KOTR_P16_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

# P21
ax =axs[2,3]

bins = np.linspace(0, 500, 50)

ax.hist(WTTR_P21_values, bins, normed=1,alpha=0.5, label='WT TR',color='#0d0d0d')
ax.hist(KOTR_P21_values, bins, normed=1,alpha=0.5, label='WT DR',color='#289498')
ax.plot([WTTR_P21_Median,WTTR_P21_Median],[0,0.01], color = '#f26b47', linewidth='2')
ax.plot([KOTR_P21_Median,KOTR_P21_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([WTTR_P21_Mean,WTTR_P21_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")
ax.plot([KOTR_P21_Mean,KOTR_P21_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")

# P30
ax =axs[2,4]

bins = np.linspace(0, 500, 50)

ax.hist(WTTR_P30_values, bins, normed=1,alpha=0.5, label='WT TR',color='#0d0d0d')
ax.hist(KOTR_P30_values, bins, normed=1,alpha=0.5, label='WT DR',color='#289498')
ax.plot([WTTR_P21_Median,WTTR_P21_Median],[0,0.01], color = '#f26b47', linewidth='2')
ax.plot([KOTR_P30_Median,KOTR_P30_Median],[0,0.01], color = '#E0AF25', linewidth='2')
ax.plot([WTTR_P30_Mean,WTTR_P30_Mean],[0,0.01], color = '#f26b47', linewidth='2', linestyle="--")
ax.plot([KOTR_P30_Mean,KOTR_P30_Mean],[0,0.01], color = '#E0AF25', linewidth='2', linestyle="--")


plot.show()


