import math
import matplotlib.pyplot as plot;plot.rcdefaults()
import scipy
from scipy import stats
import numpy as np
import matplotlib.pyplot as plot
import statsmodels.api as sm
from random import *
from Database_Queries import dev_graphs

ArborLen_WTTR_P7_values, ArborLen_WTTR_P12_values, ArborLen_WTTR_P16_values, ArborLen_WTTR_P21_values, ArborLen_WTTR_P30_values, \
ArborLen_KOTR_P7_values, ArborLen_KOTR_P12_values, ArborLen_KOTR_P16_values, ArborLen_KOTR_P21_values, ArborLen_KOTR_P30_values, \
ArborLen_WTDD_P16_values, ArborLen_WTDD_P21_values, ArborLen_WTDD_P30_values, ArborLen_KODD_P16_values, ArborLen_KODD_P21_values, ArborLen_KODD_P30_values = dev_graphs('arbor_length')

SegLen_WTTR_P7_values, SegLen_WTTR_P12_values, SegLen_WTTR_P16_values, SegLen_WTTR_P21_values, SegLen_WTTR_P30_values, \
SegLen_KOTR_P7_values, SegLen_KOTR_P12_values, SegLen_KOTR_P16_values, SegLen_KOTR_P21_values, SegLen_KOTR_P30_values, \
SegLen_WTDD_P16_values, SegLen_WTDD_P21_values, SegLen_WTDD_P30_values, SegLen_KODD_P16_values, SegLen_KODD_P21_values, SegLen_KODD_P30_values   = dev_graphs('mean_branch_length')

SegNum_WTTR_P7_values, SegNum_WTTR_P12_values, SegNum_WTTR_P16_values, SegNum_WTTR_P21_values, SegNum_WTTR_P30_values, \
SegNum_KOTR_P7_values, SegNum_KOTR_P12_values, SegNum_KOTR_P16_values, SegNum_KOTR_P21_values, SegNum_KOTR_P30_values, \
SegNum_WTDD_P16_values, SegNum_WTDD_P21_values, SegNum_WTDD_P30_values, SegNum_KODD_P16_values, SegNum_KODD_P21_values, SegNum_KODD_P30_values = dev_graphs('branch_number')

PathLen_WTTR_P7_values, PathLen_WTTR_P12_values, PathLen_WTTR_P16_values, PathLen_WTTR_P21_values, PathLen_WTTR_P30_values, \
PathLen_KOTR_P7_values, PathLen_KOTR_P12_values, PathLen_KOTR_P16_values, PathLen_KOTR_P21_values, PathLen_KOTR_P30_values, \
PathLen_WTDD_P16_values, PathLen_WTDD_P21_values, PathLen_WTDD_P30_values, PathLen_KODD_P16_values, PathLen_KODD_P21_values, PathLen_KODD_P30_values = dev_graphs('mean_path_length')

TipNum_WTTR_P7_values, TipNum_WTTR_P12_values, TipNum_WTTR_P16_values, TipNum_WTTR_P21_values, TipNum_WTTR_P30_values, \
TipNum_KOTR_P7_values, TipNum_KOTR_P12_values, TipNum_KOTR_P16_values, TipNum_KOTR_P21_values, TipNum_KOTR_P30_values, \
TipNum_WTDD_P16_values, TipNum_WTDD_P21_values, TipNum_WTDD_P30_values, TipNum_KODD_P16_values, TipNum_KODD_P21_values, TipNum_KODD_P30_values = dev_graphs('tip_number')

Tort_WTTR_P7_values, Tort_WTTR_P12_values, Tort_WTTR_P16_values, Tort_WTTR_P21_values, Tort_WTTR_P30_values, \
Tort_KOTR_P7_values, Tort_KOTR_P12_values, Tort_KOTR_P16_values, Tort_KOTR_P21_values, Tort_KOTR_P30_values, \
Tort_WTDD_P16_values, Tort_WTDD_P21_values, Tort_WTDD_P30_values, Tort_KODD_P16_values, Tort_KODD_P21_values, Tort_KODD_P30_values = dev_graphs('mean_tortuosity')

Intersections_WTTR_P7_values, Intersections_WTTR_P12_values, Intersections_WTTR_P16_values, Intersections_WTTR_P21_values, Intersections_WTTR_P30_values, \
Intersections_KOTR_P7_values, Intersections_KOTR_P12_values, Intersections_KOTR_P16_values, Intersections_KOTR_P21_values, Intersections_KOTR_P30_values, \
Intersections_WTDD_P16_values, Intersections_WTDD_P21_values, Intersections_WTDD_P30_values, Intersections_KODD_P16_values, Intersections_KODD_P21_values, Intersections_KODD_P30_values = dev_graphs('intersections')
# 
# ArborLen_WTTR_P7_values = ([math.log10(float(item))for item in ArborLen_WTTR_P7_values])
# ArborLen_WTTR_P12_values = ([math.log10(float(item))for item in ArborLen_WTTR_P12_values])
# ArborLen_WTTR_P16_values = ([math.log10(float(item))for item in ArborLen_WTTR_P16_values])
# ArborLen_WTTR_P21_values = ([math.log10(float(item))for item in ArborLen_WTTR_P21_values])
# ArborLen_WTTR_P30_values = ([math.log10(float(item))for item in ArborLen_WTTR_P30_values])
# 
# ArborLen_KOTR_P7_values = ([math.log10(float(item))for item in ArborLen_KOTR_P7_values])
# ArborLen_KOTR_P12_values = ([math.log10(float(item))for item in ArborLen_KOTR_P12_values])
# ArborLen_KOTR_P16_values = ([math.log10(float(item))for item in ArborLen_KOTR_P16_values])
# ArborLen_KOTR_P21_values = ([math.log10(float(item))for item in ArborLen_KOTR_P21_values])
# ArborLen_KOTR_P30_values = ([math.log10(float(item))for item in ArborLen_KOTR_P30_values])
# 
# SegNum_WTTR_P7_values = [math.log10(float(item)) for item in SegNum_WTTR_P7_values]
# SegNum_WTTR_P12_values = [math.log10(float(item)) for item in SegNum_WTTR_P12_values]
# SegNum_WTTR_P16_values = [math.log10(float(item)) for item in SegNum_WTTR_P16_values]
# SegNum_WTTR_P21_values = [math.log10(float(item)) for item in SegNum_WTTR_P21_values]
# SegNum_WTTR_P30_values = [math.log10(float(item)) for item in SegNum_WTTR_P30_values]
# 
# SegNum_KOTR_P7_values = [math.log10(float(item)) for item in SegNum_KOTR_P7_values]
# SegNum_KOTR_P12_values = [math.log10(float(item)) for item in SegNum_KOTR_P12_values]
# SegNum_KOTR_P16_values = [math.log10(float(item)) for item in SegNum_KOTR_P16_values]
# SegNum_KOTR_P21_values = [math.log10(float(item)) for item in SegNum_KOTR_P21_values]
# SegNum_KOTR_P30_values = [math.log10(float(item)) for item in SegNum_KOTR_P30_values]

# print len(Tort_WTTR_P12_values)
# print Tort_WTTR_P12_values
Tort_WTTR_P12_values = Tort_WTTR_P12_values[0:37] + Tort_WTTR_P12_values[38:44]
# print Tort_WTTR_P12_values
# print len(Tort_WTTR_P12_values)
SegNum_WTTR_P12_values = SegNum_WTTR_P12_values[0:37] + SegNum_WTTR_P12_values[38:44]
SegLen_WTTR_P12_values = SegLen_WTTR_P12_values[0:37] + SegLen_WTTR_P12_values[38:44]
ArborLen_WTTR_P12_values = ArborLen_WTTR_P12_values[0:37] + ArborLen_WTTR_P12_values[38:44]
TipNum_WTTR_P12_values = TipNum_WTTR_P12_values[0:37] + TipNum_WTTR_P12_values[38:44]
PathLen_WTTR_P12_values = PathLen_WTTR_P12_values[0:37] + PathLen_WTTR_P12_values[38:44]

ArborLen_WTTR_P7_values = stats.zscore(ArborLen_WTTR_P7_values)
ArborLen_WTTR_P12_values = stats.zscore(ArborLen_WTTR_P12_values)
ArborLen_WTTR_P16_values = stats.zscore(ArborLen_WTTR_P16_values)
ArborLen_WTTR_P21_values = stats.zscore(ArborLen_WTTR_P21_values)
ArborLen_WTTR_P30_values = stats.zscore(ArborLen_WTTR_P30_values)
ArborLen_KOTR_P7_values = stats.zscore(ArborLen_KOTR_P7_values)
ArborLen_KOTR_P12_values = stats.zscore(ArborLen_KOTR_P12_values)
ArborLen_KOTR_P16_values = stats.zscore(ArborLen_KOTR_P16_values)
ArborLen_KOTR_P21_values = stats.zscore(ArborLen_KOTR_P21_values)
ArborLen_KOTR_P30_values = stats.zscore(ArborLen_KOTR_P30_values)
WTTR_ArborLen = np.concatenate((ArborLen_WTTR_P7_values,ArborLen_WTTR_P12_values,ArborLen_WTTR_P16_values,ArborLen_WTTR_P21_values,ArborLen_WTTR_P30_values),axis=0)
# print len(WTTR_ArborLen)

SegNum_WTTR_P7_values = stats.zscore(SegNum_WTTR_P7_values)
SegNum_WTTR_P12_values = stats.zscore(SegNum_WTTR_P12_values)
SegNum_WTTR_P16_values = stats.zscore(SegNum_WTTR_P16_values)
SegNum_WTTR_P21_values = stats.zscore(SegNum_WTTR_P21_values)
SegNum_WTTR_P30_values = stats.zscore(SegNum_WTTR_P30_values)
SegNum_KOTR_P7_values = stats.zscore(SegNum_KOTR_P7_values)
SegNum_KOTR_P12_values = stats.zscore(SegNum_KOTR_P12_values)
SegNum_KOTR_P16_values = stats.zscore(SegNum_KOTR_P16_values)
SegNum_KOTR_P21_values = stats.zscore(SegNum_KOTR_P21_values)
SegNum_KOTR_P30_values = stats.zscore(SegNum_KOTR_P30_values)
WTTR_SegNum = np.concatenate((SegNum_WTTR_P7_values,SegNum_WTTR_P12_values,SegNum_WTTR_P16_values,SegNum_WTTR_P21_values,SegNum_WTTR_P30_values),axis=0)
KOTR_SegNum = np.concatenate((SegNum_KOTR_P7_values,SegNum_KOTR_P12_values,SegNum_KOTR_P16_values,SegNum_KOTR_P21_values,SegNum_KOTR_P30_values),axis=0)
print len(WTTR_SegNum)

SegLen_WTTR_P7_values = stats.zscore(SegLen_WTTR_P7_values)
SegLen_WTTR_P12_values = stats.zscore(SegLen_WTTR_P12_values)
SegLen_WTTR_P16_values = stats.zscore(SegLen_WTTR_P16_values)
SegLen_WTTR_P21_values = stats.zscore(SegLen_WTTR_P21_values)
SegLen_WTTR_P30_values = stats.zscore(SegLen_WTTR_P30_values)
SegLen_KOTR_P7_values = stats.zscore(SegLen_KOTR_P7_values)
SegLen_KOTR_P12_values = stats.zscore(SegLen_KOTR_P12_values)
SegLen_KOTR_P16_values = stats.zscore(SegLen_KOTR_P16_values)
SegLen_KOTR_P21_values = stats.zscore(SegLen_KOTR_P21_values)
SegLen_KOTR_P30_values = stats.zscore(SegLen_KOTR_P30_values)
WTTR_SegLen = np.concatenate((SegLen_WTTR_P7_values,SegLen_WTTR_P12_values,SegLen_WTTR_P16_values,SegLen_WTTR_P21_values,SegLen_WTTR_P30_values),axis=0)
# print len(WTTR_SegLen)


PathLen_WTTR_P7_values = stats.zscore(PathLen_WTTR_P7_values)
PathLen_WTTR_P12_values = stats.zscore(PathLen_WTTR_P12_values)
PathLen_WTTR_P16_values = stats.zscore(PathLen_WTTR_P16_values)
PathLen_WTTR_P21_values = stats.zscore(PathLen_WTTR_P21_values)
PathLen_WTTR_P30_values = stats.zscore(PathLen_WTTR_P30_values)
PathLen_KOTR_P7_values = stats.zscore(PathLen_KOTR_P7_values)
PathLen_KOTR_P12_values = stats.zscore(PathLen_KOTR_P12_values)
PathLen_KOTR_P16_values = stats.zscore(PathLen_KOTR_P16_values)
PathLen_KOTR_P21_values = stats.zscore(PathLen_KOTR_P21_values)
PathLen_KOTR_P30_values = stats.zscore(PathLen_KOTR_P30_values)
WTTR_PathLen = np.concatenate((PathLen_WTTR_P7_values,PathLen_WTTR_P12_values,PathLen_WTTR_P16_values,PathLen_WTTR_P21_values,PathLen_WTTR_P30_values),axis=0)
# print len(WTTR_PathLen)


TipNum_WTTR_P7_values = stats.zscore(TipNum_WTTR_P7_values)
TipNum_WTTR_P12_values = stats.zscore(TipNum_WTTR_P12_values)
TipNum_WTTR_P16_values = stats.zscore(TipNum_WTTR_P16_values)
TipNum_WTTR_P21_values = stats.zscore(TipNum_WTTR_P21_values)
TipNum_WTTR_P30_values = stats.zscore(TipNum_WTTR_P30_values)
TipNum_KOTR_P7_values = stats.zscore(TipNum_KOTR_P7_values)
TipNum_KOTR_P12_values = stats.zscore(TipNum_KOTR_P12_values)
TipNum_KOTR_P16_values = stats.zscore(TipNum_KOTR_P16_values)
TipNum_KOTR_P21_values = stats.zscore(TipNum_KOTR_P21_values)
TipNum_KOTR_P30_values = stats.zscore(TipNum_KOTR_P30_values)
WTTR_TipNum = np.concatenate((TipNum_WTTR_P7_values,TipNum_WTTR_P12_values,TipNum_WTTR_P16_values,TipNum_WTTR_P21_values,TipNum_WTTR_P30_values),axis=0)
# print len(WTTR_TipNum)


Tort_WTTR_P7_values = stats.zscore(Tort_WTTR_P7_values)
Tort_WTTR_P12_values = stats.zscore(Tort_WTTR_P12_values)
Tort_WTTR_P16_values = stats.zscore(Tort_WTTR_P16_values)
Tort_WTTR_P21_values = stats.zscore(Tort_WTTR_P21_values)
Tort_WTTR_P30_values = stats.zscore(Tort_WTTR_P30_values)
Tort_KOTR_P7_values = stats.zscore(Tort_KOTR_P7_values)
Tort_KOTR_P12_values = stats.zscore(Tort_KOTR_P12_values)
Tort_KOTR_P16_values = stats.zscore(Tort_KOTR_P16_values)
Tort_KOTR_P21_values = stats.zscore(Tort_KOTR_P21_values)
Tort_KOTR_P30_values = stats.zscore(Tort_KOTR_P30_values)
WTTR_Tort = np.concatenate((Tort_WTTR_P7_values,Tort_WTTR_P12_values,Tort_WTTR_P16_values,Tort_WTTR_P21_values,Tort_WTTR_P30_values),axis=0)
# print len(WTTR_Tort)


Intersections_WTTR_P7_values = stats.zscore(Intersections_WTTR_P7_values)
Intersections_WTTR_P12_values = stats.zscore(Intersections_WTTR_P12_values)
Intersections_WTTR_P16_values = stats.zscore(Intersections_WTTR_P16_values)
Intersections_WTTR_P21_values = stats.zscore(Intersections_WTTR_P21_values)
Intersections_WTTR_P30_values = stats.zscore(Intersections_WTTR_P30_values)
Intersections_KOTR_P7_values = stats.zscore(Intersections_KOTR_P7_values)
Intersections_KOTR_P12_values = stats.zscore(Intersections_KOTR_P12_values)
Intersections_KOTR_P16_values = stats.zscore(Intersections_KOTR_P16_values)
Intersections_KOTR_P21_values = stats.zscore(Intersections_KOTR_P21_values)
Intersections_KOTR_P30_values = stats.zscore(Intersections_KOTR_P30_values)
WTTR_Intersections = np.concatenate((Intersections_WTTR_P7_values,Intersections_WTTR_P12_values,Intersections_WTTR_P16_values,Intersections_WTTR_P21_values,Intersections_WTTR_P30_values),axis=0)
KOTR_Intersections = np.concatenate((Intersections_KOTR_P7_values,Intersections_KOTR_P12_values,Intersections_KOTR_P16_values,Intersections_KOTR_P21_values,Intersections_KOTR_P30_values),axis=0)
print len(WTTR_Intersections)
#Get R2 value
# print ' WT Seg Num X Intersections'
# r_squared = stats.pearsonr(WTTR_Intersections, WTTR_SegNum)
# print r_squared
#
# print ' KO Seg Num X Intersections'
# r_squared = stats.pearsonr(KOTR_Intersections, KOTR_SegNum)
# print r_squared



#Make Blank Figure
fig,axs = plot.subplots(nrows=6, ncols=3, sharex=True, sharey=True)

#Plot Tree Length by Branch Number.
#Colorcoded by Age
#WT
ax=axs[0,0]

ax.set_ylim(-6,6)
ax.set_xlim(-6,6)

ax.scatter(ArborLen_WTTR_P7_values,SegNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P12_values,SegNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P16_values,SegNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P21_values,SegNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P30_values,SegNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('ArborLen')
ax.set_ylabel('SegNum')

#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Get R2 value
print 'Arbor Len X Seg Num'
r_squared = stats.pearsonr(WTTR_ArborLen, WTTR_SegNum)
print r_squared

#KO
ax=axs[0,2]
ax.scatter(ArborLen_WTTR_P7_values,SegNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P12_values,SegNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P16_values,SegNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P21_values,SegNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P30_values,SegNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(ArborLen_KOTR_P7_values,SegNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P12_values,SegNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P16_values,SegNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P21_values,SegNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P30_values,SegNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('ArborLen')
ax.set_ylabel('SegNum')

#Plot Unity Line
ax.plot([-6,6],[-6,6])

#WT and KO
ax=axs[0,1]
ax.scatter(ArborLen_KOTR_P7_values,SegNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P12_values,SegNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P16_values,SegNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P21_values,SegNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P30_values,SegNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('ArborLen')
ax.set_ylabel('SegNum')

#Plot Unity Line
ax.plot([-6,6],[-6,6])



#Plot Tree Length by Branch_Length.
#Colorcoded by Age
#WT
ax=axs[5,0]
ax.scatter(ArborLen_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('ArborLen')
ax.set_ylabel('SegLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Get R2 value
print 'Arbor Len X Seg Len'
r_squared = stats.pearsonr(WTTR_ArborLen, WTTR_SegLen)
print r_squared

#KO
ax=axs[5,1]
ax.scatter(ArborLen_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('ArborLen')
ax.set_ylabel('SegLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Wt and KO Data
ax=axs[5,2]
ax.scatter(ArborLen_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(ArborLen_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(ArborLen_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('ArborLen')
ax.set_ylabel('SegLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

# #Plot Tree Length by Path Length
# #Colorcoded by Age
# #WT
# ax=axs[2,0]
# ax.scatter(ArborLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('PathLen')
#
# #KO
# ax=axs[2,1]
# ax.scatter(ArborLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('PathLen')
#
# #Wt and KO Data
# ax=axs[2,2]
# ax.scatter(ArborLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(ArborLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('PathLen')
#
# #Plot Tree Length by Tip number
# #WT
# ax=axs[3,0]
# ax.scatter(ArborLen_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('TipNum')
#
# #KO
# ax=axs[3,1]
# ax.scatter(ArborLen_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('TipNum')
#
# #Wt and KO Data
# ax=axs[3,2]
# ax.scatter(ArborLen_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(ArborLen_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('TipNum')
#
# #Plot Tree Length by Tortuosity
# #WT
# ax=axs[4,0]
# ax.scatter(ArborLen_WTTR_P7_values,Tort_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P12_values,Tort_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P16_values,Tort_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P21_values,Tort_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P30_values,Tort_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('Tort')
#
# #KO
# ax=axs[4,1]
# ax.scatter(ArborLen_KOTR_P7_values,Tort_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P12_values,Tort_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P16_values,Tort_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P21_values,Tort_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P30_values,Tort_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('Tort')
#
# #Wt and KO Data
# ax=axs[4,2]
# ax.scatter(ArborLen_WTTR_P7_values,Tort_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P12_values,Tort_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P16_values,Tort_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P21_values,Tort_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_WTTR_P30_values,Tort_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(ArborLen_KOTR_P7_values,Tort_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P12_values,Tort_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P16_values,Tort_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P21_values,Tort_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(ArborLen_KOTR_P30_values,Tort_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('ArborLen')
# ax.set_ylabel('Tort')

#Plot Branch Number by Tip Number
#WT
ax=axs[1,0]
ax.scatter(SegNum_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('SegNum')
ax.set_ylabel('TipNum')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Get R2 value
print 'Seg Num X Tip Num'
r_squared = stats.pearsonr(WTTR_SegNum, WTTR_TipNum)
print r_squared

# #KO
ax=axs[1,1]
ax.scatter(SegNum_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('TipNum')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Wt and KO Data
ax=axs[1,2]
ax.scatter(SegNum_WTTR_P7_values,TipNum_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,TipNum_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,TipNum_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,TipNum_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,TipNum_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(SegNum_KOTR_P7_values,TipNum_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,TipNum_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,TipNum_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,TipNum_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,TipNum_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('TipNum')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Plot Branch Number by Branch Length
#WT
ax=axs[2,0]
ax.scatter(SegNum_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('SegNum')
ax.set_ylabel('SegLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

print 'Seg Num X SegLen'
r_squared = stats.pearsonr(WTTR_SegNum, WTTR_SegLen)
print r_squared

#KO
ax=axs[2,1]
ax.scatter(SegNum_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('SegLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Wt and KO Data
ax=axs[2,2]
ax.scatter(SegNum_WTTR_P7_values,SegLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P12_values,SegLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P16_values,SegLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P21_values,SegLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_WTTR_P30_values,SegLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(SegNum_KOTR_P7_values,SegLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P12_values,SegLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P16_values,SegLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P21_values,SegLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegNum_KOTR_P30_values,SegLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegNum')
ax.set_ylabel('SegLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

# #Plot Tip Number by Path Length
# #WT
# ax=axs[2,0]
# ax.scatter(TipNum_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# #Plot Unity Line
# # ax.plot([0,5000],[5000,50])
#
# ax.set_xlabel('TipNum')
# ax.set_ylabel('PathLen')
#
# #KO
# ax=axs[7,1]
# ax.scatter(TipNum_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TipNum')
# ax.set_ylabel('PathLen')
#
# #Wt and KO Data
# ax=axs[7,2]
# ax.scatter(TipNum_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.scatter(TipNum_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
# ax.scatter(TipNum_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)
#
# ax.set_xlabel('TipNum')
# ax.set_ylabel('PathLen')

#Plot Path Length by Tortuosity
#WT
ax=axs[3,0]
ax.scatter(Tort_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('Tort')
ax.set_ylabel('PathLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

print 'Tort X PathLen'
r_squared = stats.pearsonr(WTTR_Tort, WTTR_PathLen)
print r_squared

#KO
ax=axs[3,1]
ax.scatter(Tort_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('Tort')
ax.set_ylabel('PathLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Wt and KO Data
ax=axs[3,2]
ax.scatter(Tort_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(Tort_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(Tort_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('Tort')
ax.set_ylabel('PathLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Plot Path Length by Segment Length
#WT
ax=axs[4,0]
ax.scatter(SegLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

#Plot Unity Line
# ax.plot([0,5000],[5000,50])

ax.set_xlabel('SegLen')
ax.set_ylabel('PathLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

print 'Seg Len X Path Len'
r_squared = stats.pearsonr(WTTR_SegLen, WTTR_PathLen)
print r_squared

#KO
ax=axs[4,1]
ax.scatter(SegLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegLen')
ax.set_ylabel('PathLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

#Wt and KO Data
ax=axs[4,2]
ax.scatter(SegLen_WTTR_P7_values,PathLen_WTTR_P7_values, color = '#B4B4B4',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P12_values,PathLen_WTTR_P12_values, color = '#838383',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P16_values,PathLen_WTTR_P16_values, color = '#5B5B5B',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P21_values,PathLen_WTTR_P21_values, color = '#343434',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_WTTR_P30_values,PathLen_WTTR_P30_values, color = '#0D0D0D',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.scatter(SegLen_KOTR_P7_values,PathLen_KOTR_P7_values, color = '#C2DCDE',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P12_values,PathLen_KOTR_P12_values, color = '#6DB7BA',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P16_values,PathLen_KOTR_P16_values, color = '#289498',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P21_values,PathLen_KOTR_P21_values, color = '#008287',zorder='2',alpha='0.8',edgecolors='none', s=30)
ax.scatter(SegLen_KOTR_P30_values,PathLen_KOTR_P30_values, color = '#025F64',zorder='2',alpha='0.8',edgecolors='none', s=30)

ax.set_xlabel('SegLen')
ax.set_ylabel('PathLen')
#Plot Unity Line
ax.plot([-6,6],[-6,6])

plot.show()

