import os
import ExamplePlotter_AnnotationReader
import matplotlib.pyplot as plot
file_location = raw_input("Input data path.")
os.chdir(file_location)
annotation_files = ExamplePlotter_AnnotationReader.annotation_finder(file_location)

for annotation_file in annotation_files:

    #Start by finding the paths and getting the coordinates for each node in the paths
    #This will allow you to plot without having lines between the last node of each tree and the first
    #node of the next tree, which happens with plot.plot(x,y) where x and y are the coords for each node
    id = str(ExamplePlotter_AnnotationReader.annotation_filename_getter(annotation_file))
    print id
    #
    # step = ExamplePlotter_AnnotationReader.step_size_corrector(id)
    # print step

    nodes, edges = ExamplePlotter_AnnotationReader.annotation_parser(annotation_file)

    source_target_dict = ExamplePlotter_AnnotationReader.source_target(edges)

    # node_locations =  ExamplePlotter_AnnotationReader.node_location_finder(nodes, edges, step)
    node_locations = ExamplePlotter_AnnotationReader.node_location_finder(nodes, edges)


    source_target_pairs = [[edge.attrib['source'], edge.attrib['target']] for edge in edges]
    target_source_pairs = [[edge.attrib['target'], edge.attrib['source']] for edge in edges]
    combined_node_pairs = source_target_pairs + target_source_pairs
    target_nodes = [pair[0] for pair in combined_node_pairs]
    source_nodes = [pair[1] for pair in combined_node_pairs]
    combined_source_targets_flat = target_nodes + source_nodes
    unique_nodes_set = set(combined_source_targets_flat)
    unique_nodes1 = list(unique_nodes_set)

    node_id_list = [node.attrib['id'] for node in nodes]
    tip_list = [node for node in unique_nodes1 if combined_source_targets_flat.count(node) == 2]
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]
    path_list = [ExamplePlotter_AnnotationReader.path_finder(source_target_dict, soma_node, tip) for tip in tip_list]
    node_location = ExamplePlotter_AnnotationReader.node_location_finder(nodes, edges)


    #get the locations for each node in each path
    for path in range(0, len(path_list)):
        matches = [item for item in node_location if item[0] in path_list[path]]
        matches_nodes = [match[0] for match in matches]
        matches_index = [path_list[path].index(node) for node in matches_nodes]
        sorted_matches = [x for _, x in sorted(zip(matches_index, matches))]
        int_matches = [[float(coordinate) for coordinate in match] for match in sorted_matches]
        x = [location[1] for location in sorted_matches]
        y = [location[2] for location in sorted_matches]
        plot.plot(x,y)

    #Identify the soma node identity and location, then plot a node of size 20 there
    #This is useful for scaling each cell reconstruction equally for figures since each differs significantly in
    #the span of the arbor (and therefore axes). Plotting a point in this way avoids excessive manual axis scaling

    #Start by finding the soma node
    node_id_list = [node.attrib['id'] for node in nodes]
    radii_list = [node.attrib['radius'] for node in nodes]
    soma_node = node_id_list[radii_list.index(max(radii_list))]

    #Get soma node location and plot a size 20 marker at that location
    soma_location = [node for node in nodes if node.attrib['id'] == soma_node]
    soma_x = [node.attrib['x'] for node in soma_location]
    soma_y = [node.attrib['y'] for node in soma_location]
    plot.plot(soma_x,soma_y,'bo',markersize=20)

    plot.show()
