import os
import sqlite3
import xml.etree.ElementTree as ET
import glob
from scipy.spatial import distance
from scipy.spatial import ConvexHull
import numpy as np

connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
cursor = connection.execute("select * from Steps")

for row in cursor:
     # print row
     print 'animal_id =', row[0]
     print 'neuron_id =', row[1]

# connection.execute('drop table Steps')
# connection.execute('''create table Steps(animal_id text, neuron_id text primary key, step real);''')

#
# file_location = raw_input("Input data path.")
# os.chdir(file_location)
# # print file_location
# logfiles=glob.glob("C:\Users\Sarah\Desktop\TestData\TestTextFiles\Renamed" + "\*.log")
# # print logfiles
# textfiles = glob.glob("C:\Users\Sarah\Desktop\TestData\TestTextFiles\Renamed" + "\*.txt")
# annotationtextfiles = logfiles + textfiles
# # print len(annotationtextfiles)
# textfilenames = [textfilename[54:66] for textfilename in annotationtextfiles]
# # print textfilenames
#
# os.chdir("C:\Users\Sarah\Desktop\Annotations\Attempt102917\Added")
# annotationfiles=glob.glob("C:\Users\Sarah\Desktop\Annotations\Attempt102917\Added" + "\*.xml")
# # print annotationfiles
# cellnames = [annotationfile[-29:-17] for annotationfile in annotationfiles]
# # print cellnames
#
# no_match = [name for name in textfilenames if name not in cellnames]
# # print no_match
# # print len(no_match)
# matches = [name for name in cellnames if name in textfilenames]
# # print len(matches)
# # print matches
# #
#
# for file in annotationtextfiles:
#     a = open(file, 'r')
#     text = a.readlines()
#     line = text[6]
#     step_size =[file[54:66], float(line[21:24])]
#     # print step_size
#
#     # print step_size
#     #extract just the step size
#     # adjusted_step_size = [step for step in step_size if step[0] in matches]
#     # print adjusted_step_size
#     id = step_size[0]
#     # print id
#     animal_id = id[0:6]
#     # print animal_id
#     step = step_size[1]
#     # print adjusted_step_size
#     # print len(adjusted_step_size)
#
#
#     animal_id = str(animal_id)
#     print animal_id
#
#     neuron_id = str(id)
#     print neuron_id
#     #
#     step = str(step)
#     print step
#
#     connection.execute("insert into Steps (animal_id, neuron_id,step) values(?,?,?);",(animal_id,neuron_id,step))


connection.commit()


