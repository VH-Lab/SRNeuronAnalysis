import os
import sqlite3
import AnnotationReaderXML

connection=sqlite3.connect('C:\Users\Sarah\PycharmProjects\SRNeuronAnalysis\Dendrite_Analysis.db')
# cursor = connection.execute("select * from Neurons")
# # for row in cursor:
# #     print row
# # cursor = connection.execute("select * from Neurons")
# # cursor = connection.execute("select avg(soma_radius) from Neurons")
# #
# #
# for row in cursor:
#      # print row
#      print 'animal_id', row[0]
#      print 'neuron_id =', row[1]
#      # print 'soma_size =', row[2]
#      # print 'tree_number=', row[3]
#      print 'arbor_length', row[10]
#      print 'branch_number', row [6]
#      # # print 'mean_branch_number=', row[5]
#      # print 'branch_lengths',row[6]
#      # print 'mean_branch_length',row[5]
#      # print 'volume', row[14]
#      # print 'density', row[15]

connection.execute('drop table Neurons')
# # # # #connection.execute('''create table Neurons(animal_id text, neuron_id text primary key,soma_radius real,tree_number int, mean_branch_length real, branch_lengths text, branch_number int, path_lengths text, mean_path_length real,tip_number int);''')
connection.execute('''create table Neurons(animal_id text, neuron_id text primary key,soma_radius real, primary_arbor_number int, mean_segment_length real, segment_lengths text,
    segment_number int, path_lengths text, mean_path_length real, tip_number int, arbor_length real, tortuosity text, mean_tortuosity real, volume int, density real, sholl text, intersections int, norm_intersections real);''')

file_location = raw_input("Input data path.")
os.chdir(file_location)
annotation_files = AnnotationReaderXML.annotation_finder(file_location)

for annotation_file in annotation_files:

    nodes,edges = AnnotationReaderXML.annotation_parser(annotation_file)
    source_target_dict = AnnotationReaderXML.source_target(edges)

    id = str(AnnotationReaderXML.annotation_filename_getter(annotation_file))
    print id

    step = AnnotationReaderXML.step_size_corrector(id)
    print step

    animal_id = annotation_file[-29:-23]
    print animal_id

    neuron_id = annotation_file[-29:-16]
    print neuron_id
    soma_radius = AnnotationReaderXML.soma_size(nodes,edges)

    primary_arbor_num = AnnotationReaderXML.primary_arbor_number(nodes,edges)

    segment_num = AnnotationReaderXML.segment_number(nodes,edges)

    tip_num = AnnotationReaderXML.tip_number(nodes,edges)

    segment_lengths, mean_segment_length = AnnotationReaderXML.segment_length(source_target_dict, nodes, edges,step)
    segment_lengths = str(segment_lengths).strip('[]')

    arbor_length = AnnotationReaderXML.arbor_length(source_target_dict, nodes, edges,step)

    path_lengths, mean_path_length = AnnotationReaderXML.path_length(source_target_dict, nodes, edges,step)
    path_lengths = str(path_lengths).strip('[]')
    mean_path_length = mean_path_length


    tortuosity, mean_tortuosity = AnnotationReaderXML.tortuosity(source_target_dict, nodes, edges,step)
    tortuosity = str(tortuosity).strip('[]')


    volume = AnnotationReaderXML.volume(nodes, edges,step)

    density = AnnotationReaderXML.density(source_target_dict, nodes, edges,step)

    sholl = AnnotationReaderXML.sholl(source_target_dict, nodes, edges,step)
    sholl = str(sholl).strip('[]')

    intersections,norm_intersections = AnnotationReaderXML.intersections(source_target_dict, nodes, edges,step)
    intersections = str(intersections).strip('[]')
    norm_intersections = norm_intersections

    #connection.execute("insert into Neurons (animal_id,neuron_id,soma_radius,tree_number,mean_branch_length,branch_lengths, branch_number, path_lengths,mean_path_length, tip_number,volume,density) values(?,?,?,?,?,?,?,?,?,?,?,?);",(animal_id,neuron_id,soma_radius, tree_num,mean_branch_length,branch_lengths, branch_num, path_lengths, mean_path_length,tip_num,volume,density))
    connection.execute("insert into Neurons (animal_id,neuron_id,soma_radius, primary_arbor_number, mean_segment_length, segment_lengths, segment_number, path_lengths, mean_path_length, tip_number, arbor_length, tortuosity, mean_tortuosity, volume, density, sholl, intersections, norm_intersections) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);",(animal_id,neuron_id,soma_radius, tree_num, mean_branch_length, branch_lengths, branch_num, path_lengths, mean_path_length, tip_num, arbor_length, tortuosity, mean_tortuosity, volume, density, sholl, intersections,norm_intersections))

connection.commit()